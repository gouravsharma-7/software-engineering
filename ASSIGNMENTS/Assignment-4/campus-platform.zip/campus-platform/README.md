# Smart Campus Facility and Maintenance Platform

Vue 3 + Django REST Framework + PostgreSQL, deployed with Docker Compose (CSA10 Assignment 3).

## Run (clean environment)

```bash
cp .env.example .env          # then edit every value
docker compose config         # validate configuration
docker compose up --build -d  # builds, migrates once, seeds, starts 2 backend replicas + frontend
docker compose ps
```

Open http://localhost:3000. Demo users (`admin`, `manager1`, `tech1`, `tech2`, `approver1`, `faculty1`, `student1`) all use the `SEED_PASSWORD` from your `.env`.

Stop: `docker compose down` (keeps data). `docker compose down -v` deletes the database volume - do not use it during persistence checks.

## Tests and evidence

```bash
# Automated tests (needs the postgres service; creates a throw-away test database)
docker compose run --rm migrate sh -c "python manage.py makemigrations ops --noinput && python manage.py test -v 2"

# Live evidence against the running stack: concurrency, retries, bounded stepped load
SEED_PASSWORD=<your value> python scripts/validate.py http://localhost:3000
```

Migrations: the `migrate` service mounts `backend/ops/migrations`, so the generated `0002_*.py` appears in your working tree. **Commit it** so the schema is part of the release.

## Persistence check

```bash
docker compose restart backend      # application containers only
docker compose stop && docker compose start   # whole project, volume kept
```
Sign in again and confirm earlier bookings and tickets are still listed.

## Design rules (summary)

| Concern | Authority |
|---|---|
| Role permissions | Backend (`need()` in `ops/views.py`); UI hiding is cosmetic |
| Overlapping bookings | PostgreSQL exclusion constraint `booking_no_overlap` (+ facility row lock) |
| Duplicate bookings / tickets / sensor events | Unique `request_key`, unique `(source, event_id)` |
| Conflicting ticket updates | `expected_version` compared in the `UPDATE ... WHERE version=` |
| Integration retries | Intent persisted first; unique `correlation_key`; reconcile before re-create |

## Honest limitations

- The developer-issue tracker is **simulated** (mode is shown in the UI and API).
- Triage is deterministic keyword rules, not machine learning; the priority matrix is a proposed policy.
- Equipment loans, payments, occupancy forecasting and Kubernetes are out of scope for this release.
- 300 simultaneous users has **not** been tested; `scripts/validate.py` runs a bounded 10/25/50 client test only.
- Frontend has no automated tests; backend tests were written to run in the compose network.

## Git workflow

See `scripts/git_workflow.sh` (two feature branches, deliberate conflict, `v1.0.0` tag).
