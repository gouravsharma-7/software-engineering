import os

from django.contrib.auth.models import User
from django.core.management.base import BaseCommand, CommandError

from ops import policy
from ops.models import Facility, Profile, SLAPolicy

USERS = [("admin", "admin"), ("manager1", "manager"), ("tech1", "technician"), ("tech2", "technician"),
         ("approver1", "approver"), ("faculty1", "faculty"), ("student1", "student")]
FACILITIES = [("Physics Lab 101", "laboratory", True, 30), ("Chemistry Lab 202", "laboratory", True, 24),
              ("Seminar Room A", "seminar", False, 40), ("Classroom 12", "classroom", False, 60),
              ("Main Auditorium", "auditorium", True, 400)]


class Command(BaseCommand):
    help = "Idempotent synthetic seed data. Password comes from SEED_PASSWORD (never committed)."

    def handle(self, *args, **opts):
        pw = os.environ.get("SEED_PASSWORD")
        if not pw:
            raise CommandError("SEED_PASSWORD is not set")
        for name, role in USERS:
            u, created = User.objects.get_or_create(username=name)
            if created:
                u.set_password(pw)
                u.save()
            Profile.objects.get_or_create(user=u, defaults={"role": role})
        for name, kind, restricted, cap in FACILITIES:
            Facility.objects.get_or_create(name=name, defaults={"kind": kind, "restricted": restricted, "capacity": cap})
        for prio, hours in policy.SLA_HOURS.items():
            SLAPolicy.objects.get_or_create(priority=prio, defaults={"hours": hours})
        self.stdout.write("seed complete")
