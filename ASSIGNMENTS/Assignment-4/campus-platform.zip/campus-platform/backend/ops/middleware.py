import socket


class InstanceHeaderMiddleware:
    """Adds X-Instance so two-replica behaviour can be observed from the client."""

    def __init__(self, get_response):
        self.get_response = get_response
        self.host = socket.gethostname()

    def __call__(self, request):
        response = self.get_response(request)
        response["X-Instance"] = self.host
        return response
