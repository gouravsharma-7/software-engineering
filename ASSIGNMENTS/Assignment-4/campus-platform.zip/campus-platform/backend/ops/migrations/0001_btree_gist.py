from django.contrib.postgres.operations import BtreeGistExtension
from django.db import migrations


class Migration(migrations.Migration):
    """Enables btree_gist, required by the booking exclusion constraint."""

    dependencies = []
    operations = [BtreeGistExtension()]
