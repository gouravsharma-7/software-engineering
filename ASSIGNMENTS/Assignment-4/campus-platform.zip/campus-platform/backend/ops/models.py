from django.contrib.auth.models import User
from django.contrib.postgres.constraints import ExclusionConstraint
from django.contrib.postgres.fields import DateTimeRangeField, RangeBoundary, RangeOperators
from django.db import models
from django.db.models import F, Func, Q

ROLES = ["admin", "manager", "technician", "approver", "faculty", "student"]
BOOKING_STATES = ["requested", "approved", "confirmed", "in_use", "completed", "cancelled"]
SLOT_HOLDING = ["approved", "confirmed", "in_use"]  # states that occupy the slot
TICKET_STATES = ["NEW", "ASSIGNED", "INSPECTION", "IN_PROGRESS", "RESOLVED", "CLOSED"]


class TsTzRange(Func):
    function = "TSTZRANGE"
    output_field = DateTimeRangeField()


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name="profile")
    role = models.CharField(max_length=20, choices=[(r, r) for r in ROLES])


class Facility(models.Model):
    name = models.CharField(max_length=80, unique=True)
    kind = models.CharField(max_length=30)  # laboratory, classroom, seminar, auditorium
    campus = models.CharField(max_length=40, default="Main")
    capacity = models.PositiveIntegerField(default=30)
    restricted = models.BooleanField(default=False)


class SLAPolicy(models.Model):
    priority = models.CharField(max_length=2, unique=True)
    hours = models.PositiveIntegerField()


class Booking(models.Model):
    facility = models.ForeignKey(Facility, on_delete=models.PROTECT)
    requester = models.ForeignKey(User, on_delete=models.PROTECT)
    start_at = models.DateTimeField()
    end_at = models.DateTimeField()
    purpose = models.CharField(max_length=200)
    status = models.CharField(max_length=12, default="requested")
    version = models.PositiveIntegerField(default=1)
    request_key = models.CharField(max_length=64, unique=True)  # idempotency identity
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        constraints = [
            ExclusionConstraint(
                name="booking_no_overlap",
                expressions=[
                    ("facility", RangeOperators.EQUAL),
                    (TsTzRange("start_at", "end_at", RangeBoundary()), RangeOperators.OVERLAPS),
                ],
                condition=Q(status__in=SLOT_HOLDING),
            ),
            models.CheckConstraint(check=Q(end_at__gt=F("start_at")), name="booking_end_after_start"),
        ]


class Ticket(models.Model):
    title = models.CharField(max_length=120)
    description = models.TextField(blank=True)
    facility = models.ForeignKey(Facility, on_delete=models.PROTECT)
    created_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="tickets_created")
    assignee = models.ForeignKey(User, null=True, blank=True, on_delete=models.PROTECT, related_name="tickets_assigned")
    source = models.CharField(max_length=10, default="manual")  # manual | sensor
    request_key = models.CharField(max_length=64, unique=True, null=True, blank=True)
    category = models.CharField(max_length=20, default="general")
    impact = models.CharField(max_length=10, default="low")
    urgency = models.CharField(max_length=10, default="medium")
    priority = models.CharField(max_length=2, default="M4")
    explanation = models.JSONField(default=list)
    state = models.CharField(max_length=12, default="NEW")
    version = models.PositiveIntegerField(default=1)
    inspection_notes = models.TextField(blank=True)
    resolution_notes = models.TextField(blank=True)
    sla_due = models.DateTimeField()
    created_at = models.DateTimeField(auto_now_add=True)


class SensorEvent(models.Model):
    source = models.CharField(max_length=60)
    event_id = models.CharField(max_length=60)
    facility = models.ForeignKey(Facility, on_delete=models.PROTECT)
    metric = models.CharField(max_length=30)
    value = models.FloatField()
    observed_at = models.DateTimeField()
    ticket = models.ForeignKey(Ticket, null=True, on_delete=models.SET_NULL)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["source", "event_id"], name="sensor_event_identity")]


class Approval(models.Model):
    kind = models.CharField(max_length=10)  # booking | change
    booking = models.ForeignKey(Booking, null=True, blank=True, on_delete=models.PROTECT)
    ticket = models.ForeignKey(Ticket, null=True, blank=True, on_delete=models.PROTECT)
    status = models.CharField(max_length=10, default="pending")  # pending | approved | rejected
    requested_by = models.ForeignKey(User, on_delete=models.PROTECT, related_name="approvals_requested")
    decided_by = models.ForeignKey(User, null=True, on_delete=models.PROTECT, related_name="approvals_decided")
    reason = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)


class IntegrationIntent(models.Model):
    ticket = models.ForeignKey(Ticket, on_delete=models.PROTECT)
    purpose = models.CharField(max_length=80)
    correlation_key = models.CharField(max_length=64, unique=True)
    status = models.CharField(max_length=10, default="pending")  # pending | confirmed
    mode = models.CharField(max_length=12, default="simulated")  # disclosed: no real tracker
    external_ref = models.CharField(max_length=30, blank=True)
    remote_ref = models.CharField(max_length=30, blank=True)  # simulated remote record
    remote_creations = models.PositiveIntegerField(default=0)
    attempts = models.PositiveIntegerField(default=0)


class AuditEvent(models.Model):
    actor = models.ForeignKey(User, null=True, on_delete=models.SET_NULL)
    action = models.CharField(max_length=40)
    entity = models.CharField(max_length=20)
    entity_id = models.PositiveIntegerField()
    detail = models.JSONField(default=dict)
    created_at = models.DateTimeField(auto_now_add=True)

    def save(self, *args, **kwargs):
        if self.pk:
            raise ValueError("audit events are append-only")
        super().save(*args, **kwargs)
