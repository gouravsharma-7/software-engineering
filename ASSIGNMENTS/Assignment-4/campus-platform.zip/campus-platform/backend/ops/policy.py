"""Explicit planning assumptions. These are proposed policy values, not university rules."""

MAX_BOOKING_HOURS = 4

# Controlled sensor thresholds (synthetic).
THRESHOLDS = {"temperature": 30.0, "humidity": 75.0, "power_kw": 15.0}

# Proposed priority matrix: impact -> urgency -> priority.
PRIORITY_MATRIX = {
    "high": {"high": "M1", "medium": "M2", "low": "M3"},
    "medium": {"high": "M2", "medium": "M3", "low": "M4"},
    "low": {"high": "M3", "medium": "M4", "low": "M4"},
}

SLA_HOURS = {"M1": 4, "M2": 8, "M3": 24, "M4": 72}

# Deterministic keyword rules (NOT machine learning).
KEYWORDS = {
    "hvac": ["air-conditioning", "air conditioning", "ac ", "hvac", "temperature", "heating"],
    "electrical": ["power", "electric", "socket", "light", "sparks", "circuit"],
    "plumbing": ["leak", "water", "tap", "flood", "drain"],
    "network": ["wifi", "network", "internet", "projector"],
}
URGENT_WORDS = ["fire", "smoke", "leak", "flood", "sparks", "no power", "failure"]
LOW_WORDS = ["flicker", "minor", "paint", "cosmetic", "slow"]
