"""Run inside the compose network: docker compose run --rm migrate sh -c
"python manage.py makemigrations ops --noinput && python manage.py test -v 2"
"""
import threading
from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TransactionTestCase
from django.utils import timezone
from rest_framework.test import APIClient

from .models import Booking, Facility, Profile, SensorEvent, Ticket, AuditEvent, IntegrationIntent


def mk(name, role):
    u = User.objects.create_user(name, password="pw-test-only")
    Profile.objects.create(user=u, role=role)
    c = APIClient()
    c.force_authenticate(u)
    return u, c


class Base(TransactionTestCase):
    def setUp(self):
        self.fac = Facility.objects.create(name="Lab", kind="laboratory", restricted=False)
        self.rfac = Facility.objects.create(name="RLab", kind="laboratory", restricted=True)
        self.fac_id = self.fac.id
        self.fa, self.fc = mk("fac", "faculty")
        self.st, self.sc = mk("stu", "student")
        self.ap, self.ac = mk("app", "approver")
        self.mg, self.mc = mk("mgr", "manager")
        self.t1, self.t1c = mk("t1", "technician")
        self.t2, self.t2c = mk("t2", "technician")
        base = timezone.now().replace(minute=0, second=0, microsecond=0) + timedelta(days=1)
        self.s, self.e = base, base + timedelta(hours=2)

    def book(self, client, key, fac=None, s=None, e=None):
        return client.post("/api/bookings/", {"facility": (fac or self.fac).id, "start_at": (s or self.s).isoformat(),
                           "end_at": (e or self.e).isoformat(), "purpose": "test", "request_key": key}, format="json")

    def ticket(self):
        r = self.mc.post("/api/tickets/", {"facility": self.fac_id, "title": "AC failure", "request_key": "tk-1"}, format="json")
        return r.json()["id"]


class BookingTests(Base):
    def test_create_and_overlap_rejected(self):
        self.assertEqual(self.book(self.fc, "k1").status_code, 201)
        r = self.book(self.sc, "k2", s=self.s + timedelta(hours=1), e=self.e + timedelta(hours=1))
        self.assertEqual(r.status_code, 409)
        self.assertEqual(Booking.objects.count(), 1)

    def test_adjacent_slots_allowed(self):
        self.book(self.fc, "k1")
        self.assertEqual(self.book(self.sc, "k2", s=self.e, e=self.e + timedelta(hours=1)).status_code, 201)

    def test_idempotent_retry_creates_one_row(self):
        self.assertEqual(self.book(self.fc, "same").status_code, 201)
        self.assertEqual(self.book(self.fc, "same").status_code, 200)
        self.assertEqual(Booking.objects.count(), 1)

    def test_malformed_and_too_long(self):
        self.assertEqual(self.fc.post("/api/bookings/", {"facility": self.fac_id}, format="json").status_code, 400)
        self.assertEqual(self.book(self.fc, "k9", e=self.s + timedelta(hours=9)).status_code, 422)

    def test_restricted_booking_needs_approver(self):
        self.assertEqual(self.book(self.sc, "r1", fac=self.rfac).status_code, 201)
        aid = self.mc.get("/api/approvals/").json()[0]["id"]
        body = {"decision": "approved", "reason": "ok"}
        self.assertEqual(self.sc.post(f"/api/approvals/{aid}/decide/", body, format="json").status_code, 403)
        self.assertEqual(self.ac.post(f"/api/approvals/{aid}/decide/", body, format="json").status_code, 200)
        self.assertTrue(AuditEvent.objects.filter(action="approval.decide").exists())

    def test_concurrent_overlapping_requests_one_wins(self):
        results, barrier = [], threading.Barrier(2)

        def go(client, key):
            barrier.wait()
            results.append(self.book(client, key).status_code)
        th = [threading.Thread(target=go, args=(self.fc, "c1")), threading.Thread(target=go, args=(self.sc, "c2"))]
        [t.start() for t in th]
        [t.join() for t in th]
        self.assertEqual(sorted(results), [201, 409])
        self.assertEqual(Booking.objects.count(), 1)


class TicketTests(Base):
    def test_sensor_replay_one_ticket(self):
        body = {"source": "ac-7", "event_id": "e1", "facility": self.fac_id, "metric": "temperature",
                "value": 41, "observed_at": timezone.now().isoformat()}
        codes = [self.mc.post("/api/sensor-events/", body, format="json").status_code for _ in range(5)]
        self.assertEqual(codes, [201, 200, 200, 200, 200])
        self.assertEqual(Ticket.objects.count(), 1)
        self.assertEqual(SensorEvent.objects.count(), 1)

    def test_state_rules(self):
        tid = self.ticket()
        patch = lambda c, **b: c.patch(f"/api/tickets/{tid}/state/", b, format="json")
        self.assertEqual(patch(self.mc, state="CLOSED", expected_version=1).status_code, 422)  # NEW -> CLOSED
        self.assertEqual(patch(self.sc, state="ASSIGNED", expected_version=1, assignee_id=self.t1.id).status_code, 403)
        self.assertEqual(patch(self.mc, state="ASSIGNED", expected_version=1, assignee_id=self.t1.id).status_code, 200)
        self.assertEqual(patch(self.t2c, state="INSPECTION", expected_version=2, inspection_notes="x").status_code, 403)
        self.assertEqual(patch(self.t1c, state="INSPECTION", expected_version=2, inspection_notes="x").status_code, 200)
        # no approved change approval yet
        self.assertEqual(patch(self.t1c, state="IN_PROGRESS", expected_version=3).status_code, 422)

    def test_stale_version_conflict(self):
        tid = self.ticket()
        a = self.mc.patch(f"/api/tickets/{tid}/state/", {"state": "ASSIGNED", "expected_version": 1, "assignee_id": self.t1.id}, format="json")
        b = self.mc.patch(f"/api/tickets/{tid}/state/", {"state": "ASSIGNED", "expected_version": 1, "assignee_id": self.t2.id}, format="json")
        self.assertEqual((a.status_code, b.status_code), (200, 409))
        self.assertEqual(Ticket.objects.get(pk=tid).assignee_id, self.t1.id)

    def test_full_journey_and_close_rules(self):
        tid = self.ticket()
        P = lambda c, **b: c.patch(f"/api/tickets/{tid}/state/", b, format="json")
        P(self.mc, state="ASSIGNED", expected_version=1, assignee_id=self.t1.id)
        P(self.t1c, state="INSPECTION", expected_version=2, inspection_notes="compressor fault")
        aid = self.t1c.post("/api/approvals/", {"ticket": tid, "reason": "replace part"}, format="json").json()["id"]
        self.ac.post(f"/api/approvals/{aid}/decide/", {"decision": "approved", "reason": "justified"}, format="json")
        self.assertEqual(P(self.t1c, state="IN_PROGRESS", expected_version=3).status_code, 200)
        self.assertEqual(P(self.t1c, state="RESOLVED", expected_version=4).status_code, 422)  # no notes
        self.assertEqual(P(self.t1c, state="RESOLVED", expected_version=4, resolution_notes="part replaced").status_code, 200)
        iid = self.t1c.post("/api/integrations/intents/", {"ticket": tid, "purpose": "deploy-check", "correlation_key": "cor-1"}, format="json").json()["id"]
        self.assertEqual(P(self.mc, state="CLOSED", expected_version=5).status_code, 422)  # unverified link
        self.assertEqual(self.t1c.post(f"/api/integrations/intents/{iid}/dispatch/", {}, format="json").status_code, 200)
        self.assertEqual(P(self.mc, state="CLOSED", expected_version=5).status_code, 200)

    def test_timeout_then_retry_does_not_duplicate_remote(self):
        tid = self.ticket()
        iid = self.mc.post("/api/integrations/intents/", {"ticket": tid, "purpose": "p", "correlation_key": "cor-2"}, format="json").json()["id"]
        self.assertEqual(self.mc.post(f"/api/integrations/intents/{iid}/dispatch/", {"simulate_timeout": True}, format="json").status_code, 504)
        self.assertEqual(self.mc.post(f"/api/integrations/intents/{iid}/dispatch/", {}, format="json").status_code, 200)
        i = IntegrationIntent.objects.get(pk=iid)
        self.assertEqual((i.status, i.remote_creations), ("confirmed", 1))
