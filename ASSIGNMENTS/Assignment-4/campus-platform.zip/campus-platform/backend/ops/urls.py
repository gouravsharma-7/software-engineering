from django.urls import path

from . import views as v

urlpatterns = [
    path("health/live", v.live),
    path("health/ready", v.ready),
    path("auth/login/", v.login),
    path("facilities/", v.facilities),
    path("technicians/", v.technicians),
    path("dashboard/", v.dashboard),
    path("audit/", v.audit_list),
    path("bookings/", v.bookings),
    path("bookings/<int:pk>/transition/", v.booking_transition),
    path("tickets/", v.tickets),
    path("tickets/<int:pk>/state/", v.ticket_state),
    path("sensor-events/", v.sensor_events),
    path("approvals/", v.approvals),
    path("approvals/<int:pk>/decide/", v.approval_decide),
    path("integrations/intents/", v.intents),
    path("integrations/intents/<int:pk>/dispatch/", v.intent_dispatch),
]
