import zlib
from datetime import timedelta

from django.contrib.auth import authenticate
from django.db import IntegrityError, connection, transaction
from django.db.models import Count, F
from django.utils import timezone
from django.utils.dateparse import parse_date, parse_datetime
from django.conf import settings
from rest_framework.authtoken.models import Token
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.exceptions import APIException
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from . import policy
from .models import (Approval, AuditEvent, Booking, Facility, IntegrationIntent, SensorEvent,
                     Ticket, User, SLOT_HOLDING, TICKET_STATES)


# ---------------------------------------------------------------- errors / helpers
class Err(APIException):
    def __init__(self, status, code, message):
        self.status_code = status
        self.detail = {"code": code, "message": message}


def need(request, *roles):
    role = request.user.profile.role
    if role not in roles:
        raise Err(403, "forbidden", f"role '{role}' may not perform this action")


def audit(actor, action, entity, entity_id, **detail):
    AuditEvent.objects.create(actor=actor, action=action, entity=entity, entity_id=entity_id, detail=detail)


def parse_dt(value, field):
    dt = parse_datetime(value) if isinstance(value, str) else None
    if dt is None or dt.tzinfo is None:
        raise Err(400, "malformed", f"{field} must be ISO-8601 with a timezone offset")
    return dt


def require_str(d, field, maxlen=200):
    v = d.get(field)
    if not isinstance(v, str) or not v.strip() or len(v) > maxlen:
        raise Err(400, "malformed", f"{field} is required (non-empty text, max {maxlen})")
    return v.strip()


def get_or_404(model, pk, **kw):
    try:
        return model.objects.get(pk=pk, **kw)
    except (model.DoesNotExist, ValueError, TypeError):
        raise Err(404, "not_found", f"{model.__name__} {pk} not found")


def booking_dict(b):
    return {"id": b.id, "facility": b.facility_id, "facility_name": b.facility.name,
            "requester": b.requester.username, "start_at": b.start_at, "end_at": b.end_at,
            "purpose": b.purpose, "status": b.status, "version": b.version}


def sla_status(t):
    if t.state == "CLOSED":
        return "closed"
    left = t.sla_due - timezone.now()
    if left.total_seconds() < 0:
        return "breached"
    return "at_risk" if left < timedelta(hours=2) else "ok"


def ticket_dict(t):
    return {"id": t.id, "title": t.title, "description": t.description, "facility": t.facility.name,
            "source": t.source, "category": t.category, "impact": t.impact, "urgency": t.urgency,
            "priority": t.priority, "explanation": t.explanation, "state": t.state,
            "version": t.version, "assignee": t.assignee.username if t.assignee else None,
            "inspection_notes": t.inspection_notes, "resolution_notes": t.resolution_notes,
            "sla_due": t.sla_due, "sla_status": sla_status(t)}


def triage(text, kind, metric=None, value=None):
    """Deterministic, explainable rules. Not a trained model."""
    t = text.lower()
    why, category = [], "general"
    for cat, words in policy.KEYWORDS.items():
        hits = [w.strip() for w in words if w in t]
        if hits:
            category = cat
            why.append(f"category '{cat}' because text contains {hits}")
            break
    impact = "high" if kind in ("laboratory", "auditorium") else "medium" if kind in ("classroom", "seminar") else "low"
    why.append(f"impact '{impact}' because facility kind is '{kind}'")
    urgency = "medium"
    if metric in policy.THRESHOLDS and value is not None:
        ratio = value / policy.THRESHOLDS[metric]
        urgency = "high" if ratio >= 1.2 else "medium"
        why.append(f"urgency '{urgency}' because {metric}={value} is {ratio:.2f}x threshold")
    elif any(w in t for w in policy.URGENT_WORDS):
        urgency = "high"
        why.append("urgency 'high' because text contains an urgent keyword")
    elif any(w in t for w in policy.LOW_WORDS):
        urgency = "low"
        why.append("urgency 'low' because text contains a low-severity keyword")
    prio = policy.PRIORITY_MATRIX[impact][urgency]
    why.append(f"priority {prio} from proposed matrix (impact={impact}, urgency={urgency})")
    return {"category": category, "impact": impact, "urgency": urgency, "priority": prio, "explanation": why}


def new_ticket(user, facility, title, desc, source, request_key=None, metric=None, value=None):
    tr = triage(f"{title} {desc}", facility.kind, metric, value)
    return Ticket.objects.create(
        title=title, description=desc, facility=facility, created_by=user, source=source,
        request_key=request_key, category=tr["category"], impact=tr["impact"], urgency=tr["urgency"],
        priority=tr["priority"], explanation=tr["explanation"],
        sla_due=timezone.now() + timedelta(hours=policy.SLA_HOURS[tr["priority"]]))


def overlap_exists(facility_id, start, end, exclude_id=None):
    qs = Booking.objects.filter(facility_id=facility_id, status__in=SLOT_HOLDING,
                                start_at__lt=end, end_at__gt=start)
    if exclude_id:
        qs = qs.exclude(pk=exclude_id)
    return qs.exists()


# ---------------------------------------------------------------- health / auth
@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def live(request):
    return Response({"status": "alive"})


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def ready(request):
    try:
        with connection.cursor() as c:
            c.execute("SELECT 1")
            c.execute("SELECT to_regclass('public.ops_booking')")
            if c.fetchone()[0] is None:
                raise RuntimeError("schema not migrated")
    except Exception as exc:  # readiness means DB reachable AND schema present
        return Response({"status": "not_ready", "reason": str(exc)}, status=503)
    return Response({"status": "ready"})


@api_view(["POST"])
@authentication_classes([])
@permission_classes([AllowAny])
def login(request):
    user = authenticate(username=str(request.data.get("username", "")), password=str(request.data.get("password", "")))
    if not user:
        raise Err(401, "bad_credentials", "invalid username or password")
    token, _ = Token.objects.get_or_create(user=user)
    return Response({"token": token.key, "username": user.username, "role": user.profile.role})


# ---------------------------------------------------------------- catalogue / dashboard
@api_view(["GET"])
def facilities(request):
    return Response([{"id": f.id, "name": f.name, "kind": f.kind, "campus": f.campus,
                      "capacity": f.capacity, "restricted": f.restricted} for f in Facility.objects.order_by("name")])


@api_view(["GET"])
def technicians(request):
    return Response([{"id": u.id, "username": u.username} for u in User.objects.filter(profile__role="technician")])


@api_view(["GET"])
def dashboard(request):
    by_state = {r["state"]: r["n"] for r in Ticket.objects.values("state").annotate(n=Count("id"))}
    open_t = list(Ticket.objects.exclude(state="CLOSED"))
    return Response({
        "note": "synthetic test data; not measured utilisation",
        "facilities": Facility.objects.count(),
        "bookings_active": Booking.objects.filter(status__in=SLOT_HOLDING).count(),
        "bookings_pending_approval": Booking.objects.filter(status="requested").count(),
        "tickets_by_state": by_state,
        "sla_breached": sum(1 for t in open_t if sla_status(t) == "breached"),
        "sla_at_risk": sum(1 for t in open_t if sla_status(t) == "at_risk"),
        "sensor_events": SensorEvent.objects.count(),
    })


@api_view(["GET"])
def audit_list(request):
    need(request, "admin", "manager")
    qs = AuditEvent.objects.select_related("actor").order_by("-id")[:100]
    return Response([{"id": a.id, "actor": a.actor.username if a.actor else None, "action": a.action,
                      "entity": a.entity, "entity_id": a.entity_id, "detail": a.detail,
                      "at": a.created_at} for a in qs])


# ---------------------------------------------------------------- bookings
@api_view(["GET", "POST"])
def bookings(request):
    if request.method == "GET":
        qs = Booking.objects.select_related("facility", "requester").order_by("start_at")
        if request.query_params.get("facility"):
            qs = qs.filter(facility_id=request.query_params["facility"])
        day = parse_date(request.query_params.get("date", "") or "")
        if day:
            qs = qs.filter(start_at__date=day)
        return Response([booking_dict(b) for b in qs[:200]])

    d = request.data
    key = require_str(d, "request_key", 64)
    start, end = parse_dt(d.get("start_at"), "start_at"), parse_dt(d.get("end_at"), "end_at")
    purpose = require_str(d, "purpose")
    if end <= start:
        raise Err(422, "invalid_range", "end_at must be after start_at")
    if end - start > timedelta(hours=policy.MAX_BOOKING_HOURS):
        raise Err(422, "too_long", f"maximum booking length is {policy.MAX_BOOKING_HOURS} hours")

    existing = Booking.objects.filter(request_key=key).select_related("facility", "requester").first()
    if existing:
        return _replay(request, existing)
    try:
        with transaction.atomic():
            fac = Facility.objects.select_for_update().filter(pk=d.get("facility")).first()
            if not fac:
                raise Err(404, "not_found", "facility not found")
            status = "requested" if fac.restricted else "confirmed"
            if status == "confirmed" and overlap_exists(fac.id, start, end):
                raise Err(409, "overlap", "the slot overlaps an existing booking")
            b = Booking.objects.create(facility=fac, requester=request.user, start_at=start,
                                       end_at=end, purpose=purpose, status=status, request_key=key)
            if fac.restricted:
                Approval.objects.create(kind="booking", booking=b, requested_by=request.user)
            audit(request.user, "booking.create", "booking", b.id, status=status)
    except IntegrityError:
        # Either the exclusion constraint (overlap) or a racing duplicate request_key.
        existing = Booking.objects.filter(request_key=key).select_related("facility", "requester").first()
        if existing:
            return _replay(request, existing)
        raise Err(409, "overlap", "the slot overlaps an existing booking (database constraint)")
    return Response(booking_dict(b), status=201)


def _replay(request, existing):
    if existing.requester_id != request.user.id:
        raise Err(409, "key_conflict", "request_key already used by another user")
    return Response({**booking_dict(existing), "replayed": True}, status=200)


BOOKING_FLOW = {"requested": {"cancelled"}, "approved": {"confirmed", "cancelled"},
                "confirmed": {"in_use", "cancelled"}, "in_use": {"completed"}}


@api_view(["POST"])
def booking_transition(request, pk):
    target = require_str(request.data, "target", 20)
    ev = request.data.get("expected_version")
    if not isinstance(ev, int):
        raise Err(400, "malformed", "expected_version (integer) is required")
    with transaction.atomic():
        b = Booking.objects.select_for_update().select_related("facility", "requester").filter(pk=pk).first()
        if not b:
            raise Err(404, "not_found", f"Booking {pk} not found")
        if b.version != ev:
            raise Err(409, "stale_version", f"booking is at version {b.version}, not {ev}")
        if target not in BOOKING_FLOW.get(b.status, set()):
            raise Err(422, "invalid_transition", f"{b.status} -> {target} is not allowed")
        if target == "cancelled":
            if request.user.id != b.requester_id:
                need(request, "admin", "manager")
        elif target == "confirmed":
            if request.user.id != b.requester_id:
                need(request, "admin", "manager")
        else:
            need(request, "admin", "manager")
        if target in ("confirmed", "in_use") and overlap_exists(b.facility_id, b.start_at, b.end_at, b.id):
            raise Err(409, "overlap", "the slot overlaps an existing booking")
        try:
            with transaction.atomic():
                b.status, b.version = target, b.version + 1
                b.save(update_fields=["status", "version"])
        except IntegrityError:
            raise Err(409, "overlap", "the slot overlaps an existing booking (database constraint)")
        audit(request.user, "booking.transition", "booking", b.id, to=target)
    return Response(booking_dict(b))


# ---------------------------------------------------------------- tickets
@api_view(["GET", "POST"])
def tickets(request):
    if request.method == "GET":
        qs = Ticket.objects.select_related("facility", "assignee").order_by("priority", "sla_due")
        return Response([ticket_dict(t) for t in qs[:200]])
    d = request.data
    key = require_str(d, "request_key", 64)
    title, desc = require_str(d, "title", 120), str(d.get("description", ""))[:2000]
    existing = Ticket.objects.filter(request_key=key).select_related("facility", "assignee").first()
    if existing:
        return Response({**ticket_dict(existing), "replayed": True}, status=200)
    fac = get_or_404(Facility, d.get("facility"))
    try:
        with transaction.atomic():
            t = new_ticket(request.user, fac, title, desc, "manual", request_key=key)
            audit(request.user, "ticket.create", "ticket", t.id, priority=t.priority)
    except IntegrityError:
        t = Ticket.objects.select_related("facility", "assignee").get(request_key=key)
        return Response({**ticket_dict(t), "replayed": True}, status=200)
    return Response(ticket_dict(t), status=201)


@api_view(["PATCH"])
def ticket_state(request, pk):
    d = request.data
    target, ev = d.get("state"), d.get("expected_version")
    if target not in TICKET_STATES:
        raise Err(400, "malformed", f"state must be one of {TICKET_STATES}")
    if not isinstance(ev, int):
        raise Err(400, "malformed", "expected_version (integer) is required")
    flow = {"NEW": "ASSIGNED", "ASSIGNED": "INSPECTION", "INSPECTION": "IN_PROGRESS",
            "IN_PROGRESS": "RESOLVED", "RESOLVED": "CLOSED"}
    with transaction.atomic():
        t = Ticket.objects.select_related("facility", "assignee").filter(pk=pk).first()
        if not t:
            raise Err(404, "not_found", f"Ticket {pk} not found")
        if t.version != ev:
            raise Err(409, "stale_version", f"ticket is at version {t.version}, not {ev}; refresh and retry")
        if flow.get(t.state) != target:
            raise Err(422, "invalid_transition", f"{t.state} -> {target} is not allowed")
        fields = {"state": target}
        role = request.user.profile.role
        if target == "ASSIGNED":
            need(request, "admin", "manager")
            tech = User.objects.filter(pk=d.get("assignee_id"), profile__role="technician").first()
            if not tech:
                raise Err(422, "bad_assignee", "assignee_id must be a technician")
            fields["assignee"] = tech
        else:
            need(request, "admin", "manager", "technician")
            if role == "technician" and t.assignee_id != request.user.id:
                raise Err(403, "forbidden", "only the assigned technician may update this ticket")
            if target in ("INSPECTION", "IN_PROGRESS", "RESOLVED") and role == "manager":
                raise Err(403, "forbidden", "managers assign and close; technicians do the work")
        if target == "INSPECTION":
            notes = str(d.get("inspection_notes", "")).strip()
            if not notes:
                raise Err(422, "notes_required", "inspection_notes are required")
            fields["inspection_notes"] = notes
        if target == "IN_PROGRESS" and not Approval.objects.filter(ticket=t, kind="change", status="approved").exists():
            raise Err(422, "approval_required", "an approved change approval is required before work starts")
        if target == "RESOLVED":
            notes = str(d.get("resolution_notes", "")).strip()
            if not notes:
                raise Err(422, "notes_required", "resolution_notes are required")
            fields["resolution_notes"] = notes
        if target == "CLOSED":
            need(request, "admin", "manager")
            if IntegrationIntent.objects.filter(ticket=t).exclude(status="confirmed").exists():
                raise Err(422, "integration_unverified", "linked developer issue is not confirmed")
        # Optimistic concurrency: the WHERE clause on version is the arbiter.
        n = Ticket.objects.filter(pk=pk, version=ev).update(version=F("version") + 1, **fields)
        if n != 1:
            raise Err(409, "stale_version", "ticket was changed by another update; refresh and retry")
        audit(request.user, "ticket.transition", "ticket", t.id, frm=t.state, to=target, version=ev + 1)
    t.refresh_from_db()
    return Response(ticket_dict(t))


# ---------------------------------------------------------------- sensors
@api_view(["POST"])
def sensor_events(request):
    need(request, "admin", "manager", "technician")
    d = request.data
    source, event_id = require_str(d, "source", 60), require_str(d, "event_id", 60)
    metric = require_str(d, "metric", 30)
    if isinstance(d.get("value"), bool) or not isinstance(d.get("value"), (int, float)):
        raise Err(400, "malformed", "value must be a number")
    value, observed = float(d["value"]), parse_dt(d.get("observed_at"), "observed_at")
    fac = get_or_404(Facility, d.get("facility"))
    try:
        with transaction.atomic():  # event row and ticket commit together or not at all
            ev = SensorEvent.objects.create(source=source, event_id=event_id, facility=fac,
                                            metric=metric, value=value, observed_at=observed)
            th = policy.THRESHOLDS.get(metric)
            if th is not None and value > th:
                t = new_ticket(request.user, fac, f"Sensor alert: {metric} {value} at {fac.name}",
                               f"{metric} exceeded threshold {th}", "sensor", metric=metric, value=value)
                ev.ticket = t
                ev.save(update_fields=["ticket"])
                audit(request.user, "sensor.ticket", "ticket", t.id, event=f"{source}/{event_id}")
    except IntegrityError:
        ev = SensorEvent.objects.select_related("ticket", "ticket__facility", "ticket__assignee").get(source=source, event_id=event_id)
        return Response({"duplicate": True, "event_id": event_id, "ticket_id": ev.ticket_id}, status=200)
    return Response({"duplicate": False, "event_id": event_id, "ticket_id": ev.ticket_id,
                     "breached": ev.ticket_id is not None}, status=201)


# ---------------------------------------------------------------- approvals
@api_view(["GET", "POST"])
def approvals(request):
    if request.method == "GET":
        qs = Approval.objects.select_related("booking", "ticket").order_by("-id")[:100]
        return Response([{"id": a.id, "kind": a.kind, "booking": a.booking_id, "ticket": a.ticket_id,
                          "status": a.status, "reason": a.reason} for a in qs])
    need(request, "admin", "manager", "technician")  # request a change approval for a ticket
    t = get_or_404(Ticket, request.data.get("ticket"))
    reason = require_str(request.data, "reason", 500)
    with transaction.atomic():
        a = Approval.objects.create(kind="change", ticket=t, requested_by=request.user, reason=reason)
        audit(request.user, "approval.request", "approval", a.id, ticket=t.id)
    return Response({"id": a.id, "status": a.status}, status=201)


@api_view(["POST"])
def approval_decide(request, pk):
    need(request, "approver", "admin")  # enforced on the server, not only hidden in the UI
    decision = request.data.get("decision")
    if decision not in ("approved", "rejected"):
        raise Err(400, "malformed", "decision must be 'approved' or 'rejected'")
    reason = require_str(request.data, "reason", 500)
    with transaction.atomic():
        a = Approval.objects.select_for_update().filter(pk=pk).first()
        if not a:
            raise Err(404, "not_found", f"Approval {pk} not found")
        if a.status != "pending":
            raise Err(409, "already_decided", f"approval already {a.status}")
        if a.booking_id:
            b = Booking.objects.select_for_update().get(pk=a.booking_id)
            if decision == "approved":
                if overlap_exists(b.facility_id, b.start_at, b.end_at, b.id):
                    raise Err(409, "overlap", "slot taken since the request was made")
                try:
                    with transaction.atomic():
                        b.status, b.version = "approved", b.version + 1
                        b.save(update_fields=["status", "version"])
                except IntegrityError:
                    raise Err(409, "overlap", "slot taken (database constraint)")
            else:
                b.status, b.version = "cancelled", b.version + 1
                b.save(update_fields=["status", "version"])
        a.status, a.decided_by, a.reason = decision, request.user, reason
        a.save(update_fields=["status", "decided_by", "reason"])
        audit(request.user, "approval.decide", "approval", a.id, decision=decision, reason=reason)
    return Response({"id": a.id, "status": a.status})


# ---------------------------------------------------------------- integration (simulated tracker)
def intent_dict(i):
    return {"id": i.id, "ticket": i.ticket_id, "purpose": i.purpose, "correlation_key": i.correlation_key,
            "status": i.status, "mode": i.mode, "external_ref": i.external_ref,
            "remote_creations": i.remote_creations, "attempts": i.attempts}


@api_view(["GET", "POST"])
def intents(request):
    if request.method == "GET":
        return Response([intent_dict(i) for i in IntegrationIntent.objects.order_by("-id")[:100]])
    need(request, "admin", "manager", "technician")
    t = get_or_404(Ticket, request.data.get("ticket"))
    key, purpose = require_str(request.data, "correlation_key", 64), require_str(request.data, "purpose", 80)
    try:
        with transaction.atomic():  # the intent is persisted BEFORE any remote call
            i = IntegrationIntent.objects.create(ticket=t, purpose=purpose, correlation_key=key)
            audit(request.user, "intent.create", "intent", i.id, ticket=t.id)
        return Response(intent_dict(i), status=201)
    except IntegrityError:
        return Response({**intent_dict(IntegrationIntent.objects.get(correlation_key=key)), "replayed": True})


@api_view(["POST"])
def intent_dispatch(request, pk):
    need(request, "admin", "manager", "technician")
    fault = bool(request.data.get("simulate_timeout")) and settings.ALLOW_FAULT_INJECTION
    with transaction.atomic():
        i = IntegrationIntent.objects.select_for_update().filter(pk=pk).first()
        if not i:
            raise Err(404, "not_found", f"Intent {pk} not found")
        if i.status == "confirmed":
            return Response({**intent_dict(i), "replayed": True})
        i.attempts += 1
        # Reconcile first: look the remote record up by correlation key before creating anything.
        if not i.remote_ref:
            i.remote_ref = f"CAMP-{300 + zlib.crc32(i.correlation_key.encode()) % 700}"
            i.remote_creations += 1
            if fault:  # remote record exists, but the response is "lost"
                i.save()
                audit(request.user, "intent.timeout", "intent", i.id, attempts=i.attempts)
                return Response({"code": "timeout", "message": "remote outcome unknown; retry will reconcile, not recreate",
                                 **intent_dict(i)}, status=504)
        i.external_ref, i.status = i.remote_ref, "confirmed"
        i.save()
        audit(request.user, "intent.confirm", "intent", i.id, external_ref=i.external_ref, mode=i.mode)
    return Response(intent_dict(i))
