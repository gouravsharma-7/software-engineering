<script setup>
import { ref, reactive, onMounted } from 'vue'
import { api, session, newKey } from './api.js'

const user = ref(null)
const tab = ref('dashboard')
const msg = ref('')
const err = ref('')
const login = reactive({ username: 'faculty1', password: '' })
const dash = ref(null)
const facilities = ref([])
const bookings = ref([])
const tickets = ref([])
const approvals = ref([])
const intents = ref([])
const audit = ref([])
const techs = ref([])
const instance = ref('')
const bk = reactive({ facility: '', start: '', end: '', purpose: '' })
const sens = reactive({ source: 'ac-lab-1', event_id: '', facility: '', metric: 'temperature', value: 41 })
const note = reactive({})

const ROLE_TABS = {
  admin: ['dashboard', 'bookings', 'tickets', 'sensors', 'approvals', 'integration', 'audit'],
  manager: ['dashboard', 'bookings', 'tickets', 'sensors', 'approvals', 'integration', 'audit'],
  technician: ['dashboard', 'tickets', 'sensors', 'approvals', 'integration'],
  approver: ['dashboard', 'bookings', 'approvals'],
  faculty: ['dashboard', 'bookings', 'tickets'],
  student: ['dashboard', 'bookings'],
}

async function run(fn) {
  err.value = ''; msg.value = ''
  try { await fn() } catch (e) { err.value = `${e.status || ''} ${e.code || ''} ${e.message}`.trim() }
}

async function doLogin() {
  await run(async () => {
    const { data } = await api('POST', '/auth/login/', login)
    session.set(data.token); user.value = data
    localStorage.setItem('u', JSON.stringify({ username: data.username, role: data.role }))
    await refresh()
  })
}
function logout() { session.set(''); localStorage.removeItem('u'); user.value = null }

async function refresh() {
  const get = async (p) => { const r = await api('GET', p); instance.value = r.instance; return r.data }
  dash.value = await get('/dashboard/')
  facilities.value = await get('/facilities/')
  bookings.value = await get('/bookings/')
  tickets.value = await get('/tickets/')
  approvals.value = await get('/approvals/')
  intents.value = await get('/integrations/intents/')
  techs.value = await get('/technicians/')
  if (['admin', 'manager'].includes(user.value.role)) audit.value = await get('/audit/')
}

const toIso = (v) => (v ? new Date(v).toISOString() : '')
const submitBooking = () => run(async () => {
  const { status, data } = await api('POST', '/bookings/', {
    facility: Number(bk.facility), start_at: toIso(bk.start), end_at: toIso(bk.end),
    purpose: bk.purpose, request_key: newKey(),
  })
  msg.value = `Booking ${data.id} ${status === 201 ? 'created' : 'replayed'} (${data.status})`
  await refresh()
})
const moveBooking = (b, target) => run(async () => {
  await api('POST', `/bookings/${b.id}/transition/`, { target, expected_version: b.version })
  await refresh()
})
const nextTicket = { NEW: 'ASSIGNED', ASSIGNED: 'INSPECTION', INSPECTION: 'IN_PROGRESS', IN_PROGRESS: 'RESOLVED', RESOLVED: 'CLOSED' }
const advance = (t) => run(async () => {
  const n = note[t.id] || {}
  const body = { state: nextTicket[t.state], expected_version: t.version }
  if (body.state === 'ASSIGNED') body.assignee_id = Number(n.assignee)
  if (body.state === 'INSPECTION') body.inspection_notes = n.text
  if (body.state === 'RESOLVED') body.resolution_notes = n.text
  await api('PATCH', `/tickets/${t.id}/state/`, body)
  await refresh()
})
const sendSensor = () => run(async () => {
  const { status, data } = await api('POST', '/sensor-events/', {
    ...sens, facility: Number(sens.facility), event_id: sens.event_id || newKey().slice(0, 8),
    value: Number(sens.value), observed_at: new Date().toISOString(),
  })
  msg.value = data.duplicate ? `Duplicate event ignored; existing ticket ${data.ticket_id}` : `Event stored; ticket ${data.ticket_id ?? 'none (below threshold)'}`
  await refresh()
})
const decide = (a, decision) => run(async () => {
  await api('POST', `/approvals/${a.id}/decide/`, { decision, reason: note['a' + a.id]?.text || '' })
  await refresh()
})
const requestChange = (t) => run(async () => {
  await api('POST', '/approvals/', { ticket: t.id, reason: note['c' + t.id]?.text || '' })
  await refresh()
})
const linkIssue = (t) => run(async () => {
  await api('POST', '/integrations/intents/', { ticket: t.id, purpose: 'deploy-check', correlation_key: `ticket-${t.id}-deploy` })
  await refresh()
})
const dispatch = (i, simulate) => run(async () => {
  const { data } = await api('POST', `/integrations/intents/${i.id}/dispatch/`, { simulate_timeout: simulate })
  msg.value = `Linked issue ${data.external_ref} (${data.mode} mode)`
  await refresh()
})
onMounted(() => {
  const saved = JSON.parse(localStorage.getItem('u') || 'null')
  if (session.token && saved) run(async () => { user.value = saved; await refresh() })
})
</script>

<template>
  <main>
    <h1>Smart Campus Facility and Maintenance Platform</h1>
    <section v-if="!user" class="box">
      <h2>Sign in</h2>
      <label>User <input v-model="login.username" /></label>
      <label>Password <input type="password" v-model="login.password" /></label>
      <button @click="doLogin">Sign in</button>
      <p class="note">Demo users: admin, manager1, tech1, tech2, approver1, faculty1, student1. The password is set in your local .env.</p>
    </section>

    <template v-else>
      <header>
        <span>{{ user.username }} ({{ user.role }})</span>
        <span>Served by instance: {{ instance }}</span>
        <button @click="logout">Sign out</button>
      </header>
      <nav><button v-for="t in ROLE_TABS[user.role]" :key="t" :class="{ on: tab === t }" @click="tab = t">{{ t }}</button></nav>
      <p v-if="msg" class="ok">{{ msg }}</p>
      <p v-if="err" class="bad">Rejected: {{ err }}</p>

      <section v-if="tab === 'dashboard' && dash" class="box">
        <h2>Operations dashboard</h2>
        <p class="note">{{ dash.note }}</p>
        <table>
          <tr><th>Facilities</th><td>{{ dash.facilities }}</td><th>Active bookings</th><td>{{ dash.bookings_active }}</td></tr>
          <tr><th>Pending approval</th><td>{{ dash.bookings_pending_approval }}</td><th>Sensor events</th><td>{{ dash.sensor_events }}</td></tr>
          <tr><th>SLA breached</th><td>{{ dash.sla_breached }}</td><th>SLA at risk</th><td>{{ dash.sla_at_risk }}</td></tr>
        </table>
        <h3>Tickets by state</h3>
        <table><tr><th v-for="(n, s) in dash.tickets_by_state" :key="s">{{ s }}</th></tr><tr><td v-for="(n, s) in dash.tickets_by_state" :key="s">{{ n }}</td></tr></table>
        <h3>Facility catalogue</h3>
        <table><tr><th>Name</th><th>Kind</th><th>Capacity</th><th>Restricted</th></tr>
          <tr v-for="f in facilities" :key="f.id"><td>{{ f.name }}</td><td>{{ f.kind }}</td><td>{{ f.capacity }}</td><td>{{ f.restricted ? 'yes' : 'no' }}</td></tr></table>
      </section>

      <section v-if="tab === 'bookings'" class="box">
        <h2>Booking calendar</h2>
        <label>Facility <select v-model="bk.facility"><option v-for="f in facilities" :key="f.id" :value="f.id">{{ f.name }}</option></select></label>
        <label>Start <input type="datetime-local" v-model="bk.start" /></label>
        <label>End <input type="datetime-local" v-model="bk.end" /></label>
        <label>Purpose <input v-model="bk.purpose" /></label>
        <button @click="submitBooking">Submit booking</button>
        <table><tr><th>ID</th><th>Facility</th><th>Start</th><th>End</th><th>By</th><th>Status</th><th>v</th><th>Actions</th></tr>
          <tr v-for="b in bookings" :key="b.id">
            <td>{{ b.id }}</td><td>{{ b.facility_name }}</td><td>{{ b.start_at }}</td><td>{{ b.end_at }}</td><td>{{ b.requester }}</td><td>{{ b.status }}</td><td>{{ b.version }}</td>
            <td>
              <button v-if="b.status === 'approved'" @click="moveBooking(b, 'confirmed')">Confirm</button>
              <button v-if="b.status === 'confirmed'" @click="moveBooking(b, 'in_use')">Start use</button>
              <button v-if="b.status === 'in_use'" @click="moveBooking(b, 'completed')">Complete</button>
              <button v-if="['requested', 'approved', 'confirmed'].includes(b.status)" @click="moveBooking(b, 'cancelled')">Cancel</button>
            </td></tr></table>
      </section>

      <section v-if="tab === 'tickets'" class="box">
        <h2>Maintenance queue</h2>
        <table><tr><th>ID</th><th>Title</th><th>Priority</th><th>State</th><th>SLA</th><th>Assignee</th><th>Why this priority</th><th>Action</th></tr>
          <tr v-for="t in tickets" :key="t.id">
            <td>{{ t.id }}</td><td>{{ t.title }}</td><td>{{ t.priority }}</td><td>{{ t.state }} (v{{ t.version }})</td><td>{{ t.sla_status }}</td><td>{{ t.assignee || '-' }}</td>
            <td><ul><li v-for="(w, i) in t.explanation" :key="i">{{ w }}</li></ul></td>
            <td v-if="t.state !== 'CLOSED'">
              <select v-if="t.state === 'NEW'" v-model="(note[t.id] ??= {}).assignee"><option v-for="x in techs" :key="x.id" :value="x.id">{{ x.username }}</option></select>
              <input v-if="['ASSIGNED', 'IN_PROGRESS'].includes(t.state)" placeholder="notes" v-model="(note[t.id] ??= {}).text" />
              <button @click="advance(t)">Move to {{ nextTicket[t.state] }}</button>
              <template v-if="t.state === 'INSPECTION'">
                <input placeholder="change reason" v-model="(note['c' + t.id] ??= {}).text" />
                <button @click="requestChange(t)">Request change approval</button>
              </template>
              <button v-if="t.state === 'RESOLVED'" @click="linkIssue(t)">Link developer issue</button>
            </td><td v-else>closed</td></tr></table>
      </section>

      <section v-if="tab === 'sensors'" class="box">
        <h2>Sensor intake (controlled input)</h2>
        <label>Facility <select v-model="sens.facility"><option v-for="f in facilities" :key="f.id" :value="f.id">{{ f.name }}</option></select></label>
        <label>Source <input v-model="sens.source" /></label>
        <label>Event ID <input v-model="sens.event_id" placeholder="reuse an ID to test duplicates" /></label>
        <label>Metric <select v-model="sens.metric"><option>temperature</option><option>humidity</option><option>power_kw</option></select></label>
        <label>Value <input type="number" v-model="sens.value" /></label>
        <button @click="sendSensor">Send event</button>
        <p class="note">Thresholds: temperature 30, humidity 75, power_kw 15 (synthetic assumptions).</p>
      </section>

      <section v-if="tab === 'approvals'" class="box">
        <h2>Approvals</h2>
        <table><tr><th>ID</th><th>Kind</th><th>Ref</th><th>Status</th><th>Reason</th><th>Decision</th></tr>
          <tr v-for="a in approvals" :key="a.id"><td>{{ a.id }}</td><td>{{ a.kind }}</td><td>{{ a.booking ? 'booking ' + a.booking : 'ticket ' + a.ticket }}</td><td>{{ a.status }}</td><td>{{ a.reason }}</td>
            <td v-if="a.status === 'pending'">
              <input placeholder="reason (required)" v-model="(note['a' + a.id] ??= {}).text" />
              <button @click="decide(a, 'approved')">Approve</button><button @click="decide(a, 'rejected')">Reject</button>
            </td><td v-else>-</td></tr></table>
        <p class="note">The buttons are always shown so that server-side refusal (HTTP 403) can be demonstrated for unauthorised roles.</p>
      </section>

      <section v-if="tab === 'integration'" class="box">
        <h2>DevOps integration hub (SIMULATED tracker)</h2>
        <table><tr><th>ID</th><th>Ticket</th><th>Purpose</th><th>Status</th><th>Mode</th><th>External ref</th><th>Attempts</th><th>Remote creations</th><th>Action</th></tr>
          <tr v-for="i in intents" :key="i.id"><td>{{ i.id }}</td><td>{{ i.ticket }}</td><td>{{ i.purpose }}</td><td>{{ i.status }}</td><td>{{ i.mode }}</td><td>{{ i.external_ref || '-' }}</td><td>{{ i.attempts }}</td><td>{{ i.remote_creations }}</td>
            <td v-if="i.status !== 'confirmed'"><button @click="dispatch(i, false)">Dispatch</button><button @click="dispatch(i, true)">Dispatch with simulated timeout</button></td><td v-else>done</td></tr></table>
      </section>

      <section v-if="tab === 'audit'" class="box">
        <h2>Audit history (append-only)</h2>
        <table><tr><th>ID</th><th>Actor</th><th>Action</th><th>Entity</th><th>Detail</th><th>At</th></tr>
          <tr v-for="a in audit" :key="a.id"><td>{{ a.id }}</td><td>{{ a.actor }}</td><td>{{ a.action }}</td><td>{{ a.entity }} {{ a.entity_id }}</td><td>{{ JSON.stringify(a.detail) }}</td><td>{{ a.at }}</td></tr></table>
      </section>
    </template>
  </main>
</template>

<style>
body { font-family: "Times New Roman", Times, serif; background: #fff; color: #000; margin: 0; }
main { max-width: 1100px; margin: 0 auto; padding: 16px; }
h1 { font-size: 1.5rem; border-bottom: 2px solid #000; }
.box { border: 1px solid #000; padding: 12px; margin: 12px 0; }
header { display: flex; gap: 16px; align-items: center; justify-content: space-between; }
nav button.on { background: #000; color: #fff; }
button, input, select { font-family: inherit; border: 1px solid #000; background: #fff; color: #000; padding: 3px 8px; margin: 2px; }
button { cursor: pointer; }
label { display: inline-block; margin-right: 12px; }
table { border-collapse: collapse; width: 100%; margin-top: 8px; }
th, td { border: 1px solid #000; padding: 4px 6px; text-align: left; vertical-align: top; font-size: 0.9rem; }
th { background: #eee; }
.ok { border-left: 4px solid #000; padding-left: 8px; }
.bad { border: 2px solid #000; padding: 6px; font-weight: bold; }
.note { font-style: italic; font-size: 0.85rem; }
ul { margin: 0; padding-left: 16px; }
</style>
