// Single place where the interface talks to the backend. Every call maps to an implemented endpoint.
let token = localStorage.getItem('token') || ''

export const session = {
  get token() { return token },
  set(t) { token = t; t ? localStorage.setItem('token', t) : localStorage.removeItem('token') },
}

export async function api(method, path, body) {
  const res = await fetch('/api' + path, {
    method,
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Token ' + token } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  })
  const data = await res.json().catch(() => null)
  if (!res.ok) {
    // Surface server rejections verbatim instead of silently changing visible state.
    const err = new Error(data?.message || data?.detail || `HTTP ${res.status}`)
    err.status = res.status
    err.code = data?.code
    throw err
  }
  return { status: res.status, data, instance: res.headers.get('X-Instance') }
}

export const newKey = () => crypto.randomUUID()
