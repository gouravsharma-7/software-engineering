#!/usr/bin/env bash
# Reproduces the Q4 Git evidence (two feature branches, review request, deliberate conflict, tag).
# Run ONCE from the repository root after the first commit on main, with your own git identity set:
#   git config user.name "Your Name"; git config user.email "you@example.com"
set -euo pipefail
FILE=backend/ops/policy.py

git switch main
git switch -c feature/booking-length-policy
sed -i 's/^MAX_BOOKING_HOURS = .*/MAX_BOOKING_HOURS = 3/' $FILE
git commit -am "feat: tighten maximum booking length to 3 hours"

git switch main
git switch -c feature/approval-controls
sed -i 's/^MAX_BOOKING_HOURS = .*/MAX_BOOKING_HOURS = 6/' $FILE
git commit -am "feat: allow 6 hour bookings for approved events"

git switch main
git merge --no-ff feature/booking-length-policy -m "merge: booking length policy"
echo ">>> Next merge is EXPECTED to conflict in $FILE (deliberate exercise)."
git merge --no-ff feature/approval-controls -m "merge: approval controls" || true
git status --short

cat <<'EOF'

Resolve the conflict: open backend/ops/policy.py, compare both values against the approved policy
(4 hours), delete the <<<<<<< ======= >>>>>>> markers and keep MAX_BOOKING_HOURS = 4. Then run:

  git add backend/ops/policy.py
  git commit -m "merge: resolve booking length conflict (approved policy = 4 hours)"
  git tag -a v1.0.0 -m "Campus platform core release"
  git log --oneline --graph --all

To undo an unsuitable change without erasing history:  git revert <commit>
To redeploy the stable release:                        git checkout v1.0.0
EOF
