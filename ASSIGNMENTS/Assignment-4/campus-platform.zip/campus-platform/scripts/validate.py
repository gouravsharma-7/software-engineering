#!/usr/bin/env python3
"""Evidence runner against a RUNNING stack (standard library only).

    SEED_PASSWORD=... python scripts/validate.py http://localhost:3000

Prints observed results; paste them into the report's evidence tables. Nothing here is
a claim until you have run it on your own machine.
"""
import json
import statistics
import sys
import threading
import time
import urllib.error
import urllib.request
import os
import uuid
from datetime import datetime, timedelta, timezone

BASE = (sys.argv[1] if len(sys.argv) > 1 else "http://localhost:3000").rstrip("/")
PW = os.environ.get("SEED_PASSWORD", "")


def call(method, path, body=None, token=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body is not None else None)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", f"Token {token}")
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return r.status, json.loads(r.read() or b"null"), r.headers.get("X-Instance")
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"null"), e.headers.get("X-Instance")


def login(u):
    s, b, _ = call("POST", "/api/auth/login/", {"username": u, "password": PW})
    assert s == 200, f"login failed for {u}: {s} {b}"
    return b["token"]


def par(fn, args_list):
    out, bar = [None] * len(args_list), threading.Barrier(len(args_list))

    def run(i, a):
        bar.wait()
        out[i] = fn(*a)
    ts = [threading.Thread(target=run, args=(i, a)) for i, a in enumerate(args_list)]
    [t.start() for t in ts]
    [t.join() for t in ts]
    return out


def main():
    tok = {u: login(u) for u in ("faculty1", "student1", "manager1", "tech1", "tech2", "approver1")}
    facs = call("GET", "/api/facilities/", token=tok["manager1"])[1]
    fac = next(f for f in facs if not f["restricted"])
    day = datetime.now(timezone.utc).replace(hour=9, minute=0, second=0, microsecond=0) + timedelta(days=30 + int(time.time()) % 300)
    s, e = day, day + timedelta(hours=2)
    run = uuid.uuid4().hex[:8]

    print("== 1. Two simultaneous overlapping reservations (same laboratory)")
    mk = lambda who, k: call("POST", "/api/bookings/", {"facility": fac["id"], "start_at": s.isoformat(), "end_at": e.isoformat(),
                                                        "purpose": "validate", "request_key": f"{run}-{k}"}, tok[who])
    r = par(mk, [("faculty1", "a"), ("student1", "b")])
    print("   statuses:", sorted(x[0] for x in r), "| instances:", {x[2] for x in r}, "(expect [201, 409])")

    print("== 2. Booking retry with the same request_key")
    r1, r2 = mk("faculty1", "retry-x"), mk("faculty1", "retry-x")
    print("   statuses:", r1[0], r2[0], "(expect 409 or 201 then 200 - slot already taken => 409 for both is also valid)")

    print("== 3. Sensor event replayed 5 times")
    sens = {"source": f"ac-{run}", "event_id": "evt-1", "facility": fac["id"], "metric": "temperature", "value": 41,
            "observed_at": datetime.now(timezone.utc).isoformat()}
    codes = [call("POST", "/api/sensor-events/", sens, tok["manager1"]) for _ in range(5)]
    print("   statuses:", [c[0] for c in codes], "ticket ids:", {c[1].get("ticket_id") for c in codes}, "(expect one ticket id)")
    tid = codes[0][1]["ticket_id"]

    print("== 4. Two technicians/managers update the same ticket version at once")
    techs = call("GET", "/api/technicians/", token=tok["manager1"])[1]
    patch = lambda tech: call("PATCH", f"/api/tickets/{tid}/state/", {"state": "ASSIGNED", "expected_version": 1,
                                                                      "assignee_id": tech["id"]}, tok["manager1"])
    r = par(patch, [(techs[0],), (techs[1],)])
    print("   statuses:", sorted(x[0] for x in r), "(expect [200, 409])")

    print("== 5. Idempotent integration intent + timeout + reconcile")
    key = f"cor-{run}"
    _, intent, _ = call("POST", "/api/integrations/intents/", {"ticket": tid, "purpose": "deploy-check", "correlation_key": key}, tok["manager1"])
    a = call("POST", f"/api/integrations/intents/{intent['id']}/dispatch/", {"simulate_timeout": True}, tok["manager1"])
    b = call("POST", f"/api/integrations/intents/{intent['id']}/dispatch/", {}, tok["manager1"])
    print("   dispatch statuses:", a[0], b[0], "remote_creations:", b[1]["remote_creations"], "(expect 504, 200, 1)")

    print("== 6. Stepped load (GET /api/dashboard/ + GET /api/tickets/), bounded")
    for users in (10, 25, 50):
        lat, errs = [], 0

        def worker():
            nonlocal errs
            for _ in range(5):
                t0 = time.perf_counter()
                st = call("GET", "/api/dashboard/", token=tok["manager1"])[0]
                lat.append((time.perf_counter() - t0) * 1000)
                errs += st != 200
        t0 = time.perf_counter()
        ts = [threading.Thread(target=worker) for _ in range(users)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        wall = time.perf_counter() - t0
        lat.sort()
        print(f"   {users:>3} concurrent clients: {len(lat)} requests, errors={errs}, "
              f"median={statistics.median(lat):.0f} ms, p95={lat[int(len(lat) * .95) - 1]:.0f} ms, wall={wall:.1f}s")
    print("   NOTE: this bounded test does NOT prove 300 simultaneous users.")


if __name__ == "__main__":
    main()
