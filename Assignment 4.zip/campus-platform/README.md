# Smart Campus Facility Platform – Testing and DevOps (CSA10 Assignment 4)

Representative booking + maintenance service (Flask, SQLite) with layered tests, a GitHub Actions
pipeline, Docker packaging, migration/recovery rehearsal and controlled-defect tooling.

## Run tests
    pip install -r requirements-dev.txt
    python -m pytest                       # or: python -m unittest discover -s tests -v
    python scripts/recovery_rehearsal.py   # migration failure + restore gate

## Run the service and checks
    TOKEN_SALT=changeme123 python -m campus.app            # port 8000
    TOKEN_SALT=changeme123 python scripts/smoke_test.py http://localhost:8000
    TOKEN_SALT=changeme123 python scripts/load_test.py http://localhost:8000 20

## Docker
    cp .env.example .env && docker build -t campus-backend:dev .
    docker compose up -d --wait

## Controlled defects (blocked pipeline demo)
    git checkout -b defect/threshold
    python scripts/inject_defect.py gte      # also: overlap, auth, dedupe, matrix
    git commit -am "inject defect" && git push -u origin defect/threshold
    # expect: test job fails; package and deploy-test are skipped
    python scripts/inject_defect.py --revert

## Migration
    python scripts/migrate.py campus.db --backup-dir backups      # add --inject-failure to rehearse failure

Seed tokens are synthetic (`<role>-<TOKEN_SALT>`) and for isolated test use only. Never commit `.env`.
