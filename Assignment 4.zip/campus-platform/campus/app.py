import os
from functools import wraps
from flask import Flask, jsonify, request
from . import db, seed as seeding
from .integrations import FakeTracker
from .service import Service, ServiceError, Unauthorized

APP_VERSION = os.environ.get("APP_VERSION", "dev")


def create_app(db_path=None, tracker=None, clock=None, salt=None):
    app = Flask(__name__)
    db_path = db_path or os.environ.get("DB_PATH", "campus.db")
    db.init_db(db_path)
    salt = salt or os.environ.get("TOKEN_SALT", "")
    if salt:
        seeding.seed(db_path, salt)
    svc = Service(db_path, tracker or FakeTracker(), clock)
    app.svc = svc

    @app.errorhandler(ServiceError)
    def handle(err):
        return jsonify(error=str(err)), err.status

    def auth(fn):
        @wraps(fn)
        def wrapper(*a, **kw):
            head = request.headers.get("Authorization", "")
            if not head.startswith("Bearer "):
                raise Unauthorized("missing token")
            return fn(svc.user_by_token(head[7:]), *a, **kw)   # role from DB, never payload
        return wrapper

    def body():
        return request.get_json(silent=True) or {}

    @app.get("/health")
    def health():
        return jsonify(status="ok", version=APP_VERSION)

    @app.get("/ready")
    def ready():
        conn = db.connect(db_path)
        try:
            return jsonify(status="ready", schema=db.schema_version(conn), version=APP_VERSION)
        finally:
            conn.close()

    # ---- booking API v1 (kept during transition) and v2 (revised) ----
    @app.post("/api/v1/bookings")
    @auth
    def book_v1(user):
        b = body()
        bid = svc.request_booking(user, b.get("facility_id"), b.get("start"), b.get("end"))
        return jsonify(id=bid, status="Pending"), 201

    @app.post("/api/v2/bookings")
    @auth
    def book_v2(user):
        b = body()
        bid = svc.request_booking(user, b.get("facility_id"), b.get("starts_at"), b.get("ends_at"))
        return jsonify(api_version="v2", data=svc.get_booking(user, bid)), 201

    @app.get("/api/v1/bookings/<int:bid>")
    @auth
    def get_book_v1(user, bid):
        r = svc.get_booking(user, bid)
        return jsonify(id=r["id"], facility=r["facility"], start=r["start_ts"],
                       end=r["end_ts"], status=r["status"])

    @app.get("/api/v2/bookings/<int:bid>")
    @auth
    def get_book_v2(user, bid):
        return jsonify(api_version="v2", data=svc.get_booking(user, bid))

    @app.post("/api/v1/bookings/<int:bid>/approve")
    @auth
    def approve(user, bid):
        svc.approve_booking(user, bid)         # any 'role' in the payload is ignored
        return jsonify(id=bid, status="Approved")

    # ---- sensors and tickets ----
    @app.post("/api/v1/sensor-events")
    @auth
    def sensor(user):
        b = body()
        res = svc.ingest_sensor(user, b.get("source"), b.get("event_id"), b.get("sensor"),
                                b.get("value"), b.get("campus", "DEFAULT"), b.get("text", ""))
        if res.get("breach"):
            svc.sync_outbox()
        return jsonify(res), (201 if res.get("created") else 200)

    @app.post("/api/v1/tickets")
    @auth
    def new_ticket(user):
        b = body()
        tid, created = svc.create_ticket(user, b.get("title"), b.get("impact"), b.get("urgency"),
                                         b.get("description", ""))
        svc.sync_outbox()
        return jsonify(id=tid), 201

    @app.get("/api/v1/tickets/<int:tid>")
    @auth
    def get_ticket(user, tid):
        return jsonify(svc.get_ticket(user, tid))

    @app.post("/api/v1/tickets/<int:tid>/transition")
    @auth
    def transition(user, tid):
        b = body()
        v = svc.transition(user, tid, b.get("target"), b.get("expected_version"), b.get("notes"))
        return jsonify(id=tid, version=v)

    @app.post("/api/v1/sync/run")
    @auth
    def sync(user):
        if user["role"] not in ("technician", "manager", "admin"):
            from .service import Forbidden
            raise Forbidden("role not permitted")
        return jsonify(svc.sync_outbox())

    return app


if __name__ == "__main__":
    create_app().run(host="0.0.0.0", port=int(os.environ.get("PORT", "8000")), threaded=True)  # nosec B104 - container bind
