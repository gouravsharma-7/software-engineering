import sqlite3

SCHEMA_V1 = """
CREATE TABLE IF NOT EXISTS meta(key TEXT PRIMARY KEY, value TEXT);
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY, token TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL, role TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS facilities(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL,
  restricted INTEGER NOT NULL DEFAULT 0, campus TEXT NOT NULL DEFAULT 'DEFAULT');
CREATE TABLE IF NOT EXISTS bookings(id INTEGER PRIMARY KEY, facility_id INTEGER NOT NULL
  REFERENCES facilities(id), user_id INTEGER NOT NULL REFERENCES users(id),
  start_ts TEXT NOT NULL, end_ts TEXT NOT NULL, status TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY, title TEXT NOT NULL,
  priority TEXT NOT NULL, category TEXT NOT NULL, state TEXT NOT NULL,
  version INTEGER NOT NULL, notes TEXT, source TEXT, event_id TEXT, sla_due TEXT NOT NULL,
  remote_id TEXT, UNIQUE(source, event_id));
CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY, entity TEXT NOT NULL,
  entity_id INTEGER NOT NULL, from_state TEXT, to_state TEXT, actor TEXT, at TEXT);
CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY, intent_key TEXT UNIQUE NOT NULL,
  ticket_id INTEGER NOT NULL, status TEXT NOT NULL, attempts INTEGER NOT NULL DEFAULT 0,
  next_retry TEXT NOT NULL);
"""


def connect(path):
    conn = sqlite3.connect(path, timeout=15, isolation_level=None)  # explicit transactions
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(path):
    conn = connect(path)
    conn.executescript(SCHEMA_V1)
    conn.execute("INSERT OR IGNORE INTO meta VALUES('schema_version','1')")
    conn.close()


def schema_version(conn):
    return int(conn.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()[0])


def counts(conn):
    return {t: conn.execute("SELECT COUNT(*) FROM %s" % t).fetchone()[0]  # nosec B608 fixed table names
            for t in ("bookings", "tickets", "audit", "users", "facilities")}


def migrate_to_v2(path, fail_after_backfill=False):
    """Expand step of expand-and-contract. One transaction: any failure rolls
    back the DDL and data changes. Returns (before_counts, after_counts)."""
    conn = connect(path)
    try:
        if schema_version(conn) >= 2:
            c = counts(conn)
            return c, c                                  # idempotent
        before = counts(conn)
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("ALTER TABLE bookings ADD COLUMN policy_version TEXT NOT NULL DEFAULT 'v1'")
        conn.execute("ALTER TABLE bookings ADD COLUMN campus_code TEXT NOT NULL DEFAULT 'DEFAULT'")
        conn.execute("ALTER TABLE tickets ADD COLUMN policy_version TEXT NOT NULL DEFAULT 'v1'")
        conn.execute("ALTER TABLE tickets ADD COLUMN campus_code TEXT NOT NULL DEFAULT 'DEFAULT'")
        conn.execute("UPDATE bookings SET campus_code=(SELECT campus FROM facilities "
                     "WHERE facilities.id=bookings.facility_id)")
        if fail_after_backfill:
            raise RuntimeError("injected migration failure")
        after = counts(conn)
        if after != before:
            raise RuntimeError("row counts changed: %s -> %s" % (before, after))
        bad = conn.execute("SELECT COUNT(*) FROM bookings WHERE campus_code IS NULL").fetchone()[0]
        if bad:
            raise RuntimeError("backfill left NULL campus codes")
        conn.execute("UPDATE meta SET value='2' WHERE key='schema_version'")
        conn.execute("COMMIT")
        return before, after
    except Exception:
        if conn.in_transaction:
            conn.execute("ROLLBACK")
        raise
    finally:
        conn.close()
