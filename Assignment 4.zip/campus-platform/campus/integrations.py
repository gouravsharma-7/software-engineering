"""External issue-tracker adapter. The fake is idempotent on intent_key, like a
real tracker called with an idempotency key, and can simulate outages."""


class TrackerUnavailable(Exception):
    pass


class FakeTracker:
    def __init__(self):
        self.available = True
        self.fail_after_create = False   # simulates a timeout AFTER the remote write
        self.issues = {}

    def create_issue(self, intent_key, title):
        if not self.available:
            raise TrackerUnavailable("tracker down")
        if intent_key not in self.issues:
            self.issues[intent_key] = {"id": "GH-%d" % (len(self.issues) + 1), "title": title}
        if self.fail_after_create:
            raise TrackerUnavailable("timeout after create")
        return self.issues[intent_key]["id"]
