"""Pure business rules: no I/O, so they are cheap to unit test."""
import re
from datetime import datetime, timedelta, timezone

MATRIX = {("High", "High"): "M1", ("High", "Medium"): "M2", ("High", "Low"): "M3",
          ("Medium", "High"): "M2", ("Medium", "Medium"): "M3", ("Medium", "Low"): "M4",
          ("Low", "High"): "M3", ("Low", "Medium"): "M4", ("Low", "Low"): "M4"}
KEYWORDS = {"Facilities": ["leak", "flood", "ceiling", "door", "lock"],
            "HVAC": ["ac", "compressor", "temperature", "cooling"],
            "AV-Network": ["projector", "display", "wifi", "network"]}
SLA_HOURS = {"M1": 4, "M2": 8, "M3": 24, "M4": 72}
TRANSITIONS = {"New": ["Assigned"], "Assigned": ["In Progress"],
               "In Progress": ["Resolved"], "Resolved": ["Closed"], "Closed": []}
STAFF = {"technician", "manager", "admin"}
READERS = {"technician", "manager", "admin", "approver"}
APPROVERS = {"approver", "manager", "admin"}
RESTRICTED_APPROVERS = {"manager", "admin"}
# Versioned, campus-specific policy (Task 6). v1 = single policy; v2 = per campus.
POLICIES = {
    "v1": {"DEFAULT": {"max_minutes": 180, "temp_limit": 28.0}},
    "v2": {"DEFAULT": {"max_minutes": 180, "temp_limit": 28.0},
           "MAIN": {"max_minutes": 240, "temp_limit": 30.0},
           "ANNEX": {"max_minutes": 120, "temp_limit": 26.0}},
}


def get_policy(version, campus):
    table = POLICIES[version]
    return table.get(campus, table["DEFAULT"])


def priority(impact, urgency):
    if (impact, urgency) not in MATRIX:
        raise ValueError("invalid impact/urgency")
    return MATRIX[(impact, urgency)]


def classify(text):
    words = re.findall(r"[a-z0-9]+", (text or "").lower())
    scores = {c: sum(1 for w in words if w in kws) for c, kws in KEYWORDS.items()}
    best = max(scores.values())
    top = [c for c, s in scores.items() if s == best]
    return "Manual Review" if best == 0 or len(top) != 1 else top[0]


def breached(value, limit):
    return value > limit            # strict: equality is NOT a breach


def valid_duration(minutes, max_minutes):
    return 0 < minutes <= max_minutes


def overlaps(s1, e1, s2, e2):
    return s1 < e2 and s2 < e1      # half-open: back-to-back is allowed


def parse_ts(value):
    """Parse an ISO-8601 timestamp; must carry a timezone. Returns UTC."""
    if not isinstance(value, str):
        raise ValueError("timestamp must be a string")
    dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if dt.tzinfo is None:
        raise ValueError("timestamp needs a timezone")
    return dt.astimezone(timezone.utc)


def iso(dt):
    return dt.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S+00:00")


def sla_due(created, prio):
    return created + timedelta(hours=SLA_HOURS[prio])


def is_overdue(now, due):
    return now > due                # exactly at the deadline is not overdue
