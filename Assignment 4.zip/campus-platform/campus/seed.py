from . import db

ROLES = ["admin", "manager", "technician", "approver", "faculty", "student"]


def tokens(salt):
    return {r: "%s-%s" % (r, salt) for r in ROLES}


def seed(path, salt):
    if len(salt) < 8:
        raise ValueError("TOKEN_SALT must be at least 8 characters")
    conn = db.connect(path)
    for i, (role, tok) in enumerate(tokens(salt).items(), 1):
        conn.execute("INSERT OR IGNORE INTO users(id,token,name,role) VALUES(?,?,?,?)",
                     (i, tok, role.title() + " User", role))
    conn.execute("INSERT OR IGNORE INTO users(id,token,name,role) VALUES(7,?,?,?)",
                 ("student2-" + salt, "Student Two", "student"))
    for fid, name, restricted, campus in [(1, "Lab-204", 1, "MAIN"), (2, "Room-101", 0, "MAIN"),
                                           (3, "Annex-3", 0, "ANNEX")]:
        conn.execute("INSERT OR IGNORE INTO facilities VALUES(?,?,?,?)", (fid, name, restricted, campus))
    conn.close()
