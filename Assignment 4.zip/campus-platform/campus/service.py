"""Command logic: authorization, persistence, audit, outbox. All rules enforced
server-side; identity always comes from the token, never from the payload."""
import sqlite3
from datetime import datetime, timezone
from . import db, rules
from .integrations import TrackerUnavailable

MAX_ATTEMPTS = 5


class ServiceError(Exception):
    status = 400


class ValidationError(ServiceError): status = 422
class Forbidden(ServiceError): status = 403
class Unauthorized(ServiceError): status = 401
class NotFound(ServiceError): status = 404
class Conflict(ServiceError): status = 409


class Service:
    def __init__(self, path, tracker, clock=None):
        self.path, self.tracker = path, tracker
        self.clock = clock or (lambda: datetime.now(timezone.utc))

    def _c(self):
        return db.connect(self.path)

    def policy_version(self, conn):
        return "v2" if db.schema_version(conn) >= 2 else "v1"

    def _audit(self, conn, entity, eid, frm, to, actor):
        conn.execute("INSERT INTO audit(entity,entity_id,from_state,to_state,actor,at) "
                     "VALUES(?,?,?,?,?,?)", (entity, eid, frm, to, actor, rules.iso(self.clock())))

    def user_by_token(self, token):
        conn = self._c()
        try:
            row = conn.execute("SELECT * FROM users WHERE token=?", (token,)).fetchone()
        finally:
            conn.close()
        if not row:
            raise Unauthorized("invalid token")
        return dict(row)

    # ---- bookings -------------------------------------------------------
    def request_booking(self, user, facility_id, start, end):
        try:
            s, e = rules.parse_ts(start), rules.parse_ts(end)
        except (ValueError, TypeError):
            raise ValidationError("start/end must be ISO-8601 with timezone")
        if e <= s:
            raise ValidationError("end must be after start")
        conn = self._c()
        try:
            fac = conn.execute("SELECT * FROM facilities WHERE id=?", (facility_id,)).fetchone()
            if not fac:
                raise NotFound("facility not found")
            pv = self.policy_version(conn)
            pol = rules.get_policy(pv, fac["campus"])
            minutes = (e - s).total_seconds() / 60
            if not rules.valid_duration(minutes, pol["max_minutes"]):
                raise ValidationError("duration outside policy (max %d min)" % pol["max_minutes"])
            conn.execute("BEGIN IMMEDIATE")          # check + insert is atomic
            clash = conn.execute("SELECT 1 FROM bookings WHERE facility_id=? AND status IN "
                                 "('Pending','Approved') AND start_ts < ? AND end_ts > ?",
                                 (facility_id, rules.iso(e), rules.iso(s))).fetchone()
            if clash:
                conn.execute("ROLLBACK")
                raise Conflict("overlapping booking")
            cols, vals = "facility_id,user_id,start_ts,end_ts,status", \
                [facility_id, user["id"], rules.iso(s), rules.iso(e), "Pending"]
            if pv == "v2":
                cols += ",policy_version,campus_code"
                vals += ["v2", fac["campus"]]
            cur = conn.execute("INSERT INTO bookings(%s) VALUES(%s)" %  # nosec B608 fixed columns
                               (cols, ",".join("?" * len(vals))), vals)
            self._audit(conn, "booking", cur.lastrowid, None, "Pending", user["name"])
            conn.execute("COMMIT")
            return cur.lastrowid
        finally:
            conn.close()

    def _booking(self, conn, bid):
        row = conn.execute("SELECT b.*, f.restricted, f.name AS facility FROM bookings b "
                           "JOIN facilities f ON f.id=b.facility_id WHERE b.id=?", (bid,)).fetchone()
        if not row:
            raise NotFound("booking not found")
        return row

    def get_booking(self, user, bid):
        conn = self._c()
        try:
            row = self._booking(conn, bid)
            if user["role"] not in rules.READERS and row["user_id"] != user["id"]:
                raise Forbidden("not permitted")
            return dict(row)
        finally:
            conn.close()

    def approve_booking(self, user, bid):
        allowed = rules.APPROVERS
        conn = self._c()
        try:
            row = self._booking(conn, bid)
            if user["role"] not in allowed:
                raise Forbidden("role not permitted")
            if row["restricted"] and user["role"] not in rules.RESTRICTED_APPROVERS:
                raise Forbidden("restricted facility needs manager or admin")
            if row["status"] != "Pending":
                raise Conflict("booking is not pending")
            conn.execute("UPDATE bookings SET status='Approved' WHERE id=?", (bid,))
            self._audit(conn, "booking", bid, "Pending", "Approved", user["name"])
        finally:
            conn.close()

    # ---- tickets --------------------------------------------------------
    def create_ticket(self, user, title, impact, urgency, description="",
                      source=None, event_id=None, campus="DEFAULT"):
        if not title or not str(title).strip():
            raise ValidationError("title required")
        try:
            prio = rules.priority(impact, urgency)
        except ValueError as ex:
            raise ValidationError(str(ex))
        conn = self._c()
        try:
            if source is not None:
                row = conn.execute("SELECT id FROM tickets WHERE source=? AND event_id=?",
                                   (source, event_id)).fetchone()
                if row:
                    return row[0], False
            now = self.clock()
            pv = self.policy_version(conn)
            cols = "title,priority,category,state,version,source,event_id,sla_due"
            vals = [title.strip(), prio, rules.classify(title + " " + description), "New", 1,
                    source, event_id, rules.iso(rules.sla_due(now, prio))]
            if pv == "v2":
                cols += ",policy_version,campus_code"
                vals += ["v2", campus]
            conn.execute("BEGIN IMMEDIATE")
            try:
                cur = conn.execute("INSERT INTO tickets(%s) VALUES(%s)" %  # nosec B608 fixed columns
                                   (cols, ",".join("?" * len(vals))), vals)
            except sqlite3.IntegrityError:           # lost a race with a duplicate event
                conn.execute("ROLLBACK")
                return conn.execute("SELECT id FROM tickets WHERE source=? AND event_id=?",
                                    (source, event_id)).fetchone()[0], False
            tid = cur.lastrowid
            self._audit(conn, "ticket", tid, None, "New", user["name"])
            conn.execute("INSERT INTO outbox(intent_key,ticket_id,status,next_retry) "
                         "VALUES(?,?,'pending',?)", ("ticket:%d" % tid, tid, rules.iso(now)))
            conn.execute("COMMIT")
            return tid, True
        finally:
            conn.close()

    def ingest_sensor(self, user, source, event_id, sensor, value, campus="DEFAULT", text=""):
        if user["role"] not in ("technician", "admin"):
            raise Forbidden("role not permitted")
        if not source or not event_id or not isinstance(value, (int, float)):
            raise ValidationError("source, event_id and numeric value required")
        conn = self._c()
        try:
            pol = rules.get_policy(self.policy_version(conn), campus)
        finally:
            conn.close()
        if not rules.breached(float(value), pol["temp_limit"]):
            return {"breach": False, "limit": pol["temp_limit"]}
        tid, created = self.create_ticket(user, "Sensor %s over limit" % sensor, "High", "Medium",
                                          text, source, event_id, campus)
        return {"breach": True, "ticket_id": tid, "created": created, "limit": pol["temp_limit"]}

    def get_ticket(self, user, tid):
        if user["role"] not in rules.READERS:
            raise Forbidden("not permitted")
        conn = self._c()
        try:
            row = conn.execute("SELECT t.*, o.status AS integration FROM tickets t LEFT JOIN "
                               "outbox o ON o.ticket_id=t.id WHERE t.id=?", (tid,)).fetchone()
            if not row:
                raise NotFound("ticket not found")
            return dict(row)
        finally:
            conn.close()

    def transition(self, user, tid, target, expected_version, notes=None):
        if user["role"] not in rules.STAFF:
            raise Forbidden("role not permitted")
        conn = self._c()
        try:
            row = conn.execute("SELECT state FROM tickets WHERE id=?", (tid,)).fetchone()
            if not row:
                raise NotFound("ticket not found")
            if target not in rules.TRANSITIONS[row["state"]]:
                raise ValidationError("invalid transition %s -> %s" % (row["state"], target))
            if target == "Resolved" and not (notes and notes.strip()):
                raise ValidationError("resolution notes required")
            conn.execute("BEGIN IMMEDIATE")
            cur = conn.execute("UPDATE tickets SET state=?, version=version+1, "
                               "notes=COALESCE(?,notes) WHERE id=? AND version=?",
                               (target, notes, tid, expected_version))
            if cur.rowcount != 1:
                conn.execute("ROLLBACK")
                raise Conflict("stale version")
            self._audit(conn, "ticket", tid, row["state"], target, user["name"])
            conn.execute("COMMIT")
            return expected_version + 1
        finally:
            conn.close()

    # ---- integration outbox --------------------------------------------
    def sync_outbox(self):
        """Deliver pending intents. Failure keeps local state and schedules a bounded retry."""
        conn = self._c()
        res = {"synced": 0, "retry": 0, "needs_operator": 0}
        try:
            now = self.clock()
            rows = conn.execute("SELECT o.*, t.title FROM outbox o JOIN tickets t ON t.id=o.ticket_id "
                                "WHERE o.status='pending' AND o.next_retry<=?", (rules.iso(now),)).fetchall()
            for r in rows:
                try:
                    remote = self.tracker.create_issue(r["intent_key"], r["title"])
                    conn.execute("UPDATE outbox SET status='synced' WHERE id=?", (r["id"],))
                    conn.execute("UPDATE tickets SET remote_id=? WHERE id=?", (remote, r["ticket_id"]))
                    res["synced"] += 1
                except TrackerUnavailable:
                    n = r["attempts"] + 1
                    if n >= MAX_ATTEMPTS:
                        conn.execute("UPDATE outbox SET status='needs_operator', attempts=? WHERE id=?",
                                     (n, r["id"]))
                        res["needs_operator"] += 1
                    else:
                        from datetime import timedelta
                        nxt = rules.iso(now + timedelta(minutes=2 ** n))
                        conn.execute("UPDATE outbox SET attempts=?, next_retry=? WHERE id=?",
                                     (n, nxt, r["id"]))
                        res["retry"] += 1
            return res
        finally:
            conn.close()
