"""Usage: backup.py backup DB OUT | backup.py restore BAK DB (uses SQLite online backup API)."""
import sqlite3, sys, shutil
mode, a, b = sys.argv[1:4]
if mode == "backup":
    src, dst = sqlite3.connect(a), sqlite3.connect(b)
    src.backup(dst); src.close(); dst.close(); print("backup written", b)
elif mode == "restore":
    shutil.copy(a, b); print("restored", b)
