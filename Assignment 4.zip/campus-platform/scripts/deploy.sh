#!/usr/bin/env bash
# Deploy IMAGE_TAG to the isolated stack; roll back to the previous tag if the smoke test fails.
set -euo pipefail
NEW="${1:?usage: deploy.sh <image-tag>}"; PREV="$(cat .last_good_tag 2>/dev/null || true)"
export IMAGE_TAG="$NEW" APP_VERSION="$NEW"
docker compose up -d --wait
if EXPECT_VERSION="$NEW" python scripts/smoke_test.py http://localhost:8000; then
  echo "$NEW" > .last_good_tag; echo "deployed $NEW"
else
  echo "smoke failed; rolling back to ${PREV:-none}"
  docker compose down
  if [ -n "$PREV" ]; then export IMAGE_TAG="$PREV" APP_VERSION="$PREV"; docker compose up -d --wait; fi
  exit 1
fi
