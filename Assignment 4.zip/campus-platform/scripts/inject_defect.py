"""Controlled defects for gate demonstrations. Usage: inject_defect.py NAME | --revert"""
import shutil, sys
D = {"gte": ("campus/rules.py", "return value > limit", "return value >= limit"),
     "overlap": ("campus/rules.py", "return s1 < e2 and s2 < e1", "return s1 <= e2 and s2 <= e1"),
     "auth": ("campus/service.py", 'if row["restricted"] and user["role"] not in rules.RESTRICTED_APPROVERS:', 'if False:'),
     "dedupe": ("campus/service.py", "if row:\n                    return row[0], False", "if False:\n                    return row[0], False"),
     "matrix": ("campus/rules.py", '("High", "High"): "M1"', '("High", "High"): "M2"')}
if sys.argv[1] == "--revert":
    for f, _, _ in D.values():
        try: shutil.copy(f + ".orig", f)
        except FileNotFoundError: pass
    sys.exit(0)
f, old, new = D[sys.argv[1]]
src = open(f).read(); assert old in src, "pattern not found"
shutil.copy(f, f + ".orig"); open(f, "w").write(src.replace(old, new, 1)); print("injected", sys.argv[1], "in", f)
