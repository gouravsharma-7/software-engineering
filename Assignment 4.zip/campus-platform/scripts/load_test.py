"""Bounded load experiment over real HTTP. Usage: load_test.py BASE_URL [REQS_PER_CLIENT]
Env TOKEN_SALT. Mix per client: 40% create booking, 40% read booking, 20% sensor event."""
import json, os, platform, statistics, sys, threading, time, urllib.request, urllib.error
BASE = sys.argv[1].rstrip("/"); N = int(sys.argv[2]) if len(sys.argv) > 2 else 20; SALT = os.environ["TOKEN_SALT"]


def call(method, path, role, body=None):
    req = urllib.request.Request(BASE + path, method=method, data=json.dumps(body).encode() if body else None,
                                 headers={"Content-Type": "application/json", "Authorization": "Bearer %s-%s" % (role, SALT)})
    t = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            r.read(); code = r.status
    except urllib.error.HTTPError as e:
        code = e.code
    except Exception:
        code = 0
    return code, (time.perf_counter() - t) * 1000


def run(clients, base_id):
    lat, errors, lock = [], [0], threading.Lock()
    def client(k):
        last = None
        for i in range(N):
            slot = base_id + k * 1000 + i                 # unique non-overlapping 10-minute slots
            from datetime import datetime, timedelta
            ts = lambda m: (datetime(2031, 1, 1) + timedelta(minutes=m)).strftime("%Y-%m-%dT%H:%M:00Z")
            mm = slot * 10
            if i % 5 in (0, 1):
                code, ms = call("POST", "/api/v1/bookings", "faculty", {"facility_id": 2, "start": ts(mm), "end": ts(mm + 10)})
            elif i % 5 in (2, 3):
                code, ms = call("GET", "/api/v1/bookings/1", "admin")
            else:
                code, ms = call("POST", "/api/v1/sensor-events", "technician", {"source": "load%d" % clients, "event_id": "%d-%d" % (k, i), "sensor": "t", "value": 29.0})
            with lock:
                lat.append(ms); errors[0] += code not in (200, 201)
    t0 = time.perf_counter()
    ths = [threading.Thread(target=client, args=(k,)) for k in range(clients)]
    [t.start() for t in ths]; [t.join() for t in ths]
    dur = time.perf_counter() - t0; lat.sort()
    q = lambda p: lat[min(len(lat) - 1, int(p * len(lat)))]
    return {"clients": clients, "requests": len(lat), "errors": errors[0], "duration_s": round(dur, 2),
            "rps": round(len(lat) / dur, 1), "p50_ms": round(q(.5), 1), "p95_ms": round(q(.95), 1), "max_ms": round(lat[-1], 1)}


call("POST", "/api/v1/bookings", "faculty", {"facility_id": 2, "start": "2029-12-01T10:00:00Z", "end": "2029-12-01T10:10:00Z"})
res = [run(c, i * 100000) for i, c in enumerate((10, 25, 50), 1)]
print(json.dumps({"env": {"python": platform.python_version(), "cpus": os.cpu_count(), "os": platform.platform()}, "results": res}, indent=1))
