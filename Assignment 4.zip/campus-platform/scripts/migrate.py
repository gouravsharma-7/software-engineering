"""Usage: migrate.py DB [--backup-dir DIR] [--inject-failure]. Backs up first, migrates, validates."""
import os, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from campus import db

path = sys.argv[1]
if "--backup-dir" in sys.argv:
    import sqlite3
    d = sys.argv[sys.argv.index("--backup-dir") + 1]; os.makedirs(d, exist_ok=True)
    out = os.path.join(d, "pre-migration-%d.db" % time.time())
    s, t = sqlite3.connect(path), sqlite3.connect(out); s.backup(t); s.close(); t.close()
    print("backup:", out)
try:
    before, after = db.migrate_to_v2(path, "--inject-failure" in sys.argv)
    print("MIGRATION OK before=%s after=%s" % (before, after))
except Exception as ex:
    print("MIGRATION FAILED (rolled back):", ex); sys.exit(1)
