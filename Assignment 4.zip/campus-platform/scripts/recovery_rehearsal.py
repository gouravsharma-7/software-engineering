"""Rehearses data-layer recovery on a synthetic copy. Exit 0 only if every check holds.
Scenario A: migration fails mid-way -> transaction rollback. Scenario B: a bad release
destroys data after commit -> restore from verified backup (image rollback would not help)."""
import os, sqlite3, sys, tempfile, time, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from campus import db, seed
from campus.app import create_app

tmp = tempfile.mkdtemp(); path = os.path.join(tmp, "live.db")
app = create_app(path, salt="rehearsal1"); c = app.test_client()
H = lambda r: {"Authorization": "Bearer %s-rehearsal1" % r}
for i in range(20):
    c.post("/api/v1/bookings", json={"facility_id": 2, "start": "2030-01-01T%02d:00:00Z" % i if i < 24 else "", "end": "2030-01-01T%02d:30:00Z" % i}, headers=H("faculty"))
for i in range(10):
    c.post("/api/v1/tickets", json={"title": "Door lock %d" % i, "impact": "Low", "urgency": "Low"}, headers=H("student"))
conn = db.connect(path); base = db.counts(conn); conn.close()
out = {"baseline": base}
bak = os.path.join(tmp, "verified.bak"); s = sqlite3.connect(path); t = sqlite3.connect(bak); s.backup(t); s.close(); t.close()
chk = sqlite3.connect(bak).execute("PRAGMA integrity_check").fetchone()[0]; out["backup_integrity"] = chk
# Scenario A
try:
    db.migrate_to_v2(path, fail_after_backfill=True); out["A_failed_detected"] = False
except RuntimeError:
    conn = db.connect(path); out["A_failed_detected"] = True
    out["A_schema_after"] = db.schema_version(conn); out["A_counts_equal"] = db.counts(conn) == base; conn.close()
# Scenario B: migration succeeds, then a faulty release deletes rows (destructive, committed)
db.migrate_to_v2(path)
conn = db.connect(path); conn.execute("DELETE FROM bookings WHERE id % 2 = 0"); lost = base["bookings"] - db.counts(conn)["bookings"]; conn.close()
out["B_rows_lost"] = lost
t0 = time.time(); import shutil; shutil.copy(bak, path)
conn = db.connect(path); out["B_counts_restored"] = db.counts(conn) == base; out["B_schema_after_restore"] = db.schema_version(conn)
out["B_recovery_seconds"] = round(time.time() - t0, 4); conn.close()
# forward-fix: re-run migration on restored data
db.migrate_to_v2(path); conn = db.connect(path); out["B_remigrated_counts_equal"] = db.counts(conn) == base; conn.close()
print(json.dumps(out, indent=1))
ok = (out["A_failed_detected"] and out["A_schema_after"] == 1 and out["A_counts_equal"] and lost > 0
      and out["B_counts_restored"] and out["B_remigrated_counts_equal"] and chk == "ok")
print("REHEARSAL", "OK" if ok else "FAILED"); sys.exit(0 if ok else 1)
