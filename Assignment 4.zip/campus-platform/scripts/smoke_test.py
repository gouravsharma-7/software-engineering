"""Post-deployment smoke journey over real HTTP. Usage: smoke_test.py BASE_URL
Env: TOKEN_SALT (must match the deployment), EXPECT_VERSION (optional)."""
import json, os, sys, urllib.request, urllib.error

BASE = sys.argv[1].rstrip("/") if len(sys.argv) > 1 else "http://localhost:8000"
SALT = os.environ["TOKEN_SALT"]


def call(method, path, role=None, body=None):
    req = urllib.request.Request(BASE + path, method=method,
                                 data=json.dumps(body).encode() if body is not None else None,
                                 headers={"Content-Type": "application/json"})
    if role:
        req.add_header("Authorization", "Bearer %s-%s" % (role, SALT))
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            return r.status, json.loads(r.read())
    except urllib.error.HTTPError as e:
        return e.code, json.loads(e.read() or b"{}")


def check(name, cond):
    print(("PASS " if cond else "FAIL ") + name)
    if not cond:
        sys.exit(1)


s, h = call("GET", "/health")
check("health 200", s == 200)
if os.environ.get("EXPECT_VERSION"):
    check("deployed version == %s" % os.environ["EXPECT_VERSION"], h["version"] == os.environ["EXPECT_VERSION"])
s, r = call("GET", "/ready")
check("ready 200", s == 200 and r["schema"] >= 1)
s, b = call("POST", "/api/v1/bookings", "faculty", {"facility_id": 2, "start": "2030-01-01T10:00:00Z", "end": "2030-01-01T11:00:00Z"})
check("faculty creates booking", s == 201)
s, _ = call("POST", "/api/v1/bookings/%d/approve" % b["id"], "student", {"role": "manager"})
check("student approval rejected (403)", s == 403)
s, a = call("POST", "/api/v1/bookings/%d/approve" % b["id"], "approver")
check("approver approves", s == 200 and a["status"] == "Approved")
s, e = call("POST", "/api/v1/sensor-events", "technician", {"source": "smoke", "event_id": "e1", "sensor": "t", "value": 31.0})
check("sensor breach opens ticket", s in (200, 201) and e["breach"])
tid = e["ticket_id"]
s, t = call("GET", "/api/v1/tickets/%d" % tid, "technician")
check("ticket readable by technician", s == 200 and t["state"] == "New")
v = t["version"]
for tgt, notes in [("Assigned", None), ("In Progress", None), ("Resolved", "done"), ("Closed", None)]:
    s, r = call("POST", "/api/v1/tickets/%d/transition" % tid, "technician", {"target": tgt, "expected_version": v, "notes": notes})
    check("transition -> " + tgt, s == 200)
    v = r["version"]
s, _ = call("GET", "/api/v1/tickets/%d" % tid, "student")
check("student cannot read ticket (403)", s == 403)
print("SMOKE OK")
