import os, sys, tempfile, unittest
from datetime import datetime, timezone
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from campus.app import create_app
from campus.integrations import FakeTracker
from campus import seed

SALT = "testsalt1"
T0 = datetime(2026, 1, 5, 9, 0, tzinfo=timezone.utc)


class Clock:
    def __init__(self): self.now = T0
    def __call__(self): return self.now


class Base(unittest.TestCase):
    """Fresh isolated SQLite file per test (setup) and removal afterwards (cleanup)."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.path = os.path.join(self.tmp.name, "t.db")
        self.tracker, self.clock = FakeTracker(), Clock()
        self.app = create_app(self.path, self.tracker, self.clock, SALT)
        self.c = self.app.test_client()
        self.svc = self.app.svc
        self.addCleanup(self.tmp.cleanup)

    def h(self, role):
        return {"Authorization": "Bearer %s" % seed.tokens(SALT)[role]}

    def post(self, url, who, **js):
        return self.c.post(url, json=js, headers=self.h(who))

    def get(self, url, who):
        return self.c.get(url, headers=self.h(who))

    def book(self, role="faculty", fac=2, s="2026-02-02T10:00:00Z", e="2026-02-02T11:00:00Z", v="v1"):
        if v == "v1":
            return self.post("/api/v1/bookings", role, facility_id=fac, start=s, end=e)
        return self.post("/api/v2/bookings", role, facility_id=fac, starts_at=s, ends_at=e)
