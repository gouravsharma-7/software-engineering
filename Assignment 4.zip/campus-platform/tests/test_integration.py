import threading
from helpers import Base
from campus import db, rules, seed
from campus.service import Service
from campus.integrations import FakeTracker


class Integration(Base):
    def test_I1_ticket_lifecycle_persists_and_audits_after_reopen(self):
        tid = self.post("/api/v1/tickets", "student", title="AC compressor tripping in Lab 204",
                        impact="High", urgency="High").get_json()["id"]
        v = 1
        for tgt, notes in [("Assigned", None), ("In Progress", None), ("Resolved", "Reset breaker"), ("Closed", None)]:
            resp = self.post("/api/v1/tickets/%d/transition" % tid, "technician", target=tgt,
                             expected_version=v, notes=notes)
            self.assertEqual(resp.status_code, 200, resp.get_json())
            v = resp.get_json()["version"]
        fresh = Service(self.path, FakeTracker())              # new service = reopened database
        t = fresh.get_ticket(fresh.user_by_token(seed.tokens("testsalt1")["admin"]), tid)
        self.assertEqual((t["state"], t["version"], t["category"], t["priority"]), ("Closed", 5, "HVAC", "M1"))
        conn = db.connect(self.path)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM audit WHERE entity='ticket' AND entity_id=?",
                                      (tid,)).fetchone()[0], 5)

    def test_I2_repeated_sensor_event_creates_one_ticket(self):
        ids = set()
        for _ in range(5):
            r = self.post("/api/v1/sensor-events", "technician", source="sensor-7", event_id="evt-1",
                          sensor="temp", value=31.0)
            ids.add(r.get_json()["ticket_id"])
        self.assertEqual(len(ids), 1)
        conn = db.connect(self.path)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM tickets").fetchone()[0], 1)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM outbox").fetchone()[0], 1)

    def test_I3_student_cannot_approve_even_when_claiming_role(self):
        bid = self.book(role="student").get_json()["id"]
        resp = self.post("/api/v1/bookings/%d/approve" % bid, "student", role="manager")
        self.assertEqual(resp.status_code, 403)
        self.assertEqual(self.get("/api/v1/bookings/%d" % bid, "student").get_json()["status"], "Pending")

    def test_I4_overlap_rejected_adjacent_accepted(self):
        self.assertEqual(self.book(s="2026-02-02T10:00:00Z", e="2026-02-02T12:00:00Z").status_code, 201)
        self.assertEqual(self.book(s="2026-02-02T11:00:00Z", e="2026-02-02T13:00:00Z").status_code, 409)
        self.assertEqual(self.book(s="2026-02-02T12:00:00Z", e="2026-02-02T13:00:00Z").status_code, 201)
        conn = db.connect(self.path)
        self.assertEqual(conn.execute("SELECT COUNT(*) FROM bookings").fetchone()[0], 2)

    def test_I5_concurrent_requests_accept_exactly_one(self):
        codes = []
        def go(role):
            codes.append(self.app.test_client().post("/api/v1/bookings", json=dict(
                facility_id=2, start="2026-03-01T10:00:00Z", end="2026-03-01T11:00:00Z"),
                headers=self.h(role)).status_code)
        ts = [threading.Thread(target=go, args=(r,)) for r in ("faculty", "student") * 4]
        [t.start() for t in ts]; [t.join() for t in ts]
        self.assertEqual(sorted(codes), [201] + [409] * 7)

    def test_I6_tracker_outage_keeps_local_ticket_pending_then_recovers(self):
        self.tracker.available = False
        tid = self.post("/api/v1/tickets", "faculty", title="Door lock jammed", impact="Low",
                        urgency="Low").get_json()["id"]
        t = self.get("/api/v1/tickets/%d" % tid, "admin").get_json()
        self.assertEqual((t["state"], t["integration"], t["remote_id"]), ("New", "pending", None))
        self.tracker.available = True
        self.clock.now += rules.timedelta(minutes=5)           # past the backoff
        self.assertEqual(self.post("/api/v1/sync/run", "technician").get_json()["synced"], 1)
        t = self.get("/api/v1/tickets/%d" % tid, "admin").get_json()
        self.assertEqual((t["integration"], t["remote_id"]), ("synced", "GH-1"))

    def test_I7_timeout_after_remote_create_does_not_duplicate_issue(self):
        self.tracker.fail_after_create = True
        self.post("/api/v1/tickets", "faculty", title="Projector flicker", impact="Low", urgency="Low")
        self.tracker.fail_after_create = False
        self.clock.now += rules.timedelta(minutes=5)
        self.svc.sync_outbox()
        self.assertEqual(len(self.tracker.issues), 1)

    def test_I8_restricted_lab_needs_manager_and_students_cannot_read_tickets(self):
        bid = self.book(role="faculty", fac=1).get_json()["id"]
        self.assertEqual(self.post("/api/v1/bookings/%d/approve" % bid, "approver").status_code, 403)
        self.assertEqual(self.post("/api/v1/bookings/%d/approve" % bid, "manager").status_code, 200)
        tid = self.post("/api/v1/tickets", "student", title="x", impact="Low", urgency="Low").get_json()["id"]
        self.assertEqual(self.get("/api/v1/tickets/%d" % tid, "student").status_code, 403)
        self.assertEqual(self.get("/api/v1/bookings/%d" % bid, "student").status_code, 403)

    def test_I9_missing_or_bad_token_and_bad_input(self):
        self.assertEqual(self.c.post("/api/v1/bookings", json={}).status_code, 401)
        self.assertEqual(self.c.get("/api/v1/tickets/1", headers={"Authorization": "Bearer nope"}).status_code, 401)
        self.assertEqual(self.post("/api/v1/tickets", "student", title="  ", impact="Low", urgency="Low").status_code, 422)
        self.assertEqual(self.book(s="not-a-date").status_code, 422)

    def test_I10_database_unique_constraint_backstops_event_dedupe(self):
        import sqlite3
        self.post("/api/v1/sensor-events", "technician", source="s9", event_id="e9", sensor="t", value=40)
        conn = db.connect(self.path)
        with self.assertRaises(sqlite3.IntegrityError):
            conn.execute("INSERT INTO tickets(title,priority,category,state,version,source,event_id,sla_due)"
                         " VALUES('dup','M1','x','New',1,'s9','e9','2030-01-01T00:00:00+00:00')")
