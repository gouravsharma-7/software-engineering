import os, shutil
from helpers import Base
from campus import db
from campus.app import create_app
from campus.integrations import FakeTracker
from helpers import SALT, Clock


class MigrationV2(Base):
    def _populate_v1(self):
        b = self.book().get_json()["id"]
        t = self.post("/api/v1/tickets", "faculty", title="Door lock jammed", impact="Low", urgency="Low").get_json()["id"]
        self.post("/api/v1/tickets/%d/transition" % t, "technician", target="Assigned", expected_version=1)
        return b, t

    def _counts(self):
        conn = db.connect(self.path); c = db.counts(conn); conn.close(); return c

    def test_M1_migration_preserves_rows_and_old_api_still_reads(self):
        b, t = self._populate_v1()
        before = self._counts()
        db.migrate_to_v2(self.path)
        self.assertEqual(self._counts(), before)
        app = create_app(self.path, FakeTracker(), Clock(), SALT)
        c = app.test_client()
        r = c.get("/api/v1/bookings/%d" % b, headers=self.h("faculty"))
        self.assertEqual((r.status_code, r.get_json()["status"]), (200, "Pending"))
        conn = db.connect(self.path)
        row = conn.execute("SELECT policy_version, campus_code FROM bookings WHERE id=?", (b,)).fetchone()
        self.assertEqual(tuple(row), ("v1", "MAIN"))           # old record keeps recorded policy

    def test_M2_migration_is_idempotent(self):
        self._populate_v1()
        db.migrate_to_v2(self.path)
        b, a = db.migrate_to_v2(self.path)
        self.assertEqual(b, a)

    def test_M3_failed_migration_rolls_back_completely(self):
        self._populate_v1()
        before = self._counts()
        with self.assertRaises(RuntimeError):
            db.migrate_to_v2(self.path, fail_after_backfill=True)
        conn = db.connect(self.path)
        cols = [r[1] for r in conn.execute("PRAGMA table_info(bookings)")]
        self.assertNotIn("campus_code", cols)
        self.assertEqual((db.schema_version(conn), self._counts()), (1, before))

    def test_M4_restore_from_backup_after_destructive_change(self):
        self._populate_v1()
        bak = self.path + ".bak"
        import sqlite3
        src = sqlite3.connect(self.path); dst = sqlite3.connect(bak); src.backup(dst); src.close(); dst.close()
        conn = db.connect(self.path); conn.execute("DELETE FROM bookings"); conn.close()
        self.assertEqual(self._counts()["bookings"], 0)
        shutil.copy(bak, self.path)
        self.assertEqual(self._counts()["bookings"], 1)

    def test_V1_campus_policy_after_migration(self):
        db.migrate_to_v2(self.path)
        self.assertEqual(self.book(fac=3, v="v2", s="2026-02-02T10:00:00Z", e="2026-02-02T12:00:00Z").status_code, 201)
        self.assertEqual(self.book(fac=3, v="v2", s="2026-02-02T13:00:00Z", e="2026-02-02T15:01:00Z").status_code, 422)  # ANNEX 121
        r = self.book(fac=2, v="v2", s="2026-02-03T10:00:00Z", e="2026-02-03T14:00:00Z")      # MAIN 240
        self.assertEqual((r.status_code, r.get_json()["data"]["policy_version"]), (201, "v2"))

    def test_V2_campus_sensor_threshold_and_v1_client_unaffected(self):
        db.migrate_to_v2(self.path)
        ev = lambda eid, camp, val: self.post("/api/v1/sensor-events", "technician", source="s",
                                              event_id=eid, sensor="t", value=val, campus=camp).get_json()["breach"]
        self.assertEqual([ev("1", "ANNEX", 26.0), ev("2", "ANNEX", 26.01), ev("3", "MAIN", 30.0), ev("4", "MAIN", 30.01)],
                         [False, True, False, True])
        self.assertEqual(self.book().status_code, 201)         # v1 booking API still works

    def test_V3_old_api_before_migration_uses_v1_policy(self):
        self.assertEqual(self.book(fac=3, s="2026-02-02T10:00:00Z", e="2026-02-02T13:00:00Z").status_code, 201)  # 180 on ANNEX under v1
