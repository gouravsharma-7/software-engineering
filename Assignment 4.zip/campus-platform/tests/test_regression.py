from helpers import Base


class Regression(Base):
    """Previously correct behaviour that must never change."""
    def test_R1_high_medium_is_M2_through_api(self):
        tid = self.post("/api/v1/tickets", "faculty", title="Network down", impact="High",
                        urgency="Medium").get_json()["id"]
        self.assertEqual(self.get("/api/v1/tickets/%d" % tid, "admin").get_json()["priority"], "M2")

    def test_R2_unknown_terms_go_to_manual_review(self):
        tid = self.post("/api/v1/tickets", "faculty", title="strange noise somewhere", impact="Low",
                        urgency="Low").get_json()["id"]
        self.assertEqual(self.get("/api/v1/tickets/%d" % tid, "admin").get_json()["category"], "Manual Review")

    def test_R3_resolve_without_notes_rejected_and_state_kept(self):
        tid = self.post("/api/v1/tickets", "faculty", title="Door lock jammed", impact="Low", urgency="Low").get_json()["id"]
        self.post("/api/v1/tickets/%d/transition" % tid, "technician", target="Assigned", expected_version=1)
        self.post("/api/v1/tickets/%d/transition" % tid, "technician", target="In Progress", expected_version=2)
        r = self.post("/api/v1/tickets/%d/transition" % tid, "technician", target="Resolved", expected_version=3, notes=" ")
        self.assertEqual(r.status_code, 422)
        self.assertEqual(self.get("/api/v1/tickets/%d" % tid, "admin").get_json()["state"], "In Progress")

    def test_R4_stale_version_rejected(self):
        tid = self.post("/api/v1/tickets", "faculty", title="Display flicker", impact="Low", urgency="Low").get_json()["id"]
        self.post("/api/v1/tickets/%d/transition" % tid, "technician", target="Assigned", expected_version=1)
        r = self.post("/api/v1/tickets/%d/transition" % tid, "technician", target="In Progress", expected_version=1)
        self.assertEqual(r.status_code, 409)
        self.assertEqual(self.get("/api/v1/tickets/%d" % tid, "admin").get_json()["version"], 2)

    def test_R5_duration_boundary_180_ok_181_rejected_via_api(self):
        self.assertEqual(self.book(s="2026-02-02T10:00:00Z", e="2026-02-02T13:00:00Z").status_code, 201)
        self.assertEqual(self.book(fac=3, s="2026-02-02T10:00:00Z", e="2026-02-02T13:01:00Z").status_code, 422)

    def test_R6_threshold_equality_creates_no_ticket_but_above_does(self):
        eq = self.post("/api/v1/sensor-events", "technician", source="s", event_id="a", sensor="t", value=28.0)
        up = self.post("/api/v1/sensor-events", "technician", source="s", event_id="b", sensor="t", value=28.01)
        self.assertEqual((eq.get_json()["breach"], up.get_json()["breach"]), (False, True))
