from datetime import timedelta
from helpers import Base, T0
import unittest
from campus import rules as r


class Unit(unittest.TestCase):
    def test_U1_priority_matrix_all_nine_cells(self):
        exp = {("High", "High"): "M1", ("High", "Medium"): "M2", ("High", "Low"): "M3",
               ("Medium", "High"): "M2", ("Medium", "Medium"): "M3", ("Medium", "Low"): "M4",
               ("Low", "High"): "M3", ("Low", "Medium"): "M4", ("Low", "Low"): "M4"}
        for (i, u), want in exp.items():
            with self.subTest(i=i, u=u):
                self.assertEqual(r.priority(i, u), want)

    def test_U2_priority_rejects_invalid_values(self):
        for bad in [("Critical", "High"), ("High", ""), (None, None)]:
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                r.priority(*bad)

    def test_U3_classification_and_tie_goes_to_manual_review(self):
        self.assertEqual(r.classify("Water leak from lab ceiling"), "Facilities")
        self.assertEqual(r.classify("leak and projector fault"), "Manual Review")
        self.assertEqual(r.classify(""), "Manual Review")

    def test_U4_sensor_threshold_boundary_is_strict(self):
        self.assertEqual([r.breached(v, 28.0) for v in (27.99, 28.00, 28.01)], [False, False, True])

    def test_U5_duration_boundaries(self):
        got = [r.valid_duration(m, 180) for m in (0, -5, 1, 179, 180, 181)]
        self.assertEqual(got, [False, False, True, True, True, False])

    def test_U6_overlap_is_half_open(self):
        self.assertTrue(r.overlaps(600, 720, 700, 800))
        self.assertFalse(r.overlaps(600, 720, 720, 800))     # back-to-back
        self.assertTrue(r.overlaps(600, 720, 600, 720))      # identical

    def test_U7_sla_deadline_equality_not_overdue(self):
        due = r.sla_due(T0, "M1")
        self.assertEqual(due, T0 + timedelta(hours=4))
        s = timedelta(seconds=1)
        self.assertEqual([r.is_overdue(due - s, due), r.is_overdue(due, due), r.is_overdue(due + s, due)],
                         [False, False, True])

    def test_U8_timestamp_needs_timezone(self):
        with self.assertRaises(ValueError):
            r.parse_ts("2026-02-02T10:00:00")
        self.assertEqual(r.parse_ts("2026-02-02T10:00:00+05:30").hour, 4)

    def test_U9_campus_policy_lookup_and_default(self):
        self.assertEqual(r.get_policy("v2", "ANNEX")["max_minutes"], 120)
        self.assertEqual(r.get_policy("v2", "UNKNOWN")["max_minutes"], 180)
        self.assertEqual(r.get_policy("v1", "ANNEX")["max_minutes"], 180)
