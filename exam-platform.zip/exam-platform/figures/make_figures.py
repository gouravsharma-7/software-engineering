"""Regenerates every report figure (black and white) from results/results.json. Needs matplotlib."""
import json
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from responsible_exam import decision as DEC  # noqa: E402

plt.rcParams["font.family"] = ["Liberation Serif", "Times New Roman", "DejaVu Serif"]
plt.rcParams["font.size"] = 10
OUT = os.path.dirname(__file__) + "/"
R = json.load(open(OUT + "../results/results.json"))
A, B = R["scenario_A_consistent_labels"], R["scenario_B_inconsistent_NET_labels"]
HATCH = ["", "///", "xxx", "..."]
SHADE = ["white", "0.75", "0.45", "0.15"]


def canvas(w, h):
    fig, ax = plt.subplots(figsize=(w, h))
    ax.set_xlim(0, w * 10); ax.set_ylim(0, h * 10); ax.axis("off")
    return fig, ax


def box(ax, x, y, w, h, text, fs=9, dashed=False, bold=False, fill="white"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=1", fc=fill, ec="black",
                                lw=1.2, ls="--" if dashed else "-"))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal")


def zone(ax, x, y, w, h, label):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.2,rounding_size=1.5", fc="none", ec="black",
                                lw=1.6, ls=(0, (6, 3))))
    ax.text(x + 1.5, y + h - 2.5, label, fontsize=8.5, style="italic")


def arrow(ax, p, q, label="", dashed=False, off=(0, 1.2), fs=8):
    ax.annotate("", xy=q, xytext=p, arrowprops=dict(arrowstyle="-|>", color="black", lw=1.1, ls="--" if dashed else "-"))
    if label:
        ax.text((p[0] + q[0]) / 2 + off[0], (p[1] + q[1]) / 2 + off[1], label, ha="center", fontsize=fs, style="italic")


def save(fig, name):
    fig.savefig(OUT + name, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)


# ---- F1 stakeholder map
fig, ax = plt.subplots(figsize=(6.2, 4.2))
pts = {"Student": (9, 9), "Examiner": (8, 7.5), "Moderator": (6.5, 7), "Controller of Exams": (9, 5.5), "Administrator": (4, 4.5),
       "Dept. head": (5.5, 3), "External verifier": (3, 6), "Partner institution": (2, 2.5)}
for n, (infl, imp) in pts.items():
    ax.scatter(infl, imp, s=60, c="black")
    ax.annotate(n, (infl, imp), textcoords="offset points", xytext=(6, 5), fontsize=9)
ax.axhline(5, color="0.5", lw=0.8, ls=":"); ax.axvline(5, color="0.5", lw=0.8, ls=":")
ax.set_xlim(0, 11); ax.set_ylim(0, 10.5)
ax.set_xlabel("Influence over the adoption decision (1-10, author judgement)")
ax.set_ylabel("Impact of marking errors on the stakeholder (1-10)")
for s in ("top", "right"): ax.spines[s].set_visible(False)
save(fig, "f01_stakeholders.png")

# ---- F2 component diagram with trust boundaries
fig, ax = canvas(10, 5.6)
zone(ax, 1, 3, 30, 50, "Zone 1: Examination office (internal, high trust)")
zone(ax, 34, 3, 36, 50, "Zone 2: Marks service (restricted, sensitive student data)")
zone(ax, 73, 3, 26, 50, "Zone 3: Outside the university")
box(ax, 4, 38, 24, 9, "Web UI\n(examiner / moderator /\ncontroller / student)", fs=8.5)
box(ax, 4, 22, 24, 9, "Identity and role service\n(SSO, role checks)", fs=8.5)
box(ax, 4, 7, 24, 9, "Moderation dashboard\n(priority list, reasons)", fs=8.5)
box(ax, 37, 40, 30, 8, "Marks API + workflow engine\n(versions, human gates)", fs=8.5, bold=True)
box(ax, 37, 28, 30, 8, "Rubric rule scorer v2\n(deterministic, explainable)", fs=8.5)
box(ax, 37, 17, 30, 8, "Shadow ML scorer (kNN)\nsuggestion only, never published", fs=8.5, dashed=True)
box(ax, 37, 6, 30, 8, "Marks DB + hash-chained audit log\n(encrypted at rest)", fs=8.5, bold=True)
box(ax, 76, 36, 20, 9, "External verifier\n(read-only verify API)", fs=8.5)
box(ax, 76, 20, 20, 9, "Second custodian\n(holds audit head hash)", fs=8.5)
box(ax, 76, 6, 20, 8, "Partner institution\n(withdrawn; optional)", fs=8.5, dashed=True)
arrow(ax, (28, 42), (37, 43), "HTTPS", off=(0, 2))
arrow(ax, (28, 26), (37, 41), "claims")
arrow(ax, (52, 40), (52, 36)); arrow(ax, (52, 28), (52, 25), "suggestion", off=(7, 0))
arrow(ax, (52, 17), (52, 14)); arrow(ax, (37, 11), (28, 11), "priority list", off=(0, 1.5))
arrow(ax, (67, 10), (76, 23), "head hash", off=(6, -3))
arrow(ax, (67, 43), (76, 41), "commitment", off=(0, 2.5))
save(fig, "f02_components.png")

# ---- F3 data-flow diagram
fig, ax = canvas(10, 4.8)
zone(ax, 22, 5, 52, 39, "Trust boundary: marks service")
box(ax, 1, 28, 15, 8, "Student\n(answer script)", fs=8.5)
box(ax, 1, 8, 15, 8, "Examiner", fs=8.5)
box(ax, 26, 28, 20, 8, "P1 Score\n(rules, shadow ML)", fs=8.5)
box(ax, 50, 28, 20, 8, "P2 Review and\nmoderate (human)", fs=8.5)
box(ax, 26, 8, 20, 8, "D1 Marks DB\n+ audit chain", fs=8.5, bold=True)
box(ax, 50, 8, 20, 8, "P3 Publish and\ncorrect", fs=8.5)
box(ax, 83, 28, 15, 8, "External\nverifier", fs=8.5)
box(ax, 83, 8, 15, 8, "Custodian", fs=8.5)
arrow(ax, (16, 32), (26, 32), "script text (S)", off=(0, 1.5))
arrow(ax, (46, 32), (50, 32), "suggestion (S)", off=(0, 1.8))
arrow(ax, (16, 12), (50, 30), "mark + reason (S)", off=(9, -3))
arrow(ax, (60, 28), (46, 14), "decision (S)", off=(6, 1))
arrow(ax, (46, 12), (50, 12), "")
arrow(ax, (70, 12), (83, 12), "head hash (N)", off=(0, 1.5))
arrow(ax, (70, 15), (83, 30), "commitment + grade (L)", off=(5, 4))
ax.text(1, 0.5, "S = sensitive student content / marks, L = limited personal data, N = non-personal", fontsize=8, style="italic")
save(fig, "f03_dfd.png")

# ---- F4 workflow
fig, ax = canvas(10, 3.4)
states = ["SUGGESTED", "EXAMINER\nREVIEWED", "MODERATED", "APPROVED", "PUBLISHED"]
xs = [3, 23, 43, 62, 82]
for s, x in zip(states, xs):
    box(ax, x, 18, 15, 8, s, fs=8.5)
roles = ["system", "examiner\n(read + reason)", "moderator", "controller", "controller"]
for a, b, r in zip(xs[:-1], xs[1:], roles[1:]):
    arrow(ax, (a + 15, 22), (b, 22), r, off=(0, 4.5))
box(ax, 55, 3, 38, 7, "CORRECTED (append-only: old mark, new mark, reason)", fs=8.5, dashed=True)
arrow(ax, (89, 18), (80, 10), "student challenge / disputed record", off=(-8, 1.5))
box(ax, 10, 3, 30, 7, "Override of suggestion needs written reason", fs=8.5, dashed=True)
arrow(ax, (30, 10), (30, 18), "")
save(fig, "f04_workflow.png")

# ---- F5 decision matrix totals
ini, rev = DEC.totals(DEC.INITIAL), DEC.totals(DEC.REVISED)
fig, ax = plt.subplots(figsize=(6.4, 3.6))
labels = [a.split(":")[0] for a in DEC.ALTS]
x = range(4)
b1 = ax.bar([i - 0.2 for i in x], [ini[a] for a in DEC.ALTS], 0.4, color="white", edgecolor="black", hatch="///", label="Initial assumptions")
b2 = ax.bar([i + 0.2 for i in x], [rev[a] for a in DEC.ALTS], 0.4, color="0.35", edgecolor="black", label="Revised with evidence")
for bars in (b1, b2):
    for r in bars:
        ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 0.05, f"{r.get_height():.2f}", ha="center", fontsize=9)
ax.set_xticks(list(x)); ax.set_xticklabels([f"{a}\n{n}" for a, n in zip(labels, ["Rules+human", "ML assist", "Blockchain", "ML+Blockchain"])])
ax.set_ylabel("Weighted score (max 5)"); ax.set_ylim(0, 5); ax.legend(frameon=False, loc="upper right")
for s in ("top", "right"): ax.spines[s].set_visible(False)
save(fig, "f05_matrix.png")

# ---- F6 sensitivity
ws = [i / 100 for i in range(5, 71)]
fig, ax = plt.subplots(figsize=(6.4, 3.6))
for alt, ls, mk in (("A: Rules + human", "-", "o"), ("B: Trained ML assist", "--", "s")):
    ax.plot(ws, [DEC.totals(DEC.INITIAL, DEC.reweight(DEC.WEIGHTS, "Usefulness", w))[alt] for w in ws], "k" + ls, label=alt)
bp = R["decision"]["breakpoint_initial_usefulness"]
ax.axvline(bp, color="0.4", ls=":"); ax.text(bp + 0.01, 3.15, f"break-even at\nweight {bp:.2f}", fontsize=9)
ax.axvline(0.20, color="0.7", ls="-", lw=0.8); ax.text(0.205, 4.35, "baseline 0.20", fontsize=8.5)
ax.set_xlabel("Weight given to Usefulness (other weights rescaled)"); ax.set_ylabel("Weighted score")
ax.legend(frameon=False); ax.set_ylim(3.0, 4.6)
for s in ("top", "right"): ax.spines[s].set_visible(False)
save(fig, "f06_sensitivity.png")

# ---- F7 accuracy by scorer and scenario
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.3))
names = [("rule_v1", "Rule v1\n(baseline)"), ("rule_v2", "Rule v2\n(revised)"), ("knn", "kNN\n(trained)")]
for ax, (met, title) in zip(axs, (("mae", "Mean absolute error (marks, lower is better)"), ("exact", "Exact mark agreement (higher is better)"))):
    for j, (sc, col) in enumerate(((A, "white"), (B, "0.35"))):
        vals = [sc[k][met] for k, _ in names]
        bars = ax.bar([i + (j - 0.5) * 0.38 for i in range(3)], vals, 0.38, color=col, edgecolor="black", hatch="///" if j == 0 else "",
                      label="Scenario A: consistent labels" if j == 0 else "Scenario B: inconsistent NET labels")
        for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 0.01, f"{r.get_height():.2f}", ha="center", fontsize=8)
    ax.set_xticks(range(3)); ax.set_xticklabels([n for _, n in names], fontsize=8.5); ax.set_title(title, fontsize=9)
    for s in ("top", "right"): ax.spines[s].set_visible(False)
axs[0].legend(frameon=False, fontsize=7.5, loc="upper right")
fig.tight_layout()
save(fig, "f07_accuracy.png")

# ---- F8 negation + calibration
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2))
ax = axs[0]
vals = [A[k]["neg_overcredit"] * 100 for k, _ in names]
bars = ax.bar(range(3), vals, 0.5, color=["white", "0.7", "0.35"], edgecolor="black")
for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 1, f"{r.get_height():.0f}%", ha="center")
ax.set_xticks(range(3)); ax.set_xticklabels([n for _, n in names], fontsize=8.5)
ax.set_title("Negated answers given extra credit (n=26)", fontsize=9); ax.set_ylim(0, 60)
ax = axs[1]
bins = list(A["calibration"].keys())
acc = [(A["calibration"][b]["accuracy"] or 0) * 100 for b in bins]
ns = [A["calibration"][b]["n"] for b in bins]
bars = ax.bar(range(3), acc, 0.5, color="0.6", edgecolor="black")
for r, n in zip(bars, ns): ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 1.5, f"n={n}", ha="center", fontsize=8.5)
ax.set_xticks(range(3)); ax.set_xticklabels(bins, fontsize=8.5); ax.set_ylim(0, 100)
ax.set_xlabel("Displayed confidence = 1/(1+neighbour std)"); ax.set_title("Exact-mark accuracy per confidence band (%)", fontsize=9)
for a in axs:
    for s in ("top", "right"): a.spines[s].set_visible(False)
fig.tight_layout()
save(fig, "f08_negation_calibration.png")

# ---- F9 agreement gate + moderation
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2))
ag = A["agreement_gate"]
ax = axs[0]
bars = ax.bar(range(3), [ag["exact_on_agreed"] * 100, ag["exact_on_disagreed"] * 100, A["knn"]["exact"] * 100], 0.5,
              color=["0.3", "white", "0.7"], edgecolor="black")
for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 1.5, f"{r.get_height():.0f}%", ha="center")
ax.set_xticks(range(3)); ax.set_xticklabels([f"Rule and ML\nagree ({ag['coverage']*100:.0f}% of scripts)", "Disagree", "All scripts\n(ML alone)"], fontsize=8)
ax.set_ylim(0, 100); ax.set_title("Exact-mark accuracy of ML suggestion (%)", fontsize=9)
ax = axs[1]
m = A["moderation"]
vals = [m["random_recall_top20"], m["rule_v2_recall_top20"], m["knn_recall_top20"]]
bars = ax.bar(range(3), [v * 100 for v in vals], 0.5, color=["white", "0.7", "0.35"], edgecolor="black")
for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 1.5, f"{r.get_height():.0f}%", ha="center")
ax.set_xticks(range(3)); ax.set_xticklabels(["Random\n20% sample", "Rule v2\npriority", "kNN\npriority"], fontsize=8.5)
ax.set_ylim(0, 100); ax.set_title(f"Wrong examiner marks found in top 20% (n={m['n_wrong_examiner_marks']})", fontsize=9)
for a in axs:
    for s in ("top", "right"): a.spines[s].set_visible(False)
fig.tight_layout()
save(fig, "f09_gate_moderation.png")

# ---- F10 ledger experiments
fig, ax = canvas(10, 4.0)
rows = [("Case 1: edit one past block", "chain breaks at block 3", "DETECTED", 30),
        ("Case 2: operator rewrites block and recomputes all hashes", "chain still verifies alone", "DETECTED ONLY WITH EXTERNAL ANCHOR", 17),
        ("Case 3: false mark entered at the start", "chain verifies", "NOT DETECTED", 4)]
for t, res, verdict, y in rows:
    for i in range(5):
        box(ax, 2 + i * 8, y, 6, 6, f"B{i}", fs=8, fill="0.75" if (i == 3 and y != 4) or (y == 4 and i == 0) else "white")
        if i: arrow(ax, (2 + (i - 1) * 8 + 6, y + 3), (2 + i * 8, y + 3))
    ax.text(45, y + 4.6, t, fontsize=9, fontweight="bold")
    ax.text(45, y + 0.2, res + "  ->  " + verdict if "\n" not in res else res.replace("\n", " ") + "  ->  " + verdict, fontsize=8.5, style="italic")
ax.text(2, 38.5, "Hash-chain experiments (shaded block = altered or false)", fontsize=9.5, fontweight="bold")
save(fig, "f10_ledger.png")

# ---- F11 cost and energy estimates
fig, axs = plt.subplots(1, 2, figsize=(7.0, 3.2))
cost = {"A": 1500, "B": 4100, "C": 5800, "D": 8400}
kwh = {"A": 219, "B": 876, "C": 1752, "D": 2628}
ax = axs[0]
bars = ax.bar(cost.keys(), cost.values(), 0.5, color=["0.9", "0.7", "0.5", "0.3"], edgecolor="black")
ax.axhline(3000, color="black", ls="--"); ax.text(3.45, 3150, "halved budget\n(USD 3,000)", fontsize=8, ha="right")
for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 120, f"{r.get_height():,.0f}", ha="center", fontsize=8.5)
ax.set_title("Estimated annual cost (USD)", fontsize=9)
ax = axs[1]
bars = ax.bar(kwh.keys(), kwh.values(), 0.5, color=["0.9", "0.7", "0.5", "0.3"], edgecolor="black")
for r in bars: ax.text(r.get_x() + r.get_width() / 2, r.get_height() + 40, f"{r.get_height():,.0f}", ha="center", fontsize=8.5)
ax.set_title("Estimated annual electricity (kWh)", fontsize=9)
for a in axs:
    for s in ("top", "right"): a.spines[s].set_visible(False)
fig.tight_layout()
save(fig, "f11_cost.png")

# ---- F12 revised architecture
fig, ax = canvas(10, 4.2)
zone(ax, 1, 3, 62, 38, "Revised: single trust domain (university only)")
box(ax, 4, 26, 18, 9, "Web UI +\nrole service", fs=8.5)
box(ax, 26, 26, 22, 9, "Marks API + workflow\n(human gates)", fs=8.5, bold=True)
box(ax, 26, 8, 22, 9, "Rule scorer v2 + negation\nguard + agreement gate", fs=8.5)
box(ax, 51, 14, 10, 9, "Marks DB\n+ audit chain", fs=7.5, bold=True)
box(ax, 4, 8, 18, 9, "Shadow ML\n(paused: label audit)", fs=8, dashed=True)
box(ax, 70, 26, 27, 9, "Second custodian\n(Controller + Dept. head\nhold head hash weekly)", fs=8)
box(ax, 70, 8, 27, 9, "Verification: signed PDF +\nlookup of grade commitment", fs=8)
arrow(ax, (22, 30), (26, 30)); arrow(ax, (37, 26), (37, 17)); arrow(ax, (48, 30), (53, 23))
arrow(ax, (22, 12), (26, 12), "", dashed=True)
arrow(ax, (61, 20), (70, 29)); arrow(ax, (61, 16), (70, 12))
ax.text(64, 40, "Removed: partner node, distributed ledger", fontsize=8.5, style="italic")
save(fig, "f12_revised.png")
print("figures ok")
