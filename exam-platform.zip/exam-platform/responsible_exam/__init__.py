"""Responsible technology adoption demonstrator for an examination platform (synthetic data only)."""
