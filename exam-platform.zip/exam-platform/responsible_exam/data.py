"""Synthetic answer-script generator. NO real student data is used anywhere.

Each question has four rubric concepts worth 1 mark each (max 4). An answer expresses each concept in
one of five ways. The expert label credits exact, paraphrased and misspelt expressions and refuses
credit for negated mentions or omissions. Examiner marks are the expert mark plus controlled error.
"""
import random

# concept -> (keyword, [paraphrase 1, paraphrase 2], misspelt keyword)
QUESTIONS = {
    "OS": {
        "mutual exclusion": ("mutual exclusion", ["only one process can hold the resource at a time", "a resource is used by a single process alone"], "mutual exculsion"),
        "hold and wait": ("hold and wait", ["a process keeps one resource while requesting another", "it retains what it has and asks for more"], "hold and wiat"),
        "no preemption": ("no preemption", ["resources cannot be forcibly taken away", "the system cannot snatch a resource back"], "no preemtion"),
        "circular wait": ("circular wait", ["processes wait for each other in a cycle", "each process waits on the next in a ring"], "circular wiat"),
    },
    "DB": {
        "redundancy": ("redundancy", ["the same data is repeated in many places", "duplicate copies of data are stored"], "redundancey"),
        "anomaly": ("anomaly", ["insert update and delete cause side effects", "changes produce inconsistent rows"], "anomally"),
        "functional dependency": ("functional dependency", ["one attribute determines another", "a value fixes the value of another column"], "functional dependancy"),
        "decomposition": ("decomposition", ["splitting a table into smaller tables", "breaking a relation into several relations"], "decomposision"),
    },
    "NET": {
        "acknowledgement": ("acknowledgement", ["the receiver confirms the data it received", "a reply tells the sender data arrived"], "acknowlegement"),
        "retransmission": ("retransmission", ["lost segments are sent again", "the sender transmits missing data a second time"], "retransmision"),
        "sequence number": ("sequence number", ["each byte is numbered so order is known", "segments carry a counter to keep order"], "sequence numbr"),
        "flow control": ("flow control", ["the receiver limits how fast the sender transmits", "the sender is slowed to the receiver capacity"], "flow controll"),
    },
}
FILLER = ["In my understanding", "To answer briefly", "As studied in class", "In general", "Typically"]
NEGATION = ["it does not involve {kw}", "there is no {kw} here", "{kw} is not required"]
MODES = ["exact", "paraphrase", "misspelt", "negated", "omitted"]
MODE_P = [0.40, 0.20, 0.08, 0.07, 0.25]
PER_QUESTION = 100
BANDS = [(0, "F"), (2, "C"), (3, "B"), (4, "A")]  # pass mark = 2 of 4


def band(mark):
    b = "F"
    for lo, name in BANDS:
        if mark >= lo:
            b = name
    return b


def _sentence(mode, kw, paras, miss, rng):
    if mode == "exact":
        return f"This relies on {kw}."
    if mode == "paraphrase":
        return rng.choice(paras).capitalize() + "."
    if mode == "misspelt":
        return f"This relies on {miss}."
    if mode == "negated":
        return rng.choice(NEGATION).format(kw=kw).capitalize() + "."
    return ""


def generate(seed=7):
    """Return list of answer dicts (300 scripts)."""
    rng = random.Random(seed)
    out = []
    for q, concepts in QUESTIONS.items():
        for i in range(PER_QUESTION):
            parts, expert, modes = [rng.choice(FILLER) + ","], 0, {}
            for name, (kw, paras, miss) in concepts.items():
                m = rng.choices(MODES, MODE_P)[0]
                modes[name] = m
                s = _sentence(m, kw, paras, miss, rng)
                if s:
                    parts.append(s)
                expert += m in ("exact", "paraphrase", "misspelt")
            order = parts[1:]
            rng.shuffle(order)
            out.append({"id": f"{q}-{i:03d}", "question": q, "text": " ".join([parts[0]] + order),
                        "expert": expert, "modes": modes,
                        "has_negation": "negated" in modes.values()})
    return out


def noisy(mark, p, rng):
    """Examiner inconsistency: with probability p the mark is off by one (clipped to 0..4)."""
    if rng.random() < p:
        mark += rng.choice([-1, 1])
    return max(0, min(4, mark))


def split(data):
    """First two thirds of each question = historical (training) scripts, rest = test scripts."""
    train, test = [], []
    for q in QUESTIONS:
        rows = [d for d in data if d["question"] == q]
        cut = int(len(rows) * 2 / 3)
        train += rows[:cut]
        test += rows[cut:]
    return train, test


def historical_marks(train, noise_net, seed=11, noise_other=0.08):
    """Historical examiner marks used as ML training labels. NET gets extra inconsistency in scenario B."""
    rng = random.Random(seed)
    return [noisy(d["expert"], noise_net if d["question"] == "NET" else noise_other, rng) for d in train]


def examiner_marks(test, seed=13, p=0.15):
    """Marks given by the examiner on the test scripts (some are wrong); used for moderation targeting."""
    rng = random.Random(seed)
    return [noisy(d["expert"], p, rng) for d in test]
