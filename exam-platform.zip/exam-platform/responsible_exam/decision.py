"""Weighted decision matrix and sensitivity analysis. Scores (1-5) are the author's judgements; the
rationale for each is written in the report and linked to demonstrator evidence where it exists."""
ALTS = ["A: Rules + human", "B: Trained ML assist", "C: Blockchain credentials", "D: ML + Blockchain"]
CRITERIA = ["Usefulness", "Reliability", "Privacy", "Fairness", "Cost", "Sustainability"]
WEIGHTS = {"Usefulness": 0.20, "Reliability": 0.20, "Privacy": 0.15, "Fairness": 0.20, "Cost": 0.15, "Sustainability": 0.10}

# Initial (Task 2) planning assumptions: consistent labels, partner available, full budget.
INITIAL = {
    "A: Rules + human":          [2, 3, 5, 4, 5, 5],
    "B: Trained ML assist":      [5, 4, 3, 3, 3, 3],
    "C: Blockchain credentials": [3, 4, 3, 4, 2, 2],
    "D: ML + Blockchain":        [5, 4, 2, 3, 1, 1],
}
# Revised (Task 6) after observed evidence: noisy NET labels, partner withdrew, budget halved.
REVISED = {
    "A: Rules + human":          [3, 4, 5, 4, 5, 5],
    "B: Trained ML assist":      [3, 2, 3, 2, 2, 3],
    "C: Blockchain credentials": [2, 3, 3, 4, 1, 2],
    "D: ML + Blockchain":        [3, 2, 2, 2, 1, 1],
}


def totals(scores, weights=WEIGHTS):
    return {a: round(sum(weights[c] * s for c, s in zip(CRITERIA, v)), 3) for a, v in scores.items()}


def reweight(weights, criterion, new):
    """Set one criterion to a new weight and rescale the others so the sum stays 1."""
    rest = 1 - weights[criterion]
    return {c: (new if c == criterion else w * (1 - new) / rest) for c, w in weights.items()}


def winner(scores, weights=WEIGHTS):
    t = totals(scores, weights)
    return max(t, key=t.get)


def sweep(scores, criterion, values):
    return {v: winner(scores, reweight(WEIGHTS, criterion, v)) for v in values}


def breakpoint(scores, criterion, base_winner=None):
    """Smallest weight (step 0.01) of `criterion` at which the winner differs from the base winner, else None."""
    base = base_winner or winner(scores)
    for i in range(0, 100):
        w = i / 100
        if w == WEIGHTS[criterion]:
            continue
        if winner(scores, reweight(WEIGHTS, criterion, w)) != base and w > WEIGHTS[criterion]:
            return w
    return None
