"""Hash-chained append-only log. Used both as the local audit trail and as the stand-in for a shared ledger.

It demonstrates what chaining can and cannot establish; it is NOT a distributed Blockchain implementation.
"""
import hashlib
import json


def digest(obj):
    return hashlib.sha256(json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def commitment(salt, credential):
    """Salted commitment: only this digest, never personal data, is placed in the shared log."""
    return hashlib.sha256((salt + json.dumps(credential, sort_keys=True)).encode()).hexdigest()


class HashChain:
    def __init__(self):
        self.blocks = []

    def append(self, payload):
        prev = self.blocks[-1]["hash"] if self.blocks else "0" * 64
        body = {"index": len(self.blocks), "prev": prev, "payload": payload}
        body["hash"] = digest({k: body[k] for k in ("index", "prev", "payload")})
        self.blocks.append(body)
        return body["index"]

    @property
    def head(self):
        return self.blocks[-1]["hash"] if self.blocks else "0" * 64

    def verify(self, anchor=None):
        """Return (ok, first_bad_index). If an externally held head hash is supplied it must match too."""
        prev = "0" * 64
        for b in self.blocks:
            if b["prev"] != prev or b["hash"] != digest({k: b[k] for k in ("index", "prev", "payload")}):
                return False, b["index"]
            prev = b["hash"]
        if anchor is not None and anchor != prev:
            return False, len(self.blocks) - 1
        return True, None

    def rewrite_as_single_operator(self, index, new_payload):
        """An operator who controls the whole chain edits a block and recomputes every later hash."""
        prev = self.blocks[index - 1]["hash"] if index else "0" * 64
        for b in self.blocks[index:]:
            if b["index"] == index:
                b["payload"] = new_payload
            b["prev"] = prev
            b["hash"] = digest({k: b[k] for k in ("index", "prev", "payload")})
            prev = b["hash"]
