"""Moderation-priority score using the stakes-discrepancy idea: large disagreement matters more near a band boundary."""
import random

from .data import band


def priority(suggested, examiner_mark):
    diff = abs(suggested - examiner_mark)
    crosses = band(round(suggested)) != band(examiner_mark)
    near_pass = min(suggested, examiner_mark) < 2 <= max(suggested, examiner_mark) + 0.5
    return diff + (1.0 if crosses else 0.0) + (0.5 if near_pass else 0.0)


def top_fraction(scores, frac=0.2):
    n = max(1, int(len(scores) * frac))
    return set(sorted(range(len(scores)), key=lambda i: -scores[i])[:n])


def recall_at(flagged, wrong):
    return len(flagged & wrong) / len(wrong) if wrong else 0.0


def random_recall(n, wrong, frac=0.2, trials=500, seed=3):
    rng = random.Random(seed)
    k = max(1, int(n * frac))
    return sum(recall_at(set(rng.sample(range(n), k)), wrong) for _ in range(trials)) / trials
