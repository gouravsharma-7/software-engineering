"""Runs every experiment and writes results/results.json. Usage: python -m responsible_exam.run_demo"""
import json
import os
import time
from collections import Counter

from . import data as D
from . import decision as DEC
from . import moderation as M
from .ledger import HashChain, commitment
from .scorers import KNNScorer, rule_v1, rule_v2
from .workflow import MarkRecord, WorkflowError


def metrics(preds, test):
    n = len(test)
    mae = sum(abs(p - d["expert"]) for p, d in zip(preds, test)) / n
    exact = sum(round(p) == d["expert"] for p, d in zip(preds, test)) / n
    bnd = sum(D.band(round(p)) == D.band(d["expert"]) for p, d in zip(preds, test)) / n
    neg = [(p, d) for p, d in zip(preds, test) if d["has_negation"]]
    neg_exact = sum(round(p) == d["expert"] for p, d in neg) / len(neg)
    neg_over = sum(round(p) > d["expert"] for p, d in neg) / len(neg)  # false credit after negation
    return {"mae": round(mae, 3), "exact": round(exact, 3), "band": round(bnd, 3),
            "neg_exact": round(neg_exact, 3), "neg_overcredit": round(neg_over, 3), "n_neg": len(neg)}


def per_question_mae(preds, test):
    out = {}
    for q in D.QUESTIONS:
        pairs = [(p, d) for p, d in zip(preds, test) if d["question"] == q]
        out[q] = round(sum(abs(p - d["expert"]) for p, d in pairs) / len(pairs), 3)
    return out


def scenario(name, noise_net, data):
    train, test = D.split(data)
    labels = D.historical_marks(train, noise_net)
    label_err = sum(l != d["expert"] for l, d in zip(labels, train)) / len(train)
    t0 = time.perf_counter()
    knn = KNNScorer(k=5).fit(train, labels)
    fit_s = time.perf_counter() - t0
    res, timing = {}, {}
    p1 = [rule_v1(d) for d in test]
    p2 = [rule_v2(d) for d in test]
    t0 = time.perf_counter()
    pk_raw = [knn.predict(d) for d in test]
    timing["knn_ms_per_script"] = round((time.perf_counter() - t0) / len(test) * 1000, 2)
    pk = [m for m, _ in pk_raw]
    res["rule_v1"], res["rule_v2"], res["knn"] = metrics(p1, test), metrics(p2, test), metrics(pk, test)
    res["per_question_mae"] = {"rule_v1": per_question_mae(p1, test), "rule_v2": per_question_mae(p2, test),
                               "knn": per_question_mae(pk, test)}
    # displayed "confidence" = 1/(1+std); check whether it behaves like a probability
    bins = {"[0.0,0.6)": [], "[0.6,0.8)": [], "[0.8,1.0]": []}
    for (m, s), d in zip(pk_raw, test):
        c = 1 / (1 + s)
        key = "[0.0,0.6)" if c < 0.6 else "[0.6,0.8)" if c < 0.8 else "[0.8,1.0]"
        bins[key].append(round(m) == d["expert"])
    res["calibration"] = {k: {"n": len(v), "accuracy": round(sum(v) / len(v), 3) if v else None} for k, v in bins.items()}
    # abstain rule (design revision): route to a human when neighbour disagreement is high
    kept = [(m, d) for (m, s), d in zip(pk_raw, test) if s <= 0.8]
    res["abstain"] = {"coverage": round(len(kept) / len(test), 3),
                      "exact_on_kept": round(sum(round(m) == d["expert"] for m, d in kept) / len(kept), 3) if kept else None}
    # agreement gate (design revision): accept machine suggestions only where rules and model agree within 0.5
    agree = [(m, d) for m, r, d in zip(pk, p2, test) if abs(m - r) < 0.5]
    res["agreement_gate"] = {"coverage": round(len(agree) / len(test), 3),
                             "exact_on_agreed": round(sum(round(m) == d["expert"] for m, d in agree) / len(agree), 3) if agree else None,
                             "exact_on_disagreed": round(sum(round(m) == d["expert"] for m, r, d in zip(pk, p2, test) if abs(m - r) >= 0.5) / max(1, len(test) - len(agree)), 3)}
    # moderation targeting on examiner marks that contain errors
    ex = D.examiner_marks(test)
    wrong = {i for i, (e, d) in enumerate(zip(ex, test)) if e != d["expert"]}
    mod = {"n_wrong_examiner_marks": len(wrong)}
    for nm, preds in (("rule_v2", p2), ("knn", pk)):
        sc = [M.priority(p, e) for p, e in zip(preds, ex)]
        mod[nm + "_recall_top20"] = round(M.recall_at(M.top_fraction(sc), wrong), 3)
    mod["random_recall_top20"] = round(M.random_recall(len(test), wrong), 3)
    res["moderation"] = mod
    res["train_label_error_rate"] = round(label_err, 3)
    res["knn_fit_seconds"] = round(fit_s, 3)
    res["timing"] = timing
    return res


def ledger_tests():
    out = {}
    c = HashChain()
    for i in range(6):
        c.append({"script": f"S{i}", "mark": 3})
    out["clean_chain_valid"] = c.verify()[0]
    c.blocks[3]["payload"]["mark"] = 4  # plain edit without recomputing
    out["plain_tamper_detected"] = (not c.verify()[0], c.verify()[1])
    c2 = HashChain()
    for i in range(6):
        c2.append({"script": f"S{i}", "mark": 3})
    anchor = c2.head  # head hash held by an independent party
    c2.rewrite_as_single_operator(3, {"script": "S3", "mark": 4})
    out["operator_rewrite_passes_alone"] = c2.verify()[0]
    out["operator_rewrite_caught_by_anchor"] = not c2.verify(anchor)[0]
    c3 = HashChain()
    c3.append({"script": "S9", "mark": 4, "note": "examiner typed 4 but the answer deserved 1"})
    out["false_input_accepted"] = c3.verify()[0]  # chain cannot judge truth of input
    salt, cred = "random-salt-123", {"student": "SYN-0001", "grade": "B"}
    com = commitment(salt, cred)
    out["commitment_matches_with_salt"] = com == commitment(salt, cred)
    out["commitment_after_erasure"] = "unverifiable (salt and record deleted); chain still valid"
    return out


def workflow_tests():
    out = {}
    r = MarkRecord("SYN-1", 2.2)
    for label, kw in (("no_read", dict(role="examiner", mark=2, read_answer=False)),
                      ("override_without_reason", dict(role="examiner", mark=3, read_answer=True)),
                      ("wrong_role", dict(role="moderator", mark=2, read_answer=True)),
                      ("stale_version", dict(role="examiner", mark=2, read_answer=True, expected_version=9))):
        try:
            r.advance("u1", expected_version=kw.pop("expected_version", 1), **kw)
            out[label] = "ACCEPTED (defect)"
        except WorkflowError as e:
            out[label] = f"rejected: {e}"
    r.advance("ex1", "examiner", 1, mark=3, read_answer=True, reason="answer covers four ideas")
    r.advance("mod1", "moderator", 2)
    r.advance("coe1", "controller", 3)
    r.advance("coe1", "controller", 4)
    r.correct("coe1", "controller", 2, "student challenge upheld after re-reading")
    out["final_state"], out["final_mark"], out["audit_entries"] = r.state, r.mark, len(r.audit.blocks)
    out["audit_valid"] = r.audit.verify()[0]
    return out


def main():
    data = D.generate()
    results = {"dataset": {"scripts": len(data), "mode_counts": dict(Counter(m for d in data for m in d["modes"].values())),
                           "scripts_with_negation": sum(d["has_negation"] for d in data)}}
    results["scenario_A_consistent_labels"] = scenario("A", 0.08, data)
    results["scenario_B_inconsistent_NET_labels"] = scenario("B", 0.45, data)
    results["ledger"] = ledger_tests()
    results["workflow"] = workflow_tests()
    results["decision"] = {
        "initial_totals": DEC.totals(DEC.INITIAL), "revised_totals": DEC.totals(DEC.REVISED),
        "initial_winner": DEC.winner(DEC.INITIAL), "revised_winner": DEC.winner(DEC.REVISED),
        "sweep_initial_fairness": DEC.sweep(DEC.INITIAL, "Fairness", [0.10, 0.20, 0.30, 0.40, 0.50]),
        "sweep_initial_usefulness": DEC.sweep(DEC.INITIAL, "Usefulness", [0.10, 0.20, 0.30, 0.40, 0.50]),
        "breakpoint_initial_usefulness": DEC.breakpoint(DEC.INITIAL, "Usefulness"),
        "breakpoint_initial_fairness_down": DEC.sweep(DEC.INITIAL, "Fairness", [0.0, 0.05, 0.1]),
        "breakpoint_revised_usefulness": DEC.breakpoint(DEC.REVISED, "Usefulness"),
        "sweep_revised_cost": DEC.sweep(DEC.REVISED, "Cost", [0.05, 0.15, 0.25, 0.35, 0.45]),
    }
    os.makedirs("results", exist_ok=True)
    with open("results/results.json", "w") as f:
        json.dump(results, f, indent=2, default=str)
    print(json.dumps(results, indent=2, default=str))


if __name__ == "__main__":
    main()
