"""Three scorers. Only KNNScorer is trained; the two rule scorers are deterministic and NOT machine learning."""
import difflib
import math
import re
from collections import Counter

from .data import QUESTIONS

NEG_WORDS = {"not", "no", "never", "without", "cannot"}
TOKEN = re.compile(r"[a-z]+")


def tokens(text):
    return TOKEN.findall(text.lower())


def rule_v1(item):
    """Baseline: one mark per rubric keyword found verbatim."""
    t = item["text"].lower()
    return sum(kw in t for kw, _, _ in QUESTIONS[item["question"]].values())


def _window_match(words, phrase, ratio=0.88):
    n = len(phrase.split())
    target = " ".join(phrase.split())
    for i in range(len(words) - n + 1):
        if difflib.SequenceMatcher(None, " ".join(words[i:i + n]), target).ratio() >= ratio:
            return i
    return -1


def rule_v2(item):
    """Revised rules: fuzzy keyword match, ONE rubric-author synonym per concept, negation guard (4 tokens)."""
    words = tokens(item["text"])
    score = 0
    for kw, paras, _ in QUESTIONS[item["question"]].values():
        pos = _window_match(words, kw)
        if pos >= 0:
            end = pos + len(kw.split())
            # look only OUTSIDE the matched phrase: 4 tokens before, 3 after ("no preemption" contains "no")
            if any(w in NEG_WORDS for w in words[max(0, pos - 4):pos] + words[end:end + 3]):
                continue  # negated mention is not credited
            score += 1
        elif _window_match(words, paras[0], 0.9) >= 0:  # only the first listed synonym is known
            score += 1
    return score


class KNNScorer:
    """Small trained model: TF-IDF (unigram+bigram) cosine k-nearest neighbours over historical marks."""

    def __init__(self, k=5):
        self.k = k

    @staticmethod
    def _grams(text):
        w = tokens(text)
        return w + [a + "_" + b for a, b in zip(w, w[1:])]

    def fit(self, items, marks):
        self.items, self.marks = items, marks
        docs = [Counter(self._grams(d["text"])) for d in items]
        df = Counter(g for d in docs for g in d)
        n = len(docs)
        self.idf = {g: math.log((1 + n) / (1 + c)) + 1 for g, c in df.items()}
        self.vecs = [self._vec(d) for d in docs]
        return self

    def _vec(self, counts):
        v = {g: c * self.idf.get(g, 0.0) for g, c in counts.items() if g in self.idf}
        norm = math.sqrt(sum(x * x for x in v.values())) or 1.0
        return {g: x / norm for g, x in v.items()}

    def predict(self, item):
        """Return (suggested mark, std of neighbour marks). Only same-question neighbours are used."""
        q = self._vec(Counter(self._grams(item["text"])))
        sims = []
        for i, v in enumerate(self.vecs):
            if self.items[i]["question"] != item["question"]:
                continue
            sims.append((sum(x * v.get(g, 0.0) for g, x in q.items()), self.marks[i]))
        top = sorted(sims, reverse=True)[:self.k]
        ms = [m for _, m in top]
        mean = sum(ms) / len(ms)
        std = math.sqrt(sum((m - mean) ** 2 for m in ms) / len(ms))
        return mean, std
