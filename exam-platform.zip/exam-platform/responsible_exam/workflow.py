"""Mark lifecycle with mandatory human steps, recorded overrides, corrections and an audit chain."""
from .ledger import HashChain

FLOW = {"SUGGESTED": "EXAMINER_REVIEWED", "EXAMINER_REVIEWED": "MODERATED", "MODERATED": "APPROVED",
        "APPROVED": "PUBLISHED"}
ROLES = {"EXAMINER_REVIEWED": "examiner", "MODERATED": "moderator", "APPROVED": "controller", "PUBLISHED": "controller"}


class WorkflowError(Exception):
    pass


class MarkRecord:
    def __init__(self, script_id, suggestion, audit=None):
        self.script_id, self.suggestion = script_id, suggestion
        self.state, self.mark, self.version = "SUGGESTED", None, 1
        self.audit = audit if audit is not None else HashChain()
        self._log("created", "system", suggestion=suggestion)

    def _log(self, action, actor, **detail):
        self.audit.append({"script": self.script_id, "action": action, "actor": actor, "version": self.version, **detail})

    def advance(self, actor, role, expected_version, mark=None, read_answer=False, reason=""):
        if expected_version != self.version:
            raise WorkflowError("stale version")
        target = FLOW.get(self.state)
        if target is None:
            raise WorkflowError(f"no transition from {self.state}")
        if role != ROLES[target]:
            raise WorkflowError(f"{target} requires role {ROLES[target]}")
        if target == "EXAMINER_REVIEWED":
            if not read_answer:
                raise WorkflowError("examiner must confirm the answer was read")
            if mark is None:
                raise WorkflowError("examiner must enter a mark")
            if mark != round(self.suggestion) and not reason.strip():
                raise WorkflowError("override of the suggestion needs a recorded reason")
            self.mark = mark
        self.state, self.version = target, self.version + 1
        self._log("advance", actor, to=target, mark=self.mark, reason=reason)

    def correct(self, actor, role, new_mark, reason):
        """Student challenge / disputed record: append a correction, never edit history."""
        if self.state != "PUBLISHED":
            raise WorkflowError("only published marks are corrected")
        if role != "controller" or not reason.strip():
            raise WorkflowError("correction needs the controller role and a reason")
        old, self.mark, self.version = self.mark, new_mark, self.version + 1
        self._log("correction", actor, old=old, new=new_mark, reason=reason)
