import unittest

from responsible_exam import data as D
from responsible_exam import decision as DEC
from responsible_exam.ledger import HashChain
from responsible_exam.scorers import rule_v1, rule_v2
from responsible_exam.workflow import MarkRecord, WorkflowError


def item(text, q="OS"):
    return {"question": q, "text": text}


class ScorerTests(unittest.TestCase):
    def test_baseline_credits_negated_mention(self):
        t = "It does not involve mutual exclusion."
        self.assertEqual(rule_v1(item(t)), 1)   # known weakness of the baseline
        self.assertEqual(rule_v2(item(t)), 0)   # negation guard

    def test_phrase_containing_no_is_credited(self):
        self.assertEqual(rule_v2(item("The system has no preemption of resources.")), 1)

    def test_known_synonym_and_misspelling(self):
        self.assertEqual(rule_v2(item("Processes wait for each other in a cycle.")), 1)
        self.assertEqual(rule_v2(item("This relies on circular wiat.")), 1)

    def test_unknown_paraphrase_missed(self):
        self.assertEqual(rule_v2(item("Each process waits on the next in a ring.")), 0)  # documented limitation

    def test_dataset_is_reproducible_and_synthetic(self):
        a, b = D.generate(), D.generate()
        self.assertEqual([x["text"] for x in a], [x["text"] for x in b])
        self.assertEqual(len(a), 300)
        self.assertTrue(all(x["id"].split("-")[0] in D.QUESTIONS for x in a))


class LedgerTests(unittest.TestCase):
    def make(self):
        c = HashChain()
        for i in range(5):
            c.append({"i": i})
        return c

    def test_tamper_detected(self):
        c = self.make()
        c.blocks[2]["payload"]["i"] = 99
        self.assertEqual(c.verify(), (False, 2))

    def test_single_operator_rewrite_needs_external_anchor(self):
        c = self.make()
        anchor = c.head
        c.rewrite_as_single_operator(2, {"i": 99})
        self.assertTrue(c.verify()[0])
        self.assertFalse(c.verify(anchor)[0])

    def test_false_input_is_not_detected(self):
        c = HashChain()
        c.append({"mark": 4, "truth": "should be 1"})
        self.assertTrue(c.verify()[0])


class WorkflowTests(unittest.TestCase):
    def test_human_gates_and_correction(self):
        r = MarkRecord("S1", 2.2)
        with self.assertRaises(WorkflowError):
            r.advance("u", "examiner", 1, mark=2, read_answer=False)
        with self.assertRaises(WorkflowError):
            r.advance("u", "examiner", 1, mark=3, read_answer=True)       # override without reason
        r.advance("e", "examiner", 1, mark=3, read_answer=True, reason="four ideas")
        with self.assertRaises(WorkflowError):
            r.advance("m", "examiner", 2)                                   # wrong role
        r.advance("m", "moderator", 2)
        r.advance("c", "controller", 3)
        r.advance("c", "controller", 4)
        with self.assertRaises(WorkflowError):
            r.correct("c", "controller", 2, "")                              # reason required
        r.correct("c", "controller", 2, "challenge upheld")
        self.assertEqual((r.state, r.mark), ("PUBLISHED", 2))
        self.assertTrue(r.audit.verify()[0])
        self.assertEqual(r.audit.blocks[-1]["payload"]["old"], 3)           # history kept


class DecisionTests(unittest.TestCase):
    def test_weights_sum_to_one_and_reweight(self):
        self.assertAlmostEqual(sum(DEC.WEIGHTS.values()), 1.0)
        self.assertAlmostEqual(sum(DEC.reweight(DEC.WEIGHTS, "Usefulness", 0.4).values()), 1.0)

    def test_initial_winner_can_flip(self):
        self.assertEqual(DEC.winner(DEC.INITIAL), "A: Rules + human")
        self.assertEqual(DEC.winner(DEC.INITIAL, DEC.reweight(DEC.WEIGHTS, "Usefulness", 0.4)), "B: Trained ML assist")


if __name__ == "__main__":
    unittest.main()
