import { useState, useEffect, useRef } from "react";
import {
  ArrowRight,
  Bus,
  MapPin,
  Calendar,
  Users,
  ChevronRight,
  Wifi,
  Wind,
  Plug,
  CheckCircle2,
  ArrowLeft,
  ArrowLeftRight,
  Clock,
  Star,
  Shield,
  Download,
  RotateCw,
} from "lucide-react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Step = "search" | "results" | "seats" | "confirm" | "done";

interface Trip {
  id: string;
  operator: string;
  from: string;
  to: string;
  depart: string;
  arrive: string;
  duration: string;
  price: number;
  seats: number;
  amenities: string[];
  busType: string;
  rating: number;
}

interface Seat {
  id: string;
  row: number;
  col: number;
  status: "available" | "occupied" | "selected";
}

// ─── Data ────────────────────────────────────────────────────────────────────

const ROUTES = [
  { value: "Lagos", label: "Lagos (LOS)" },
  { value: "Abuja", label: "Abuja (ABJ)" },
  { value: "Port Harcourt", label: "Port Harcourt (PHC)" },
  { value: "Ibadan", label: "Ibadan (IBA)" },
  { value: "Kano", label: "Kano (KAN)" },
  { value: "Benin City", label: "Benin City (BEN)" },
];

const TRIPS: Trip[] = [
  {
    id: "t1",
    operator: "GreenLine Express",
    from: "Lagos",
    to: "Abuja",
    depart: "06:00",
    arrive: "14:30",
    duration: "8h 30m",
    price: 6500,
    seats: 12,
    amenities: ["wifi", "ac", "power"],
    busType: "Luxury Coach",
    rating: 4.8,
  },
  {
    id: "t2",
    operator: "Swift Transit",
    from: "Lagos",
    to: "Abuja",
    depart: "08:15",
    arrive: "16:00",
    duration: "7h 45m",
    price: 5800,
    seats: 4,
    amenities: ["ac", "power"],
    busType: "Executive",
    rating: 4.5,
  },
  {
    id: "t3",
    operator: "Premier Bus",
    from: "Lagos",
    to: "Abuja",
    depart: "10:30",
    arrive: "19:15",
    duration: "8h 45m",
    price: 4200,
    seats: 18,
    amenities: ["ac"],
    busType: "Standard",
    rating: 4.2,
  },
  {
    id: "t4",
    operator: "GreenLine Express",
    from: "Lagos",
    to: "Abuja",
    depart: "13:00",
    arrive: "21:30",
    duration: "8h 30m",
    price: 6500,
    seats: 7,
    amenities: ["wifi", "ac", "power"],
    busType: "Luxury Coach",
    rating: 4.8,
  },
];

function generateSeats(): Seat[] {
  const occupied = new Set([
    "1A","1B","2C","2D","3A","4B","4C","4D","5A","5C","6B","6D","7A","7B","8C",
  ]);
  const seats: Seat[] = [];
  for (let row = 1; row <= 10; row++) {
    ["A","B","C","D"].forEach((col, i) => {
      const id = `${row}${col}`;
      seats.push({ id, row, col: i, status: occupied.has(id) ? "occupied" : "available" });
    });
  }
  return seats;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function AmenityPill({ type }: { type: string }) {
  const map: Record<string, { icon: React.ReactNode; label: string }> = {
    wifi: { icon: <Wifi className="size-3" />, label: "WiFi" },
    ac: { icon: <Wind className="size-3" />, label: "A/C" },
    power: { icon: <Plug className="size-3" />, label: "USB" },
  };
  const item = map[type];
  if (!item) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[10px] font-mono text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
      {item.icon} {item.label}
    </span>
  );
}

function StepDots({ step }: { step: Step }) {
  const steps: Step[] = ["search", "results", "seats", "confirm"];
  const labels = ["Search", "Results", "Seats", "Pay"];
  const current = steps.indexOf(step);
  return (
    <div className="flex items-center gap-1">
      {steps.map((s, i) => (
        <div key={s} className="flex items-center gap-1">
          <div
            className={`flex items-center justify-center rounded-full text-[10px] font-bold transition-all duration-300 ${
              i === current
                ? "size-6 bg-primary text-primary-foreground"
                : i < current
                ? "size-5 bg-primary/20 text-primary"
                : "size-5 bg-muted text-muted-foreground"
            }`}
          >
            {i < current ? "✓" : i + 1}
          </div>
          {/* Label only on sm+ */}
          <span
            className={`hidden sm:inline text-[11px] font-medium ${
              i === current ? "text-foreground" : "text-muted-foreground"
            }`}
          >
            {labels[i]}
          </span>
          {i < steps.length - 1 && (
            <div className={`w-4 sm:w-8 h-px mx-0.5 sm:mx-1 ${i < current ? "bg-primary/40" : "bg-border"}`} />
          )}
        </div>
      ))}
    </div>
  );
}

// ─── Nav ─────────────────────────────────────────────────────────────────────

function Nav({ step, onBack }: { step: Step; onBack: () => void }) {
  const canBack = step !== "search" && step !== "done";
  return (
    <header className="bg-white border-b border-border sticky top-0 z-30 shadow-[0_1px_0_0_rgba(0,0,0,0.06)]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
        {/* Logo + back */}
        <div className="flex items-center gap-2 shrink-0">
          {canBack ? (
            <button
              onClick={onBack}
              className="flex items-center justify-center size-8 rounded-full hover:bg-muted transition-colors text-muted-foreground hover:text-foreground"
              aria-label="Go back"
            >
              <ArrowLeft className="size-4" />
            </button>
          ) : null}
          <div className="flex items-center gap-2">
            <div className="size-7 rounded-lg bg-primary flex items-center justify-center">
              <Bus className="size-4 text-white" />
            </div>
            <span className="font-bold text-base tracking-tight text-foreground">BusGo</span>
          </div>
        </div>

        {/* Steps */}
        {step !== "done" && <StepDots step={step} />}

        {/* Spacer to center steps */}
        <div className="shrink-0 w-[88px] sm:w-[120px]" />
      </div>
    </header>
  );
}

// ─── Step 1: Search ───────────────────────────────────────────────────────────

function SearchStep({
  onSearch,
}: {
  onSearch: (from: string, to: string, date: string, passengers: number) => void;
}) {
  const [from, setFrom] = useState("Lagos");
  const [to, setTo] = useState("Abuja");
  const [date, setDate] = useState("2026-08-15");
  const [passengers, setPassengers] = useState(1);
  const [tripType, setTripType] = useState<"one-way" | "round">("one-way");

  const swap = () => { setFrom(to); setTo(from); };

  return (
    <div className="min-h-[calc(100vh-56px)] bg-background">
      {/* Hero */}
      <div
        className="relative bg-foreground overflow-hidden"
        style={{ background: "linear-gradient(135deg, #111110 0%, #1e1c1a 100%)" }}
      >
        {/* Subtle grid texture */}
        <div
          className="absolute inset-0 opacity-[0.04]"
          style={{
            backgroundImage:
              "linear-gradient(#e85c0d 1px, transparent 1px), linear-gradient(90deg, #e85c0d 1px, transparent 1px)",
            backgroundSize: "48px 48px",
          }}
        />
        <div className="relative max-w-5xl mx-auto px-4 sm:px-6 pt-10 pb-20 sm:pt-16 sm:pb-24">
          <span className="inline-block text-primary text-[11px] font-mono tracking-[0.15em] uppercase mb-4 border border-primary/30 px-2.5 py-1 rounded-full">
            Intercity Bus Booking
          </span>
          <h1 className="text-3xl sm:text-5xl font-bold tracking-tight text-white leading-[1.15] mb-3">
            Where are you<br className="hidden sm:block" /> headed today?
          </h1>
          <p className="text-white/50 text-sm sm:text-base max-w-md">
            Book seats on premium coaches across Nigeria — safe, fast, and confirmed instantly.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-4 sm:px-6 -mt-10 sm:-mt-14 relative z-10">
        {/* Search Card */}
        <div className="bg-card rounded-xl border border-border shadow-xl shadow-black/5 overflow-hidden">
          {/* Trip type tabs */}
          <div className="flex border-b border-border px-5 pt-4">
            {(["one-way", "round"] as const).map((t) => (
              <button
                key={t}
                onClick={() => setTripType(t)}
                className={`relative pb-3 px-1 mr-5 text-sm font-medium transition-colors ${
                  tripType === t ? "text-foreground" : "text-muted-foreground hover:text-foreground"
                }`}
              >
                {t === "one-way" ? "One Way" : "Round Trip"}
                {tripType === t && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary rounded-t-full" />
                )}
              </button>
            ))}
          </div>

          <div className="p-4 sm:p-6">
            {/* From / Swap / To row */}
            <div className="grid grid-cols-1 sm:grid-cols-[1fr_40px_1fr] gap-2 sm:gap-3 mb-3 items-center">
              {/* From */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                  <MapPin className="size-3 text-primary" /> From
                </label>
                <div className="relative">
                  <select
                    value={from}
                    onChange={(e) => setFrom(e.target.value)}
                    className="w-full bg-input-background border border-border rounded-lg px-3 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-primary appearance-none cursor-pointer font-medium transition-colors"
                  >
                    {ROUTES.map((r) => (
                      <option key={r.value} value={r.value}>{r.label}</option>
                    ))}
                  </select>
                  <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground rotate-90 pointer-events-none" />
                </div>
              </div>

              {/* Swap button */}
              <button
                onClick={swap}
                className="self-end mb-0 sm:mb-0 mx-auto sm:mt-5 size-9 rounded-full border border-border bg-card hover:bg-muted hover:border-primary/50 flex items-center justify-center text-muted-foreground hover:text-primary transition-all active:scale-95"
                title="Swap"
              >
                <ArrowLeftRight className="size-3.5" />
              </button>

              {/* To */}
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                  <MapPin className="size-3 text-primary" /> To
                </label>
                <div className="relative">
                  <select
                    value={to}
                    onChange={(e) => setTo(e.target.value)}
                    className="w-full bg-input-background border border-border rounded-lg px-3 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-primary appearance-none cursor-pointer font-medium transition-colors"
                  >
                    {ROUTES.map((r) => (
                      <option key={r.value} value={r.value}>{r.label}</option>
                    ))}
                  </select>
                  <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground rotate-90 pointer-events-none" />
                </div>
              </div>
            </div>

            {/* Date + Passengers row */}
            <div className="grid grid-cols-2 gap-3 mb-5">
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                  <Calendar className="size-3 text-primary" /> Date
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className="bg-input-background border border-border rounded-lg px-3 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-primary transition-colors font-medium"
                />
              </div>
              <div className="flex flex-col gap-1">
                <label className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest flex items-center gap-1">
                  <Users className="size-3 text-primary" /> Passengers
                </label>
                <div className="relative">
                  <select
                    value={passengers}
                    onChange={(e) => setPassengers(Number(e.target.value))}
                    className="w-full bg-input-background border border-border rounded-lg px-3 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-ring/30 focus:border-primary appearance-none cursor-pointer font-medium transition-colors"
                  >
                    {[1,2,3,4,5].map((n) => (
                      <option key={n} value={n}>{n} passenger{n > 1 ? "s" : ""}</option>
                    ))}
                  </select>
                  <ChevronRight className="absolute right-3 top-1/2 -translate-y-1/2 size-3.5 text-muted-foreground rotate-90 pointer-events-none" />
                </div>
              </div>
            </div>

            <button
              onClick={() => onSearch(from, to, date, passengers)}
              className="w-full bg-primary text-white py-3.5 rounded-lg text-sm font-bold hover:bg-primary/90 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-md shadow-primary/20"
            >
              Search Available Buses <ArrowRight className="size-4" />
            </button>
          </div>
        </div>

        {/* Trust badges */}
        <div className="flex flex-wrap justify-center gap-x-6 gap-y-2 mt-5 text-xs text-muted-foreground">
          {[
            { icon: <Shield className="size-3.5 text-green-600" />, text: "Secure booking" },
            { icon: <CheckCircle2 className="size-3.5 text-blue-500" />, text: "Instant confirmation" },
            { icon: <RotateCw className="size-3.5 text-amber-500" />, text: "Easy rescheduling" },
          ].map((b) => (
            <div key={b.text} className="flex items-center gap-1.5">{b.icon}{b.text}</div>
          ))}
        </div>

        {/* Popular routes */}
        <div className="mt-8 mb-12">
          <p className="text-[11px] font-mono text-muted-foreground uppercase tracking-widest mb-3">
            Popular Routes
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {[
              { from: "Lagos", to: "Abuja", price: "₦4,200", time: "8h+" },
              { from: "Lagos", to: "Port Harcourt", price: "₦5,500", time: "6h+" },
              { from: "Abuja", to: "Kano", price: "₦3,800", time: "5h+" },
              { from: "Ibadan", to: "Lagos", price: "₦1,200", time: "2h+" },
            ].map((r) => (
              <button
                key={`${r.from}-${r.to}`}
                onClick={() => { setFrom(r.from); setTo(r.to); }}
                className="text-left bg-card border border-border rounded-xl p-3.5 hover:border-primary/60 hover:shadow-sm hover:bg-accent/50 transition-all group active:scale-[0.98]"
              >
                <div className="flex items-center gap-1 text-sm font-semibold text-foreground mb-1 group-hover:text-primary transition-colors">
                  {r.from}
                  <ArrowRight className="size-3 shrink-0 text-muted-foreground group-hover:text-primary transition-colors" />
                  {r.to}
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-primary font-semibold">{r.price}</span>
                  <span className="text-[10px] text-muted-foreground font-mono">{r.time}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Step 2: Results ──────────────────────────────────────────────────────────

function ResultsStep({
  from, to, date, passengers, onSelect,
}: {
  from: string; to: string; date: string; passengers: number;
  onSelect: (trip: Trip) => void;
}) {
  const [sort, setSort] = useState<"price" | "depart" | "duration">("depart");
  const sorted = [...TRIPS].sort((a, b) => {
    if (sort === "price") return a.price - b.price;
    if (sort === "depart") return a.depart.localeCompare(b.depart);
    return a.duration.localeCompare(b.duration);
  });

  const fmt = new Date(date).toLocaleDateString("en-NG", {
    weekday: "short", day: "numeric", month: "short",
  });

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-24 sm:pb-10">
      {/* Route summary bar */}
      <div className="flex flex-wrap items-center gap-2 mb-5 bg-card border border-border rounded-xl px-4 py-3">
        <div className="flex items-center gap-2 font-bold text-foreground text-base sm:text-lg">
          {from}
          <ArrowRight className="size-4 text-primary" />
          {to}
        </div>
        <div className="flex items-center gap-1.5 text-xs text-muted-foreground ml-auto">
          <span className="font-mono bg-muted px-2 py-0.5 rounded">{fmt}</span>
          <span className="font-mono bg-muted px-2 py-0.5 rounded">
            {passengers} pax
          </span>
        </div>
      </div>

      {/* Sort */}
      <div className="flex items-center gap-2 mb-4">
        <span className="text-xs text-muted-foreground shrink-0">Sort by:</span>
        <div className="flex gap-1.5 flex-wrap">
          {(["depart", "price", "duration"] as const).map((s) => (
            <button
              key={s}
              onClick={() => setSort(s)}
              className={`px-3 py-1 rounded-full text-xs font-medium border transition-colors ${
                sort === s
                  ? "bg-primary text-white border-primary"
                  : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-foreground/20"
              }`}
            >
              {s.charAt(0).toUpperCase() + s.slice(1)}
            </button>
          ))}
        </div>
        <span className="ml-auto text-xs text-muted-foreground font-mono">{sorted.length} found</span>
      </div>

      <div className="flex flex-col gap-3">
        {sorted.map((trip) => (
          <div
            key={trip.id}
            className="bg-card border border-border rounded-xl overflow-hidden hover:border-primary/40 hover:shadow-md hover:shadow-black/4 transition-all duration-200"
          >
            {/* Bus type badge */}
            <div className="px-4 pt-3.5 pb-0 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-sm font-bold text-foreground">{trip.operator}</span>
                <span className="text-[10px] font-mono bg-muted text-muted-foreground px-1.5 py-0.5 rounded">
                  {trip.busType}
                </span>
              </div>
              <div className="flex items-center gap-0.5 text-xs text-amber-500">
                <Star className="size-3 fill-amber-500" />
                <span className="font-semibold text-foreground">{trip.rating}</span>
              </div>
            </div>

            {/* Time row */}
            <div className="px-4 py-3 flex items-center gap-3">
              <div className="w-16 sm:w-20">
                <div className="text-xl sm:text-2xl font-bold text-foreground leading-none">{trip.depart}</div>
                <div className="text-[10px] text-muted-foreground font-mono mt-0.5">{from}</div>
              </div>

              <div className="flex-1 flex flex-col items-center gap-1 min-w-0">
                <span className="text-[10px] font-mono text-muted-foreground">{trip.duration}</span>
                <div className="w-full flex items-center gap-1.5">
                  <div className="flex-1 h-px bg-border" />
                  <div className="size-4 rounded-full border border-border bg-muted flex items-center justify-center shrink-0">
                    <Bus className="size-2.5 text-muted-foreground" />
                  </div>
                  <div className="flex-1 h-px bg-border" />
                </div>
                <span className="text-[10px] font-mono text-green-600 font-semibold">Direct</span>
              </div>

              <div className="w-16 sm:w-20 text-right">
                <div className="text-xl sm:text-2xl font-bold text-foreground leading-none">{trip.arrive}</div>
                <div className="text-[10px] text-muted-foreground font-mono mt-0.5">{to}</div>
              </div>
            </div>

            {/* Bottom row: amenities + price + button */}
            <div className="border-t border-border px-4 py-3 flex items-center justify-between gap-3">
              <div className="flex flex-wrap gap-1 flex-1 min-w-0">
                {trip.amenities.map((a) => <AmenityPill key={a} type={a} />)}
                <span
                  className={`inline-flex text-[10px] font-mono px-1.5 py-0.5 rounded ${
                    trip.seats <= 5
                      ? "bg-red-50 text-red-600"
                      : "bg-green-50 text-green-700"
                  }`}
                >
                  {trip.seats} left
                </span>
              </div>

              <div className="flex items-center gap-3 shrink-0">
                <div className="text-right">
                  <div className="text-base sm:text-xl font-bold text-foreground leading-none">
                    ₦{(trip.price * passengers).toLocaleString()}
                  </div>
                  {passengers > 1 && (
                    <div className="text-[10px] text-muted-foreground">
                      ₦{trip.price.toLocaleString()} each
                    </div>
                  )}
                </div>
                <button
                  onClick={() => onSelect(trip)}
                  className="bg-primary text-white text-xs sm:text-sm font-bold px-4 py-2.5 rounded-lg hover:bg-primary/90 active:scale-95 transition-all shrink-0"
                >
                  Select
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Step 3: Seat Selection ───────────────────────────────────────────────────

function SeatsStep({
  trip, passengers, onConfirm,
}: {
  trip: Trip; passengers: number; onConfirm: (seats: string[]) => void;
}) {
  const [seats, setSeats] = useState<Seat[]>(generateSeats);
  const selected = seats.filter((s) => s.status === "selected").map((s) => s.id);

  const toggle = (id: string) => {
    setSeats((prev) =>
      prev.map((s) => {
        if (s.id !== id || s.status === "occupied") return s;
        if (s.status === "selected") return { ...s, status: "available" };
        if (selected.length >= passengers) return s;
        return { ...s, status: "selected" };
      })
    );
  };

  const COLS = ["A", "B", "C", "D"];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-36 sm:pb-10">
      <div className="grid grid-cols-1 sm:grid-cols-[auto_1fr] gap-6 lg:gap-10">
        {/* Bus map */}
        <div>
          <h2 className="font-bold text-lg text-foreground mb-0.5">Choose your seat{passengers > 1 ? "s" : ""}</h2>
          <p className="text-sm text-muted-foreground mb-5">
            Select {passengers} seat{passengers > 1 ? "s" : ""} · tap to choose
          </p>

          {/* Legend */}
          <div className="flex gap-4 mb-5 text-xs text-muted-foreground">
            {[
              { cls: "bg-muted border border-border", label: "Available" },
              { cls: "bg-primary border-primary", label: "Selected" },
              { cls: "bg-foreground/8 border border-border opacity-40", label: "Taken" },
            ].map((l) => (
              <div key={l.label} className="flex items-center gap-1.5">
                <div className={`size-4 rounded ${l.cls}`} />
                {l.label}
              </div>
            ))}
          </div>

          {/* Bus */}
          <div className="inline-block border-2 border-border rounded-2xl p-4 sm:p-5 bg-card shadow-sm">
            {/* Windshield */}
            <div className="flex items-center justify-between mb-4 border-b border-border pb-3">
              <div className="text-[10px] font-mono text-muted-foreground uppercase tracking-widest">Front</div>
              <div className="h-3 w-20 rounded-full bg-muted/80 border border-border" />
              <div className="text-[10px] font-mono text-muted-foreground">Driver</div>
            </div>

            {/* Col headers */}
            <div className="grid grid-cols-[20px_36px_36px_12px_36px_36px] gap-1 mb-1 text-center">
              <div />
              {["A","B","","C","D"].map((c, i) => (
                <div key={i} className="text-[10px] font-mono text-muted-foreground font-bold">{c}</div>
              ))}
            </div>

            {/* Rows */}
            {Array.from({ length: 10 }, (_, ri) => ri + 1).map((row) => {
              const rowSeats = seats.filter((s) => s.row === row);
              return (
                <div key={row} className="grid grid-cols-[20px_36px_36px_12px_36px_36px] gap-1 mb-1.5 items-center">
                  <div className="text-[10px] font-mono text-muted-foreground text-right pr-1">{row}</div>
                  {[0, 1].map((ci) => {
                    const seat = rowSeats[ci];
                    return (
                      <button
                        key={seat.id}
                        onClick={() => toggle(seat.id)}
                        disabled={seat.status === "occupied"}
                        className={`h-9 w-full rounded-lg text-[10px] font-mono font-bold transition-all active:scale-90 ${
                          seat.status === "occupied"
                            ? "bg-muted border border-border text-border opacity-40 cursor-not-allowed"
                            : seat.status === "selected"
                            ? "bg-primary border-2 border-primary/80 text-white shadow-md shadow-primary/30"
                            : "bg-white border border-border text-muted-foreground hover:border-primary hover:text-primary hover:bg-accent"
                        }`}
                      >
                        {seat.id}
                      </button>
                    );
                  })}
                  {/* Aisle */}
                  <div className="flex justify-center">
                    <div className="w-px h-4 bg-border" />
                  </div>
                  {[2, 3].map((ci) => {
                    const seat = rowSeats[ci];
                    return (
                      <button
                        key={seat.id}
                        onClick={() => toggle(seat.id)}
                        disabled={seat.status === "occupied"}
                        className={`h-9 w-full rounded-lg text-[10px] font-mono font-bold transition-all active:scale-90 ${
                          seat.status === "occupied"
                            ? "bg-muted border border-border text-border opacity-40 cursor-not-allowed"
                            : seat.status === "selected"
                            ? "bg-primary border-2 border-primary/80 text-white shadow-md shadow-primary/30"
                            : "bg-white border border-border text-muted-foreground hover:border-primary hover:text-primary hover:bg-accent"
                        }`}
                      >
                        {seat.id}
                      </button>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>

        {/* Summary — hidden on mobile (replaced by sticky bar) */}
        <div className="hidden sm:flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5 sticky top-20">
            <h3 className="font-bold text-sm text-foreground mb-4">Trip Summary</h3>
            <div className="space-y-2.5 text-sm">
              {[
                ["Operator", trip.operator],
                ["Bus Type", trip.busType],
                ["Departs", trip.depart],
                ["Arrives", trip.arrive],
                ["Duration", trip.duration],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-muted-foreground">{k}</span>
                  <span className="font-medium text-foreground">{v}</span>
                </div>
              ))}
              <div className="h-px bg-border" />
              <div className="flex justify-between">
                <span className="text-muted-foreground">Seats</span>
                <span className="font-mono text-sm text-foreground">
                  {selected.length > 0 ? selected.join(", ") : "—"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Price / seat</span>
                <span className="font-mono">₦{trip.price.toLocaleString()}</span>
              </div>
              <div className="h-px bg-border" />
              <div className="flex justify-between font-bold text-base">
                <span>Total</span>
                <span className="text-primary">₦{(trip.price * selected.length).toLocaleString()}</span>
              </div>
            </div>

            <button
              onClick={() => onConfirm(selected)}
              disabled={selected.length !== passengers}
              className="mt-5 w-full bg-primary text-white py-3 rounded-lg font-bold text-sm hover:bg-primary/90 transition-all disabled:opacity-40 disabled:cursor-not-allowed active:scale-[0.99]"
            >
              {selected.length === passengers
                ? "Continue to Checkout"
                : `Select ${passengers - selected.length} more seat${passengers - selected.length > 1 ? "s" : ""}`}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile sticky bottom bar */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border px-4 py-3 shadow-2xl">
        <div className="flex items-center justify-between mb-2.5">
          <div>
            <div className="text-xs text-muted-foreground">
              {selected.length}/{passengers} seats selected
              {selected.length > 0 && (
                <span className="ml-2 font-mono text-foreground">· {selected.join(", ")}</span>
              )}
            </div>
            <div className="text-lg font-bold text-primary">
              ₦{(trip.price * selected.length).toLocaleString()}
            </div>
          </div>
          <button
            onClick={() => onConfirm(selected)}
            disabled={selected.length !== passengers}
            className="bg-primary text-white px-5 py-3 rounded-xl font-bold text-sm hover:bg-primary/90 active:scale-95 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Continue →
          </button>
        </div>
        {/* Progress dots */}
        <div className="flex gap-1">
          {Array.from({ length: passengers }).map((_, i) => (
            <div
              key={i}
              className={`h-1 flex-1 rounded-full transition-all ${
                i < selected.length ? "bg-primary" : "bg-border"
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Step 4: Confirm ──────────────────────────────────────────────────────────

function ConfirmStep({
  trip, seats, passengers, date, onBook,
}: {
  trip: Trip; seats: string[]; passengers: number; date: string; onBook: () => void;
}) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [payMethod, setPayMethod] = useState("card");
  const [errors, setErrors] = useState<Record<string, string>>({});

  const validate = () => {
    const e: Record<string, string> = {};
    if (!name.trim()) e.name = "Full name is required";
    if (!email.includes("@")) e.email = "Valid email required";
    if (phone.length < 10) e.phone = "Valid phone required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const total = trip.price * passengers + 150 * passengers;

  const fmt = new Date(date).toLocaleDateString("en-NG", {
    weekday: "short", day: "numeric", month: "short", year: "numeric",
  });

  const payMethods = [
    { id: "card", label: "Debit / Credit Card", sub: "Visa, Mastercard, Verve" },
    { id: "transfer", label: "Bank Transfer", sub: "Instant confirmation" },
    { id: "ussd", label: "USSD", sub: "Dial *901# and more" },
  ];

  const Field = ({
    label, value, onChange, type = "text", placeholder, error,
  }: {
    label: string; value: string; onChange: (v: string) => void;
    type?: string; placeholder: string; error?: string;
  }) => (
    <div>
      <label className="block text-xs font-semibold text-foreground mb-1.5">{label}</label>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className={`w-full bg-input-background border rounded-lg px-3.5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/20 focus:border-primary transition-colors ${
          error ? "border-destructive" : "border-border"
        }`}
      />
      {error && <p className="text-xs text-destructive mt-1.5 flex items-center gap-1">⚠ {error}</p>}
    </div>
  );

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 pb-36 sm:pb-10">
      {/* On mobile: summary first */}
      <div className="sm:hidden mb-5">
        <div className="bg-foreground text-primary-foreground rounded-xl p-4">
          <div className="flex items-center justify-between mb-3">
            <div className="font-bold text-white">{trip.from} → {trip.to}</div>
            <div className="text-xs font-mono text-white/50">{fmt}</div>
          </div>
          <div className="flex items-center gap-3">
            <div>
              <div className="text-xl font-bold text-white">{trip.depart}</div>
              <div className="text-xs text-white/40">{trip.from}</div>
            </div>
            <div className="flex-1 h-px bg-white/20" />
            <div className="text-xs font-mono text-white/50">{trip.duration}</div>
            <div className="flex-1 h-px bg-white/20" />
            <div className="text-right">
              <div className="text-xl font-bold text-white">{trip.arrive}</div>
              <div className="text-xs text-white/40">{trip.to}</div>
            </div>
          </div>
          <div className="mt-3 pt-3 border-t border-white/10 flex items-center justify-between">
            <div className="text-xs text-white/50">Seats: <span className="text-white font-mono">{seats.join(", ")}</span></div>
            <div className="font-bold text-primary text-lg">₦{total.toLocaleString()}</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-[1fr_320px] gap-6">
        {/* Left: form */}
        <div className="space-y-6">
          {/* Passenger */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-bold text-base text-foreground mb-4">Passenger Details</h2>
            <div className="space-y-4">
              <Field label="Full Name" value={name} onChange={setName} placeholder="Adesola Adeyemi" error={errors.name} />
              <Field label="Email Address" value={email} onChange={setEmail} type="email" placeholder="adesola@email.com" error={errors.email} />
              <Field label="Phone Number" value={phone} onChange={setPhone} type="tel" placeholder="+234 801 234 5678" error={errors.phone} />
            </div>
          </div>

          {/* Payment */}
          <div className="bg-card border border-border rounded-xl p-5">
            <h2 className="font-bold text-base text-foreground mb-4">Payment Method</h2>
            <div className="space-y-2.5">
              {payMethods.map((pm) => (
                <label
                  key={pm.id}
                  className={`flex items-center gap-3 p-3.5 rounded-xl border cursor-pointer transition-all ${
                    payMethod === pm.id
                      ? "border-primary bg-accent shadow-sm"
                      : "border-border hover:bg-muted"
                  }`}
                >
                  <div
                    className={`size-4 rounded-full border-2 flex items-center justify-center shrink-0 ${
                      payMethod === pm.id ? "border-primary" : "border-border"
                    }`}
                  >
                    {payMethod === pm.id && <div className="size-2 rounded-full bg-primary" />}
                  </div>
                  <input
                    type="radio"
                    name="payment"
                    value={pm.id}
                    checked={payMethod === pm.id}
                    onChange={() => setPayMethod(pm.id)}
                    className="sr-only"
                  />
                  <div>
                    <div className="text-sm font-semibold text-foreground">{pm.label}</div>
                    <div className="text-xs text-muted-foreground">{pm.sub}</div>
                  </div>
                </label>
              ))}
            </div>
          </div>
        </div>

        {/* Right: order summary (desktop) */}
        <div className="hidden sm:flex flex-col gap-4">
          <div className="bg-card border border-border rounded-xl p-5 sticky top-20">
            <h3 className="font-bold text-sm text-foreground mb-4">Order Summary</h3>
            <div className="space-y-2.5 text-sm">
              {[
                ["Route", `${trip.from} → ${trip.to}`],
                ["Date", fmt],
                ["Operator", trip.operator],
                ["Departs", trip.depart],
                ["Seats", seats.join(", ")],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between">
                  <span className="text-muted-foreground">{k}</span>
                  <span className="font-medium text-right max-w-[160px]">{v}</span>
                </div>
              ))}
              <div className="h-px bg-border my-1" />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>₦{trip.price.toLocaleString()} × {passengers}</span>
                <span>₦{(trip.price * passengers).toLocaleString()}</span>
              </div>
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>Service fee</span>
                <span>₦{(150 * passengers).toLocaleString()}</span>
              </div>
              <div className="h-px bg-border my-1" />
              <div className="flex justify-between font-bold text-base">
                <span>Total</span>
                <span className="text-primary">₦{total.toLocaleString()}</span>
              </div>
            </div>
            <button
              onClick={() => { if (validate()) onBook(); }}
              className="mt-5 w-full bg-primary text-white py-3.5 rounded-xl font-bold text-sm hover:bg-primary/90 active:scale-[0.99] transition-all flex items-center justify-center gap-2 shadow-lg shadow-primary/20"
            >
              <Shield className="size-4" /> Confirm & Pay ₦{total.toLocaleString()}
            </button>
            <p className="text-[10px] text-center text-muted-foreground mt-2.5">
              Your e-ticket will be sent to your email after payment
            </p>
          </div>
        </div>
      </div>

      {/* Mobile sticky pay button */}
      <div className="sm:hidden fixed bottom-0 left-0 right-0 z-40 bg-card border-t border-border px-4 py-3 shadow-2xl">
        <div className="flex items-center justify-between mb-2.5">
          <div>
            <div className="text-xs text-muted-foreground">Total amount</div>
            <div className="text-xl font-bold text-primary">₦{total.toLocaleString()}</div>
          </div>
          <button
            onClick={() => { if (validate()) onBook(); }}
            className="bg-primary text-white px-6 py-3.5 rounded-xl font-bold text-sm hover:bg-primary/90 active:scale-95 transition-all flex items-center gap-2"
          >
            <Shield className="size-4" /> Pay Now
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Step 5: Done ─────────────────────────────────────────────────────────────

function DoneStep({
  trip, seats, date, passengers, onRestart,
}: {
  trip: Trip; seats: string[]; date: string; passengers: number; onRestart: () => void;
}) {
  const [ref] = useState(() => `BG-${Math.random().toString(36).slice(2, 8).toUpperCase()}`);

  const fmt = new Date(date).toLocaleDateString("en-NG", {
    weekday: "long", day: "numeric", month: "long", year: "numeric",
  });

  return (
    <div className="min-h-[calc(100vh-56px)] bg-background">
      <div className="max-w-lg mx-auto px-4 sm:px-6 py-10 sm:py-16 flex flex-col items-center">
        {/* Success icon */}
        <div className="relative mb-6">
          <div className="size-20 rounded-full bg-green-50 border-4 border-green-100 flex items-center justify-center">
            <CheckCircle2 className="size-9 text-green-500" />
          </div>
          <div className="absolute -right-1 -top-1 size-6 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">
            ✓
          </div>
        </div>

        <h1 className="text-2xl sm:text-3xl font-bold text-foreground mb-2 text-center">
          Booking Confirmed!
        </h1>
        <p className="text-muted-foreground text-sm text-center mb-8 max-w-xs">
          Your e-ticket has been sent to your email address. Enjoy your journey!
        </p>

        {/* Ticket card */}
        <div className="w-full bg-card rounded-2xl overflow-hidden shadow-xl border border-border">
          {/* Header */}
          <div className="bg-foreground px-5 py-4 flex items-center justify-between"
            style={{ background: "linear-gradient(135deg, #111110 0%, #1e1c1a 100%)" }}
          >
            <div className="flex items-center gap-2.5">
              <div className="size-7 rounded-lg bg-primary flex items-center justify-center">
                <Bus className="size-4 text-white" />
              </div>
              <span className="font-bold text-white text-base">BusGo</span>
            </div>
            <div className="text-right">
              <div className="text-[10px] text-white/40 font-mono uppercase tracking-wider">Booking Ref</div>
              <div className="font-mono font-bold text-primary text-sm">{ref}</div>
            </div>
          </div>

          {/* Route */}
          <div className="px-5 py-5 flex items-center gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-foreground leading-none">{trip.depart}</div>
              <div className="text-xs text-muted-foreground mt-1 font-medium">{trip.from}</div>
            </div>
            <div className="flex-1 flex flex-col items-center gap-1.5">
              <span className="text-[10px] font-mono text-muted-foreground">{trip.duration}</span>
              <div className="w-full flex items-center gap-2">
                <div className="flex-1 h-px bg-border" />
                <div className="size-5 rounded-full bg-primary/10 border border-primary/30 flex items-center justify-center">
                  <Bus className="size-2.5 text-primary" />
                </div>
                <div className="flex-1 h-px bg-border" />
              </div>
              <span className="text-[10px] font-mono text-green-600 font-bold">DIRECT</span>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-foreground leading-none">{trip.arrive}</div>
              <div className="text-xs text-muted-foreground mt-1 font-medium">{trip.to}</div>
            </div>
          </div>

          {/* Tear line */}
          <div className="flex items-center gap-0 -mx-0 relative">
            <div className="size-5 rounded-full bg-background border-r border-border absolute -left-2.5" />
            <div className="flex-1 border-t-2 border-dashed border-border mx-5" />
            <div className="size-5 rounded-full bg-background border-l border-border absolute -right-2.5" />
          </div>

          {/* Details */}
          <div className="grid grid-cols-3 px-5 py-4 gap-3">
            {[
              { label: "Date", value: fmt.split(",").slice(0, 2).join(",") },
              { label: "Seat(s)", value: seats.join(", ") },
              { label: "Class", value: trip.busType },
            ].map((d) => (
              <div key={d.label}>
                <div className="text-[9px] font-mono text-muted-foreground uppercase tracking-widest mb-0.5">
                  {d.label}
                </div>
                <div className="text-xs font-bold text-foreground leading-tight">{d.value}</div>
              </div>
            ))}
          </div>

          {/* Barcode */}
          <div className="px-5 py-3.5 bg-muted flex items-center justify-between border-t border-border">
            <div className="text-[10px] text-muted-foreground font-mono">
              {passengers} pax · {trip.operator}
            </div>
            <div className="flex items-end gap-px h-7">
              {Array.from({ length: 38 }, (_, i) => (
                <div
                  key={i}
                  className="bg-foreground/70 rounded-sm"
                  style={{
                    width: [1, 2, 1, 3, 1, 2][i % 6],
                    height: `${55 + Math.sin(i * 1.3) * 30}%`,
                  }}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-3 w-full mt-7">
          <button className="flex-1 flex items-center justify-center gap-2 border border-border px-5 py-3 rounded-xl text-sm font-semibold text-foreground hover:bg-muted active:scale-95 transition-all">
            <Download className="size-4" /> Download PDF
          </button>
          <button
            onClick={onRestart}
            className="flex-1 flex items-center justify-center gap-2 bg-primary text-white px-5 py-3 rounded-xl text-sm font-bold hover:bg-primary/90 active:scale-95 transition-all shadow-md shadow-primary/20"
          >
            Book Another Trip <ArrowRight className="size-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── App ─────────────────────────────────────────────────────────────────────

export default function App() {
  const [step, setStep] = useState<Step>("search");
  const [from, setFrom] = useState("Lagos");
  const [to, setTo] = useState("Abuja");
  const [date, setDate] = useState("2026-08-15");
  const [passengers, setPassengers] = useState(1);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);

  useEffect(() => { window.scrollTo({ top: 0, behavior: "smooth" }); }, [step]);

  const goBack = () => {
    if (step === "results") setStep("search");
    else if (step === "seats") setStep("results");
    else if (step === "confirm") setStep("seats");
  };

  const restart = () => {
    setStep("search");
    setSelectedTrip(null);
    setSelectedSeats([]);
  };

  return (
    <div className="min-h-screen bg-background" style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {step !== "done" && <Nav step={step} onBack={goBack} />}

      {step === "search" && (
        <SearchStep
          onSearch={(f, t, d, p) => {
            setFrom(f); setTo(t); setDate(d); setPassengers(p);
            setStep("results");
          }}
        />
      )}

      {step === "results" && (
        <ResultsStep
          from={from} to={to} date={date} passengers={passengers}
          onSelect={(trip) => { setSelectedTrip(trip); setStep("seats"); }}
        />
      )}

      {step === "seats" && selectedTrip && (
        <SeatsStep
          trip={selectedTrip} passengers={passengers}
          onConfirm={(s) => { setSelectedSeats(s); setStep("confirm"); }}
        />
      )}

      {step === "confirm" && selectedTrip && (
        <ConfirmStep
          trip={selectedTrip} seats={selectedSeats}
          passengers={passengers} date={date}
          onBook={() => setStep("done")}
        />
      )}

      {step === "done" && selectedTrip && (
        <DoneStep
          trip={selectedTrip} seats={selectedSeats}
          date={date} passengers={passengers}
          onRestart={restart}
        />
      )}
    </div>
  );
}
