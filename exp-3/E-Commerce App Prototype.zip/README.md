
  # E-Commerce App Prototype

  This is a code bundle for E-Commerce App Prototype. The original project is available at https://www.figma.com/design/kgzJu18hBSsu18mAycQ8SS/E-Commerce-App-Prototype.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  