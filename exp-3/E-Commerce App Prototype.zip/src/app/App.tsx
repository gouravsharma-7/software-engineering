import { useState } from "react";
import {
  Search, ShoppingBag, Heart, Home, Grid, User, ArrowLeft,
  Star, Minus, Plus, ChevronRight, MapPin, CreditCard,
  Check, Bell, Filter, SlidersHorizontal, X, Package,
  Truck, RotateCcw, Shield, ChevronDown
} from "lucide-react";

type Screen = "home" | "product" | "cart" | "checkout" | "confirmation" | "profile" | "search";

interface Product {
  id: number;
  name: string;
  brand: string;
  price: number;
  originalPrice?: number;
  rating: number;
  reviews: number;
  image: string;
  tag?: string;
  category: string;
}

const products: Product[] = [
  {
    id: 1,
    name: "Merino Wool Coat",
    brand: "Maison Libre",
    price: 485,
    originalPrice: 620,
    rating: 4.8,
    reviews: 142,
    image: "https://images.unsplash.com/photo-1544022613-e87ca75a784a?w=600&h=750&fit=crop&auto=format",
    tag: "Sale",
    category: "Outerwear",
  },
  {
    id: 2,
    name: "Structured Blazer",
    brand: "Atelier Nord",
    price: 320,
    rating: 4.6,
    reviews: 89,
    image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?w=600&h=750&fit=crop&auto=format",
    tag: "New",
    category: "Jackets",
  },
  {
    id: 3,
    name: "Cashmere Turtleneck",
    brand: "Maison Libre",
    price: 195,
    rating: 4.9,
    reviews: 214,
    image: "https://images.unsplash.com/photo-1576566588028-4147f3842f27?w=600&h=750&fit=crop&auto=format",
    category: "Knitwear",
  },
  {
    id: 4,
    name: "Wide-Leg Trousers",
    brand: "Studio Cove",
    price: 265,
    rating: 4.7,
    reviews: 67,
    image: "https://images.unsplash.com/photo-1509631179647-0177331693ae?w=600&h=750&fit=crop&auto=format",
    tag: "Trending",
    category: "Trousers",
  },
  {
    id: 5,
    name: "Silk Midi Dress",
    brand: "Atelier Nord",
    price: 340,
    rating: 4.5,
    reviews: 103,
    image: "https://images.unsplash.com/photo-1515372039744-b8f02a3ae446?w=600&h=750&fit=crop&auto=format",
    category: "Dresses",
  },
  {
    id: 6,
    name: "Leather Ankle Boot",
    brand: "Forme Studio",
    price: 420,
    originalPrice: 520,
    rating: 4.8,
    reviews: 178,
    image: "https://images.unsplash.com/photo-1543163521-1bf539c55dd2?w=600&h=750&fit=crop&auto=format",
    tag: "Sale",
    category: "Footwear",
  },
];

const categories = ["All", "Outerwear", "Jackets", "Knitwear", "Dresses", "Trousers", "Footwear"];

interface CartItem extends Product {
  qty: number;
  size: string;
}

export default function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [selectedProduct, setSelectedProduct] = useState<Product>(products[0]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<number[]>([]);
  const [selectedSize, setSelectedSize] = useState("M");
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [qty, setQty] = useState(1);
  const [searchQuery, setSearchQuery] = useState("");

  const cartCount = cart.reduce((s, i) => s + i.qty, 0);
  const cartTotal = cart.reduce((s, i) => s + i.price * i.qty, 0);

  const filteredProducts = selectedCategory === "All"
    ? products
    : products.filter(p => p.category === selectedCategory);

  const addToCart = () => {
    setCart(prev => {
      const existing = prev.find(i => i.id === selectedProduct.id && i.size === selectedSize);
      if (existing) {
        return prev.map(i => i.id === selectedProduct.id && i.size === selectedSize
          ? { ...i, qty: i.qty + qty }
          : i
        );
      }
      return [...prev, { ...selectedProduct, qty, size: selectedSize }];
    });
    setScreen("cart");
  };

  const toggleWishlist = (id: number) => {
    setWishlist(prev => prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]);
  };

  const updateQty = (id: number, size: string, delta: number) => {
    setCart(prev => prev
      .map(i => i.id === id && i.size === size ? { ...i, qty: i.qty + delta } : i)
      .filter(i => i.qty > 0)
    );
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4 md:p-8"
      style={{ fontFamily: "'DM Sans', sans-serif" }}>
      {/* Phone frame */}
      <div className="w-full max-w-[390px] bg-card rounded-[2.5rem] shadow-2xl overflow-hidden relative"
        style={{ minHeight: "844px", boxShadow: "0 32px 80px rgba(26,23,20,0.18), 0 8px 24px rgba(26,23,20,0.12)" }}>

        {/* Status bar */}
        <div className="bg-card px-6 pt-4 pb-2 flex justify-between items-center">
          <span className="text-xs font-medium text-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>9:41</span>
          <div className="flex gap-1.5 items-center">
            <div className="w-4 h-2 border border-foreground rounded-sm relative">
              <div className="absolute inset-[2px] right-[4px] bg-foreground rounded-sm" />
              <div className="absolute right-[-3px] top-[3px] w-[2px] h-[6px] bg-foreground rounded-full" style={{ top: "3px" }} />
            </div>
          </div>
        </div>

        {/* Screen content */}
        <div className="overflow-y-auto" style={{ height: "760px", scrollbarWidth: "none" }}>
          {screen === "home" && <HomeScreen
            products={filteredProducts}
            categories={categories}
            selectedCategory={selectedCategory}
            setSelectedCategory={setSelectedCategory}
            wishlist={wishlist}
            toggleWishlist={toggleWishlist}
            cartCount={cartCount}
            onProduct={(p) => { setSelectedProduct(p); setScreen("product"); setQty(1); setSelectedSize("M"); }}
            onSearch={() => setScreen("search")}
            onCart={() => setScreen("cart")}
          />}
          {screen === "search" && <SearchScreen
            query={searchQuery}
            setQuery={setSearchQuery}
            products={products}
            onBack={() => setScreen("home")}
            onProduct={(p) => { setSelectedProduct(p); setScreen("product"); setQty(1); setSelectedSize("M"); }}
            wishlist={wishlist}
            toggleWishlist={toggleWishlist}
          />}
          {screen === "product" && <ProductScreen
            product={selectedProduct}
            selectedSize={selectedSize}
            setSelectedSize={setSelectedSize}
            qty={qty}
            setQty={setQty}
            wishlist={wishlist}
            toggleWishlist={toggleWishlist}
            onBack={() => setScreen("home")}
            onCart={() => setScreen("cart")}
            onAddToCart={addToCart}
            cartCount={cartCount}
          />}
          {screen === "cart" && <CartScreen
            cart={cart}
            total={cartTotal}
            updateQty={updateQty}
            onBack={() => setScreen("home")}
            onCheckout={() => setScreen("checkout")}
            onProduct={(p) => { setSelectedProduct(p); setScreen("product"); }}
          />}
          {screen === "checkout" && <CheckoutScreen
            total={cartTotal}
            onBack={() => setScreen("cart")}
            onConfirm={() => setScreen("confirmation")}
          />}
          {screen === "confirmation" && <ConfirmationScreen
            onContinue={() => { setCart([]); setScreen("home"); }}
          />}
          {screen === "profile" && <ProfileScreen onBack={() => setScreen("home")} />}
        </div>

        {/* Bottom nav */}
        {(screen === "home" || screen === "profile" || screen === "search") && (
          <BottomNav
            screen={screen}
            cartCount={cartCount}
            onHome={() => setScreen("home")}
            onSearch={() => setScreen("search")}
            onCart={() => setScreen("cart")}
            onProfile={() => setScreen("profile")}
          />
        )}
      </div>

      {/* Desktop annotation */}
      <div className="hidden md:block ml-12 max-w-xs">
        <div className="mb-6">
          <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1"
            style={{ fontFamily: "'DM Mono', monospace" }}>Stakeholder Prototype</p>
          <h1 className="text-3xl font-bold text-foreground leading-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}>Maison<br />Commerce</h1>
          <p className="text-sm text-muted-foreground mt-3 leading-relaxed">
            Mobile-first e-commerce experience. Navigate through the app to explore the full user journey.
          </p>
        </div>
        <div className="space-y-3">
          {[
            { label: "Home & Discovery", hint: "Browse, filter, search products" },
            { label: "Product Detail", hint: "Size selection, add to cart, wishlist" },
            { label: "Cart & Checkout", hint: "Order summary, payment flow" },
            { label: "Confirmation", hint: "Order success state" },
            { label: "Profile", hint: "Account, orders, preferences" },
          ].map(({ label, hint }) => (
            <div key={label} className="flex gap-3 items-start">
              <div className="w-1.5 h-1.5 rounded-full mt-2 flex-shrink-0" style={{ background: "#C9923A" }} />
              <div>
                <p className="text-sm font-medium text-foreground">{label}</p>
                <p className="text-xs text-muted-foreground">{hint}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="mt-8 pt-6 border-t border-border">
          <p className="text-xs text-muted-foreground" style={{ fontFamily: "'DM Mono', monospace" }}>
            Version 1.0 — For review only
          </p>
        </div>
      </div>
    </div>
  );
}

/* ─── Bottom Nav ─── */
function BottomNav({ screen, cartCount, onHome, onSearch, onCart, onProfile }: {
  screen: Screen; cartCount: number;
  onHome: () => void; onSearch: () => void; onCart: () => void; onProfile: () => void;
}) {
  return (
    <div className="absolute bottom-0 left-0 right-0 bg-card border-t border-border px-6 pb-6 pt-3">
      <div className="flex justify-around items-center">
        {[
          { icon: Home, label: "Home", active: screen === "home", action: onHome },
          { icon: Search, label: "Search", active: screen === "search", action: onSearch },
          { icon: ShoppingBag, label: "Cart", active: false, action: onCart, badge: cartCount },
          { icon: User, label: "Profile", active: screen === "profile", action: onProfile },
        ].map(({ icon: Icon, label, active, action, badge }) => (
          <button key={label} onClick={action}
            className="flex flex-col items-center gap-1 relative"
            style={{ color: active ? "#C9923A" : "#8A7F74" }}>
            <div className="relative">
              <Icon size={22} strokeWidth={active ? 2.5 : 1.8} />
              {badge ? (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full text-white flex items-center justify-center"
                  style={{ fontSize: "9px", background: "#C9923A" }}>{badge}</span>
              ) : null}
            </div>
            <span className="text-[10px] font-medium">{label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

/* ─── Home Screen ─── */
function HomeScreen({ products, categories, selectedCategory, setSelectedCategory, wishlist, toggleWishlist, cartCount, onProduct, onSearch, onCart }: {
  products: Product[]; categories: string[]; selectedCategory: string;
  setSelectedCategory: (c: string) => void; wishlist: number[];
  toggleWishlist: (id: number) => void; cartCount: number;
  onProduct: (p: Product) => void; onSearch: () => void; onCart: () => void;
}) {
  return (
    <div className="pb-24">
      {/* Header */}
      <div className="px-5 pt-2 pb-4">
        <div className="flex justify-between items-center mb-5">
          <div>
            <p className="text-xs text-muted-foreground tracking-widest uppercase"
              style={{ fontFamily: "'DM Mono', monospace" }}>Good morning</p>
            <h2 className="text-xl font-bold text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}>Discover</h2>
          </div>
          <div className="flex gap-3 items-center">
            <button className="relative p-2">
              <Bell size={20} strokeWidth={1.8} className="text-foreground" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full" style={{ background: "#C9923A" }} />
            </button>
            <button onClick={onCart} className="relative p-2">
              <ShoppingBag size={20} strokeWidth={1.8} className="text-foreground" />
              {cartCount > 0 && (
                <span className="absolute top-0.5 right-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center"
                  style={{ fontSize: "9px", background: "#C9923A" }}>{cartCount}</span>
              )}
            </button>
          </div>
        </div>

        {/* Search bar */}
        <button onClick={onSearch}
          className="w-full flex items-center gap-3 px-4 py-3 rounded-xl border border-border text-left"
          style={{ background: "#EDE9E3" }}>
          <Search size={16} className="text-muted-foreground" />
          <span className="text-sm text-muted-foreground">Search for styles, brands...</span>
        </button>
      </div>

      {/* Hero banner */}
      <div className="mx-5 mb-5 rounded-2xl overflow-hidden relative" style={{ height: "180px" }}>
        <img
          src="https://images.unsplash.com/photo-1490481651871-ab68de25d43d?w=800&h=400&fit=crop&auto=format"
          alt="Season collection hero"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0" style={{ background: "linear-gradient(135deg, rgba(26,23,20,0.7) 0%, rgba(26,23,20,0.1) 100%)" }} />
        <div className="absolute bottom-4 left-4">
          <p className="text-xs text-white/70 tracking-widest uppercase mb-1"
            style={{ fontFamily: "'DM Mono', monospace" }}>New Season</p>
          <p className="text-2xl font-bold text-white leading-tight"
            style={{ fontFamily: "'Playfair Display', serif" }}>Autumn/<br />Winter '25</p>
          <button className="mt-2 px-3 py-1.5 rounded-lg text-xs font-medium text-foreground"
            style={{ background: "#F9F7F4" }}>
            Shop Now
          </button>
        </div>
      </div>

      {/* Categories */}
      <div className="px-5 mb-4">
        <div className="flex gap-2 overflow-x-auto pb-1" style={{ scrollbarWidth: "none" }}>
          {categories.map(cat => (
            <button key={cat} onClick={() => setSelectedCategory(cat)}
              className="flex-shrink-0 px-4 py-2 rounded-full text-xs font-medium transition-all"
              style={{
                background: selectedCategory === cat ? "#1A1714" : "#EDE9E3",
                color: selectedCategory === cat ? "#F9F7F4" : "#8A7F74",
              }}>
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Products grid */}
      <div className="px-5">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-sm font-semibold text-foreground"
            style={{ fontFamily: "'Playfair Display', serif" }}>
            {selectedCategory === "All" ? "Featured Pieces" : selectedCategory}
          </h3>
          <button className="flex items-center gap-1 text-xs text-muted-foreground">
            <SlidersHorizontal size={12} /> Filter
          </button>
        </div>
        <div className="grid grid-cols-2 gap-3">
          {products.map(p => (
            <ProductCard key={p.id} product={p} wishlisted={wishlist.includes(p.id)}
              onToggleWishlist={() => toggleWishlist(p.id)} onClick={() => onProduct(p)} />
          ))}
        </div>
      </div>
    </div>
  );
}

/* ─── Product Card ─── */
function ProductCard({ product, wishlisted, onToggleWishlist, onClick }: {
  product: Product; wishlisted: boolean; onToggleWishlist: () => void; onClick: () => void;
}) {
  return (
    <div className="bg-card rounded-xl overflow-hidden cursor-pointer" onClick={onClick}
      style={{ boxShadow: "0 2px 12px rgba(26,23,20,0.07)" }}>
      <div className="relative" style={{ aspectRatio: "3/4" }}>
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" style={{ background: "#EDE9E3" }} />
        {product.tag && (
          <span className="absolute top-2.5 left-2.5 px-2 py-0.5 rounded-full text-white"
            style={{ fontSize: "10px", fontFamily: "'DM Mono', monospace", background: product.tag === "Sale" ? "#C9923A" : "#1A1714" }}>
            {product.tag}
          </span>
        )}
        <button onClick={e => { e.stopPropagation(); onToggleWishlist(); }}
          className="absolute top-2.5 right-2.5 w-7 h-7 rounded-full flex items-center justify-center"
          style={{ background: "rgba(249,247,244,0.9)" }}>
          <Heart size={14} fill={wishlisted ? "#C9923A" : "none"} color={wishlisted ? "#C9923A" : "#1A1714"} />
        </button>
      </div>
      <div className="p-3">
        <p className="text-[10px] text-muted-foreground tracking-wide uppercase mb-0.5"
          style={{ fontFamily: "'DM Mono', monospace" }}>{product.brand}</p>
        <p className="text-sm font-medium text-foreground leading-tight mb-1.5"
          style={{ fontFamily: "'Playfair Display', serif" }}>{product.name}</p>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            <span className="text-sm font-semibold text-foreground">${product.price}</span>
            {product.originalPrice && (
              <span className="text-xs text-muted-foreground line-through">${product.originalPrice}</span>
            )}
          </div>
          <div className="flex items-center gap-0.5">
            <Star size={10} fill="#C9923A" color="#C9923A" />
            <span style={{ fontSize: "10px" }} className="text-muted-foreground">{product.rating}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ─── Search Screen ─── */
function SearchScreen({ query, setQuery, products, onBack, onProduct, wishlist, toggleWishlist }: {
  query: string; setQuery: (q: string) => void; products: Product[];
  onBack: () => void; onProduct: (p: Product) => void; wishlist: number[];
  toggleWishlist: (id: number) => void;
}) {
  const results = query.length > 1
    ? products.filter(p => p.name.toLowerCase().includes(query.toLowerCase()) || p.brand.toLowerCase().includes(query.toLowerCase()))
    : [];

  return (
    <div className="pb-24 pt-2">
      <div className="px-5 pb-4">
        <div className="flex items-center gap-3">
          <button onClick={onBack}><ArrowLeft size={20} /></button>
          <div className="flex-1 flex items-center gap-3 px-4 py-3 rounded-xl border border-border"
            style={{ background: "#EDE9E3" }}>
            <Search size={16} className="text-muted-foreground" />
            <input autoFocus value={query} onChange={e => setQuery(e.target.value)}
              placeholder="Search styles, brands..."
              className="flex-1 bg-transparent text-sm text-foreground outline-none placeholder-muted-foreground" />
            {query && <button onClick={() => setQuery("")}><X size={14} className="text-muted-foreground" /></button>}
          </div>
        </div>
      </div>

      {query.length < 2 ? (
        <div className="px-5">
          <p className="text-xs text-muted-foreground tracking-widest uppercase mb-4"
            style={{ fontFamily: "'DM Mono', monospace" }}>Popular Searches</p>
          {["Cashmere knitwear", "Wool coats", "Silk dresses", "Wide-leg trousers", "Leather boots"].map(s => (
            <button key={s} onClick={() => setQuery(s)}
              className="w-full flex justify-between items-center py-3 border-b border-border text-sm text-foreground">
              {s} <ChevronRight size={14} className="text-muted-foreground" />
            </button>
          ))}
        </div>
      ) : results.length === 0 ? (
        <div className="px-5 pt-12 text-center">
          <p className="text-sm text-muted-foreground">No results for "{query}"</p>
        </div>
      ) : (
        <div className="px-5 grid grid-cols-2 gap-3">
          {results.map(p => (
            <ProductCard key={p.id} product={p} wishlisted={wishlist.includes(p.id)}
              onToggleWishlist={() => toggleWishlist(p.id)} onClick={() => onProduct(p)} />
          ))}
        </div>
      )}
    </div>
  );
}

/* ─── Product Detail Screen ─── */
function ProductScreen({ product, selectedSize, setSelectedSize, qty, setQty, wishlist, toggleWishlist, onBack, onCart, onAddToCart, cartCount }: {
  product: Product; selectedSize: string; setSelectedSize: (s: string) => void;
  qty: number; setQty: (n: number) => void; wishlist: number[];
  toggleWishlist: (id: number) => void; onBack: () => void; onCart: () => void;
  onAddToCart: () => void; cartCount: number;
}) {
  const [tab, setTab] = useState<"details" | "care" | "shipping">("details");
  const sizes = ["XS", "S", "M", "L", "XL"];

  return (
    <div className="pb-28">
      {/* Hero image */}
      <div className="relative" style={{ height: "420px" }}>
        <img src={product.image} alt={product.name} className="w-full h-full object-cover"
          style={{ background: "#EDE9E3" }} />
        <div className="absolute inset-0" style={{ background: "linear-gradient(to bottom, rgba(26,23,20,0.3) 0%, transparent 40%, rgba(26,23,20,0.05) 100%)" }} />
        <div className="absolute top-4 left-4 right-4 flex justify-between">
          <button onClick={onBack}
            className="w-9 h-9 rounded-full flex items-center justify-center"
            style={{ background: "rgba(249,247,244,0.9)" }}>
            <ArrowLeft size={18} />
          </button>
          <div className="flex gap-2">
            <button onClick={() => toggleWishlist(product.id)}
              className="w-9 h-9 rounded-full flex items-center justify-center"
              style={{ background: "rgba(249,247,244,0.9)" }}>
              <Heart size={18} fill={wishlist.includes(product.id) ? "#C9923A" : "none"}
                color={wishlist.includes(product.id) ? "#C9923A" : "#1A1714"} />
            </button>
            <button onClick={onCart}
              className="w-9 h-9 rounded-full flex items-center justify-center relative"
              style={{ background: "rgba(249,247,244,0.9)" }}>
              <ShoppingBag size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-0.5 -right-0.5 w-4 h-4 rounded-full text-white flex items-center justify-center"
                  style={{ fontSize: "9px", background: "#C9923A" }}>{cartCount}</span>
              )}
            </button>
          </div>
        </div>
        {product.tag && (
          <div className="absolute bottom-4 left-4">
            <span className="px-3 py-1 rounded-full text-white text-xs"
              style={{ fontFamily: "'DM Mono', monospace", background: product.tag === "Sale" ? "#C9923A" : "#1A1714" }}>
              {product.tag}
            </span>
          </div>
        )}
      </div>

      <div className="px-5 pt-5">
        {/* Name + price */}
        <div className="flex justify-between items-start mb-1">
          <div className="flex-1 pr-4">
            <p className="text-xs text-muted-foreground tracking-widest uppercase mb-1"
              style={{ fontFamily: "'DM Mono', monospace" }}>{product.brand}</p>
            <h2 className="text-2xl font-bold text-foreground leading-tight"
              style={{ fontFamily: "'Playfair Display', serif" }}>{product.name}</h2>
          </div>
          <div className="text-right">
            <p className="text-xl font-semibold text-foreground">${product.price}</p>
            {product.originalPrice && (
              <p className="text-sm text-muted-foreground line-through">${product.originalPrice}</p>
            )}
          </div>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-2 mb-5">
          <div className="flex gap-0.5">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={12} fill={i < Math.floor(product.rating) ? "#C9923A" : "none"}
                color="#C9923A" />
            ))}
          </div>
          <span className="text-xs text-muted-foreground">{product.rating} ({product.reviews} reviews)</span>
        </div>

        {/* Size selection */}
        <div className="mb-5">
          <div className="flex justify-between items-center mb-3">
            <p className="text-sm font-medium text-foreground">Size</p>
            <button className="text-xs text-muted-foreground flex items-center gap-1">
              Size Guide <ChevronRight size={10} />
            </button>
          </div>
          <div className="flex gap-2">
            {sizes.map(s => (
              <button key={s} onClick={() => setSelectedSize(s)}
                className="w-11 h-11 rounded-lg text-sm font-medium transition-all border"
                style={{
                  background: selectedSize === s ? "#1A1714" : "transparent",
                  color: selectedSize === s ? "#F9F7F4" : "#1A1714",
                  borderColor: selectedSize === s ? "#1A1714" : "rgba(26,23,20,0.2)",
                }}>
                {s}
              </button>
            ))}
          </div>
        </div>

        {/* Quantity */}
        <div className="flex items-center justify-between mb-6">
          <p className="text-sm font-medium text-foreground">Quantity</p>
          <div className="flex items-center gap-4">
            <button onClick={() => setQty(Math.max(1, qty - 1))}
              className="w-8 h-8 rounded-full border border-border flex items-center justify-center">
              <Minus size={14} />
            </button>
            <span className="text-sm font-semibold w-4 text-center">{qty}</span>
            <button onClick={() => setQty(qty + 1)}
              className="w-8 h-8 rounded-full border border-border flex items-center justify-center">
              <Plus size={14} />
            </button>
          </div>
        </div>

        {/* Tabs */}
        <div className="border-b border-border mb-4">
          <div className="flex gap-6">
            {(["details", "care", "shipping"] as const).map(t => (
              <button key={t} onClick={() => setTab(t)}
                className="pb-2 text-xs font-medium capitalize transition-all"
                style={{
                  color: tab === t ? "#1A1714" : "#8A7F74",
                  borderBottom: tab === t ? "2px solid #C9923A" : "2px solid transparent",
                }}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {tab === "details" && (
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            Crafted from 100% Merino wool, this coat features a tailored silhouette with a wrap closure and notched lapels. Fully lined in silk-blend fabric for exceptional comfort and drape.
          </p>
        )}
        {tab === "care" && (
          <p className="text-sm text-muted-foreground leading-relaxed mb-4">
            Dry clean only. Store folded or on a padded hanger. Brush gently with a soft garment brush after wearing. Keep away from direct sunlight.
          </p>
        )}
        {tab === "shipping" && (
          <div className="space-y-3 mb-4">
            {[
              { icon: Truck, text: "Free standard shipping on orders over $250" },
              { icon: RotateCcw, text: "30-day free returns & exchanges" },
              { icon: Shield, text: "Authenticity guaranteed on all items" },
            ].map(({ icon: Icon, text }) => (
              <div key={text} className="flex gap-3 items-start">
                <Icon size={16} className="text-muted-foreground mt-0.5 flex-shrink-0" />
                <p className="text-sm text-muted-foreground">{text}</p>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add to cart */}
      <div className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-card border-t border-border">
        <button onClick={onAddToCart}
          className="w-full py-4 rounded-xl text-sm font-semibold text-primary-foreground transition-all active:scale-[0.98]"
          style={{ background: "#1A1714" }}>
          Add to Cart — ${(product.price * qty).toLocaleString()}
        </button>
      </div>
    </div>
  );
}

/* ─── Cart Screen ─── */
function CartScreen({ cart, total, updateQty, onBack, onCheckout, onProduct }: {
  cart: CartItem[]; total: number; updateQty: (id: number, size: string, delta: number) => void;
  onBack: () => void; onCheckout: () => void; onProduct: (p: Product) => void;
}) {
  return (
    <div className="pb-36 pt-2">
      <div className="px-5 pb-4 flex justify-between items-center">
        <button onClick={onBack}><ArrowLeft size={20} /></button>
        <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
          Cart {cart.length > 0 && <span className="text-muted-foreground text-base">({cart.length})</span>}
        </h2>
        <div className="w-5" />
      </div>

      {cart.length === 0 ? (
        <div className="px-5 pt-20 text-center">
          <ShoppingBag size={40} className="text-muted-foreground mx-auto mb-4" strokeWidth={1.2} />
          <p className="text-base font-medium text-foreground mb-2"
            style={{ fontFamily: "'Playfair Display', serif" }}>Your cart is empty</p>
          <p className="text-sm text-muted-foreground mb-6">Add some pieces to get started.</p>
          <button onClick={onBack}
            className="px-6 py-3 rounded-xl text-sm font-medium text-primary-foreground"
            style={{ background: "#1A1714" }}>
            Continue Shopping
          </button>
        </div>
      ) : (
        <>
          <div className="px-5 space-y-4 mb-6">
            {cart.map(item => (
              <div key={`${item.id}-${item.size}`}
                className="flex gap-3 bg-card rounded-xl p-3"
                style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
                <button onClick={() => onProduct(item)} className="flex-shrink-0">
                  <img src={item.image} alt={item.name}
                    className="w-20 h-24 object-cover rounded-lg" style={{ background: "#EDE9E3" }} />
                </button>
                <div className="flex-1 min-w-0">
                  <p className="text-[10px] text-muted-foreground tracking-wide uppercase mb-0.5"
                    style={{ fontFamily: "'DM Mono', monospace" }}>{item.brand}</p>
                  <p className="text-sm font-medium text-foreground leading-tight mb-1"
                    style={{ fontFamily: "'Playfair Display', serif" }}>{item.name}</p>
                  <p className="text-xs text-muted-foreground mb-2">Size: {item.size}</p>
                  <div className="flex justify-between items-center">
                    <div className="flex items-center gap-2 border border-border rounded-lg px-2 py-1">
                      <button onClick={() => updateQty(item.id, item.size, -1)}>
                        <Minus size={12} />
                      </button>
                      <span className="text-xs font-semibold w-4 text-center">{item.qty}</span>
                      <button onClick={() => updateQty(item.id, item.size, 1)}>
                        <Plus size={12} />
                      </button>
                    </div>
                    <p className="text-sm font-semibold text-foreground">
                      ${(item.price * item.qty).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Order summary */}
          <div className="mx-5 bg-card rounded-xl p-4 mb-4"
            style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
            <h3 className="text-sm font-semibold text-foreground mb-3"
              style={{ fontFamily: "'Playfair Display', serif" }}>Order Summary</h3>
            <div className="space-y-2">
              {[
                { label: "Subtotal", value: `$${total.toLocaleString()}` },
                { label: "Shipping", value: total > 250 ? "Free" : "$12" },
                { label: "Tax (8%)", value: `$${(total * 0.08).toFixed(2)}` },
              ].map(({ label, value }) => (
                <div key={label} className="flex justify-between text-sm">
                  <span className="text-muted-foreground">{label}</span>
                  <span className="font-medium text-foreground">{value}</span>
                </div>
              ))}
              <div className="border-t border-border pt-2 mt-2 flex justify-between">
                <span className="text-sm font-semibold text-foreground">Total</span>
                <span className="text-sm font-bold text-foreground">
                  ${(total + (total > 250 ? 0 : 12) + total * 0.08).toFixed(2)}
                </span>
              </div>
            </div>
          </div>

          {/* Promo code */}
          <div className="mx-5 flex gap-2 mb-4">
            <input placeholder="Promo code"
              className="flex-1 px-4 py-3 rounded-xl border border-border text-sm outline-none"
              style={{ background: "#EDE9E3" }} />
            <button className="px-4 py-3 rounded-xl text-sm font-medium text-foreground"
              style={{ background: "#EDE9E3" }}>
              Apply
            </button>
          </div>
        </>
      )}

      {cart.length > 0 && (
        <div className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-card border-t border-border">
          <button onClick={onCheckout}
            className="w-full py-4 rounded-xl text-sm font-semibold text-primary-foreground"
            style={{ background: "#1A1714" }}>
            Proceed to Checkout
          </button>
        </div>
      )}
    </div>
  );
}

/* ─── Checkout Screen ─── */
function CheckoutScreen({ total, onBack, onConfirm }: {
  total: number; onBack: () => void; onConfirm: () => void;
}) {
  const [step, setStep] = useState<1 | 2 | 3>(1);
  const orderTotal = (total + (total > 250 ? 0 : 12) + total * 0.08).toFixed(2);

  return (
    <div className="pb-32 pt-2">
      <div className="px-5 pb-4 flex justify-between items-center">
        <button onClick={step > 1 ? () => setStep(s => (s - 1) as 1 | 2 | 3) : onBack}>
          <ArrowLeft size={20} />
        </button>
        <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
          Checkout
        </h2>
        <div className="w-5" />
      </div>

      {/* Steps indicator */}
      <div className="px-5 mb-6">
        <div className="flex items-center gap-2">
          {[1, 2, 3].map((s, i) => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className="flex items-center gap-1.5 flex-shrink-0">
                <div className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium"
                  style={{
                    background: step > s ? "#C9923A" : step === s ? "#1A1714" : "#EDE9E3",
                    color: step > s || step === s ? "#fff" : "#8A7F74",
                  }}>
                  {step > s ? <Check size={12} /> : s}
                </div>
                <span className="text-xs" style={{ color: step === s ? "#1A1714" : "#8A7F74" }}>
                  {["Delivery", "Payment", "Review"][i]}
                </span>
              </div>
              {i < 2 && <div className="h-px flex-1" style={{ background: step > s + 1 ? "#C9923A" : "#EDE9E3" }} />}
            </div>
          ))}
        </div>
      </div>

      <div className="px-5 space-y-4">
        {step === 1 && (
          <>
            <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
              <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
                <MapPin size={15} style={{ color: "#C9923A" }} /> Delivery Address
              </h3>
              <div className="space-y-3">
                <div className="grid grid-cols-2 gap-2">
                  <input placeholder="First name" defaultValue="Sarah"
                    className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                    style={{ background: "#EDE9E3" }} />
                  <input placeholder="Last name" defaultValue="Mitchell"
                    className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                    style={{ background: "#EDE9E3" }} />
                </div>
                <input placeholder="Street address" defaultValue="142 Broadwick Street"
                  className="w-full px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                  style={{ background: "#EDE9E3" }} />
                <div className="grid grid-cols-2 gap-2">
                  <input placeholder="City" defaultValue="London"
                    className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                    style={{ background: "#EDE9E3" }} />
                  <input placeholder="Post code" defaultValue="W1F 0JH"
                    className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                    style={{ background: "#EDE9E3" }} />
                </div>
              </div>
            </div>
            <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
              <h3 className="text-sm font-semibold text-foreground mb-3">Delivery Method</h3>
              {[
                { label: "Standard", eta: "5–7 business days", price: total > 250 ? "Free" : "$12" },
                { label: "Express", eta: "2–3 business days", price: "$18" },
                { label: "Next Day", eta: "Order by 3pm", price: "$28" },
              ].map((m, i) => (
                <label key={m.label} className="flex items-center gap-3 py-2.5 cursor-pointer">
                  <input type="radio" name="delivery" defaultChecked={i === 0}
                    className="accent-foreground w-4 h-4" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-foreground">{m.label}</p>
                    <p className="text-xs text-muted-foreground">{m.eta}</p>
                  </div>
                  <span className="text-sm font-medium text-foreground">{m.price}</span>
                </label>
              ))}
            </div>
          </>
        )}

        {step === 2 && (
          <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
            <h3 className="text-sm font-semibold text-foreground mb-4 flex items-center gap-2">
              <CreditCard size={15} style={{ color: "#C9923A" }} /> Payment Details
            </h3>
            <div className="space-y-3">
              <input placeholder="Cardholder name" defaultValue="Sarah Mitchell"
                className="w-full px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                style={{ background: "#EDE9E3" }} />
              <div className="relative">
                <input placeholder="Card number" defaultValue="•••• •••• •••• 4242"
                  className="w-full px-3 py-2.5 rounded-lg border border-border text-sm outline-none pr-16"
                  style={{ background: "#EDE9E3" }} />
                <span className="absolute right-3 top-2.5 text-xs text-muted-foreground"
                  style={{ fontFamily: "'DM Mono', monospace" }}>VISA</span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input placeholder="Expiry" defaultValue="09/27"
                  className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                  style={{ background: "#EDE9E3" }} />
                <input placeholder="CVV" defaultValue="•••"
                  className="px-3 py-2.5 rounded-lg border border-border text-sm outline-none"
                  style={{ background: "#EDE9E3" }} />
              </div>
            </div>
            <div className="mt-4 pt-4 border-t border-border">
              <p className="text-xs text-muted-foreground text-center">
                <Shield size={10} className="inline mr-1" />
                Payments are encrypted and secure
              </p>
            </div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
              <h3 className="text-sm font-semibold text-foreground mb-3">Delivery to</h3>
              <p className="text-sm text-foreground">Sarah Mitchell</p>
              <p className="text-sm text-muted-foreground">142 Broadwick Street, London W1F 0JH</p>
            </div>
            <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
              <h3 className="text-sm font-semibold text-foreground mb-3">Payment</h3>
              <p className="text-sm text-foreground">Visa ending in 4242</p>
            </div>
            <div className="bg-card rounded-xl p-4" style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
              <h3 className="text-sm font-semibold text-foreground mb-3">Order Total</h3>
              <div className="flex justify-between items-center">
                <span className="text-2xl font-bold text-foreground"
                  style={{ fontFamily: "'Playfair Display', serif" }}>${orderTotal}</span>
                <span className="text-xs text-muted-foreground">incl. tax</span>
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="absolute bottom-0 left-0 right-0 px-5 pb-6 pt-3 bg-card border-t border-border">
        <button
          onClick={step < 3 ? () => setStep(s => (s + 1) as 1 | 2 | 3) : onConfirm}
          className="w-full py-4 rounded-xl text-sm font-semibold text-primary-foreground"
          style={{ background: "#1A1714" }}>
          {step === 1 ? "Continue to Payment" : step === 2 ? "Review Order" : `Place Order — $${orderTotal}`}
        </button>
      </div>
    </div>
  );
}

/* ─── Confirmation Screen ─── */
function ConfirmationScreen({ onContinue }: { onContinue: () => void }) {
  return (
    <div className="px-5 pt-20 pb-32 flex flex-col items-center text-center">
      <div className="w-20 h-20 rounded-full flex items-center justify-center mb-6"
        style={{ background: "rgba(201, 146, 58, 0.12)" }}>
        <Check size={36} style={{ color: "#C9923A" }} strokeWidth={2.5} />
      </div>
      <p className="text-xs text-muted-foreground tracking-widest uppercase mb-2"
        style={{ fontFamily: "'DM Mono', monospace" }}>Order Confirmed</p>
      <h2 className="text-3xl font-bold text-foreground mb-3"
        style={{ fontFamily: "'Playfair Display', serif" }}>Thank You,<br />Sarah</h2>
      <p className="text-sm text-muted-foreground leading-relaxed mb-8 max-w-[260px]">
        Your order #MC-2025-8491 has been placed. You will receive a confirmation email shortly.
      </p>

      <div className="w-full bg-card rounded-xl p-4 mb-6 text-left"
        style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
        {[
          { icon: Package, label: "Processing", status: "In progress", active: true },
          { icon: Truck, label: "Dispatched", status: "Pending", active: false },
          { icon: Check, label: "Delivered", status: "Pending", active: false },
        ].map(({ icon: Icon, label, status, active }) => (
          <div key={label} className="flex items-center gap-3 py-2">
            <div className="w-8 h-8 rounded-full flex items-center justify-center"
              style={{ background: active ? "rgba(201,146,58,0.12)" : "#EDE9E3" }}>
              <Icon size={14} style={{ color: active ? "#C9923A" : "#8A7F74" }} />
            </div>
            <div className="flex-1">
              <p className="text-sm font-medium text-foreground">{label}</p>
              <p className="text-xs text-muted-foreground">{status}</p>
            </div>
          </div>
        ))}
      </div>

      <button onClick={onContinue}
        className="w-full py-4 rounded-xl text-sm font-semibold text-primary-foreground mb-3"
        style={{ background: "#1A1714" }}>
        Continue Shopping
      </button>
      <button className="text-sm text-muted-foreground">Track my order</button>
    </div>
  );
}

/* ─── Profile Screen ─── */
function ProfileScreen({ onBack }: { onBack: () => void }) {
  return (
    <div className="pb-28 pt-2">
      <div className="px-5 pb-4 flex justify-between items-center">
        <button onClick={onBack}><ArrowLeft size={20} /></button>
        <h2 className="text-lg font-bold text-foreground" style={{ fontFamily: "'Playfair Display', serif" }}>
          Profile
        </h2>
        <div className="w-5" />
      </div>

      {/* Avatar */}
      <div className="px-5 mb-6 flex items-center gap-4">
        <div className="w-16 h-16 rounded-full overflow-hidden">
          <img src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&auto=format"
            alt="Sarah Mitchell" className="w-full h-full object-cover" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-foreground"
            style={{ fontFamily: "'Playfair Display', serif" }}>Sarah Mitchell</h3>
          <p className="text-xs text-muted-foreground">sarah.mitchell@email.com</p>
          <span className="mt-1 inline-block px-2 py-0.5 rounded-full text-white"
            style={{ fontSize: "10px", background: "#C9923A", fontFamily: "'DM Mono', monospace" }}>
            Gold Member
          </span>
        </div>
      </div>

      {/* Stats */}
      <div className="mx-5 grid grid-cols-3 gap-2 mb-6">
        {[
          { label: "Orders", value: "24" },
          { label: "Wishlist", value: "18" },
          { label: "Reviews", value: "9" },
        ].map(({ label, value }) => (
          <div key={label} className="bg-card rounded-xl p-3 text-center"
            style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
            <p className="text-xl font-bold text-foreground"
              style={{ fontFamily: "'Playfair Display', serif" }}>{value}</p>
            <p className="text-xs text-muted-foreground">{label}</p>
          </div>
        ))}
      </div>

      {/* Menu */}
      <div className="mx-5 bg-card rounded-xl overflow-hidden"
        style={{ boxShadow: "0 2px 8px rgba(26,23,20,0.06)" }}>
        {[
          { icon: Package, label: "My Orders" },
          { icon: Heart, label: "Wishlist" },
          { icon: MapPin, label: "Saved Addresses" },
          { icon: CreditCard, label: "Payment Methods" },
          { icon: Bell, label: "Notifications" },
          { icon: Shield, label: "Privacy & Security" },
        ].map(({ icon: Icon, label }, i, arr) => (
          <button key={label}
            className="w-full flex items-center gap-3 px-4 py-4 text-left"
            style={{ borderBottom: i < arr.length - 1 ? "1px solid rgba(26,23,20,0.08)" : "none" }}>
            <div className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ background: "#EDE9E3" }}>
              <Icon size={15} className="text-foreground" />
            </div>
            <span className="flex-1 text-sm font-medium text-foreground">{label}</span>
            <ChevronRight size={14} className="text-muted-foreground" />
          </button>
        ))}
      </div>

      <div className="mx-5 mt-4">
        <button className="w-full py-3 rounded-xl text-sm font-medium text-center"
          style={{ color: "#C0392B", background: "rgba(192,57,43,0.08)" }}>
          Sign Out
        </button>
      </div>
    </div>
  );
}
