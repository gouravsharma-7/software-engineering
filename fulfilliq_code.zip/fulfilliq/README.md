# FulfilIQ - Agile Delivery Strategy and Reference Order Fulfilment Core

CSA10 Software Engineering, Assignment 1. Contains (1) a small working order-to-refund core used as
evidence for the first release, (2) a sprint simulation that regenerates the report figures, and
(3) a Jira CSV import. All data is synthetic. Simulated sprint results are NOT real team performance.

## Run (Python 3.10+)
    python -m unittest discover -s tests -t . -v     # 12 repeatable checks
    python -m fulfilliq.demo                         # order -> delivery -> return -> refund walkthrough
    pip install -r requirements.txt
    python simulation/sprint_simulation.py           # figures in docs/figures, indicators in docs/indicators.json

## Layout
    fulfilliq/service.py   reservation, idempotent payment, picking, dispatch, tracking, returns, refund audit
    tests/                 stock integrity (100 concurrent orders), idempotency, authorization, refund rules
    simulation/            labelled simulation of sprint 1 and the two-team redesign
    jira/jira_import.csv   epics and stories (import via Jira > System > External System Import > CSV)
    docs/                  figures and the assignment report (Word)

The low-stock alert is a deterministic fixed-threshold rule, not machine learning.
