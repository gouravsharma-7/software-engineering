"""Run: python -m fulfilliq.demo  -> one synthetic order from checkout to refund."""
from .service import Store, Denied

def main():
    s = Store()
    for u, r in [("cust1", "customer"), ("pick1", "picker"), ("sup1", "support"), ("fin1", "finance"), ("adm1", "admin")]:
        s.add_user(u, r)
    s.add_product("SKU-KETTLE", 10, 40.0)
    oid = s.place_order("cust1", "SKU-KETTLE", 1, "key-1")
    print("1 placed + reserved :", oid, s.stock("SKU-KETTLE"))
    print("2 gateway down      :", s.pay("cust1", oid, "pay-1", gateway_up=False))
    print("3 retry / replay    :", s.pay("cust1", oid, "pay-1"), "/", s.pay("cust1", oid, "pay-1"))
    print("4 pick list         :", s.pick_list("pick1"))
    print("5 wrong / right scan:", s.confirm_scan("pick1", oid, "SKU-X"), s.confirm_scan("pick1", oid, "SKU-KETTLE"))
    s.dispatch("pick1", oid); s.deliver("adm1", oid)
    print("6 customer tracking :", s.track("cust1", oid))
    s.request_return("cust1", oid)
    try: s.approve_refund("sup1", oid, 40.0)
    except Denied as e: print("7 support refund     : denied ->", e)
    print("8 finance refund    :", s.approve_refund("fin1", oid, 40.0))
    print("9 support lookup    :", s.lookup("sup1", oid))
    print("10 audit trail:")
    for a in s.audit_trail(oid): print("   ", a["actor"], a["event"])

if __name__ == "__main__":
    main()
