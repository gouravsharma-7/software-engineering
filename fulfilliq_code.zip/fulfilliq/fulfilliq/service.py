"""FulfilIQ core: order -> stock reservation -> idempotent payment -> pick -> dispatch
-> delivery -> return -> approved refund. Synthetic data only. SQLite, stdlib only."""
import sqlite3, time, uuid

ROLES = {"customer", "picker", "support", "finance", "admin"}
PERMS = {  # server-side authorization (S01)
    "place_order": {"customer"}, "pay": {"customer"}, "pick_list": {"picker"},
    "confirm_scan": {"picker"}, "dispatch": {"picker", "admin"}, "deliver": {"admin"},
    "request_return": {"customer"}, "approve_refund": {"finance"},
    "lookup": {"support", "admin"}, "alerts": {"picker", "admin"},
}
TRANSITIONS = {  # operational order lifecycle (not the Jira workflow)
    "PLACED": {"PAID", "CANCELLED"}, "PAID": {"PICKED"}, "PICKED": {"DISPATCHED"},
    "DISPATCHED": {"DELIVERED"}, "DELIVERED": {"RETURN_REQUESTED"},
    "RETURN_REQUESTED": {"REFUNDED"},
}
CUSTOMER_MILESTONES = {"PAID": "Paid", "PICKED": "Picked", "DISPATCHED": "Dispatched",
                       "DELIVERED": "Delivered", "REFUNDED": "Refunded"}
LOW_STOCK_THRESHOLD = 3          # deterministic rule, not machine learning
RESERVATION_TTL = 900            # seconds (planning assumption)
RETURN_WINDOW_DAYS = 30          # planning assumption
REFUND_LIMIT = {"finance": 500.0}  # amount limit per reviewer role (assumption)


class Denied(Exception): pass
class OutOfStock(Exception): pass
class BadTransition(Exception): pass


class Store:
    def __init__(self, path=":memory:"):
        self.path = path
        self._keep = sqlite3.connect(path, timeout=30, isolation_level=None, check_same_thread=False)
        self._keep.row_factory = sqlite3.Row
        self._keep.executescript("""
        CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, role TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS products(sku TEXT PRIMARY KEY, stock INTEGER CHECK(stock>=0),
            reserved INTEGER DEFAULT 0 CHECK(reserved>=0), price REAL);
        CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY, owner TEXT, sku TEXT, qty INTEGER,
            total REAL, status TEXT, idem_key TEXT UNIQUE, created REAL, reserve_expiry REAL,
            scanned INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS payments(idem_key TEXT PRIMARY KEY, order_id TEXT, state TEXT,
            attempts INTEGER DEFAULT 0);
        CREATE TABLE IF NOT EXISTS returns(order_id TEXT PRIMARY KEY, requested REAL, status TEXT);
        CREATE TABLE IF NOT EXISTS refunds(order_id TEXT PRIMARY KEY, amount REAL, approver TEXT, at REAL);
        CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL, actor TEXT,
            order_id TEXT, event TEXT);
        CREATE TABLE IF NOT EXISTS alerts(sku TEXT PRIMARY KEY, raised REAL);""")

    def _conn(self):
        # in-memory db is single-connection (calls are serialised); file db gets one connection per call
        if self.path == ":memory:":
            return self._keep
        c = sqlite3.connect(self.path, timeout=30, isolation_level=None, check_same_thread=False)
        c.row_factory = sqlite3.Row
        return c

    def add_user(self, uid, role):
        assert role in ROLES
        self._keep.execute("INSERT OR REPLACE INTO users VALUES(?,?)", (uid, role))

    def add_product(self, sku, stock, price):
        self._keep.execute("INSERT OR REPLACE INTO products(sku,stock,reserved,price) VALUES(?,?,0,?)",
                           (sku, stock, price))

    def _auth(self, c, uid, action):
        r = c.execute("SELECT role FROM users WHERE id=?", (uid,)).fetchone()
        if not r or r["role"] not in PERMS[action]:
            raise Denied(f"{uid} may not {action}")
        return r["role"]

    def _log(self, c, actor, oid, event):
        c.execute("INSERT INTO audit(ts,actor,order_id,event) VALUES(?,?,?,?)",
                  (time.time(), actor, oid, event))

    def _move(self, c, actor, oid, new):
        row = c.execute("SELECT status FROM orders WHERE id=?", (oid,)).fetchone()
        if not row or new not in TRANSITIONS.get(row["status"], ()):
            raise BadTransition(f"{row['status'] if row else '?'} -> {new}")
        c.execute("UPDATE orders SET status=? WHERE id=?", (new, oid))
        self._log(c, actor, oid, f"{row['status']}->{new}")

    def _tx(self, fn):
        c = self._conn()
        try:
            c.execute("BEGIN IMMEDIATE")
            out = fn(c)
            c.execute("COMMIT")
            return out
        except Exception:
            c.execute("ROLLBACK")
            raise
        finally:
            if c is not self._keep:
                c.close()

    # S02 place order with reservation (idempotent on key)
    def place_order(self, uid, sku, qty, idem_key, now=None):
        now = now or time.time()
        def tx(c):
            self._auth(c, uid, "place_order")
            dup = c.execute("SELECT id FROM orders WHERE idem_key=?", (idem_key,)).fetchone()
            if dup: return dup["id"]
            p = c.execute("SELECT stock,reserved,price FROM products WHERE sku=?", (sku,)).fetchone()
            if not p or p["stock"] - p["reserved"] < qty:
                raise OutOfStock(sku)
            c.execute("UPDATE products SET reserved=reserved+? WHERE sku=?", (qty, sku))
            oid = "ORD-" + uuid.uuid4().hex[:8]
            c.execute("INSERT INTO orders(id,owner,sku,qty,total,status,idem_key,created,reserve_expiry)"
                      " VALUES(?,?,?,?,?,?,?,?,?)",
                      (oid, uid, sku, qty, qty * p["price"], "PLACED", idem_key, now, now + RESERVATION_TTL))
            self._log(c, uid, oid, "PLACED+RESERVED")
            return oid
        return self._tx(tx)

    def expire_reservations(self, now=None):
        now = now or time.time()
        def tx(c):
            rows = c.execute("SELECT id,sku,qty FROM orders WHERE status='PLACED' AND reserve_expiry<?", (now,)).fetchall()
            for r in rows:
                c.execute("UPDATE products SET reserved=reserved-? WHERE sku=?", (r["qty"], r["sku"]))
                c.execute("UPDATE orders SET status='CANCELLED' WHERE id=?", (r["id"],))
                self._log(c, "system", r["id"], "RESERVATION_EXPIRED")
            return len(rows)
        return self._tx(tx)

    # S03 idempotent payment; gateway sandbox may be down
    def pay(self, uid, oid, pay_key, gateway_up=True):
        def tx(c):
            self._auth(c, uid, "pay")
            o = c.execute("SELECT owner FROM orders WHERE id=?", (oid,)).fetchone()
            if not o or o["owner"] != uid: raise Denied("not your order")
            pr = c.execute("SELECT state FROM payments WHERE idem_key=?", (pay_key,)).fetchone()
            if pr and pr["state"] == "AUTHORISED":
                return "AUTHORISED"                       # replay: no second charge
            if not pr:
                c.execute("INSERT INTO payments VALUES(?,?,?,0)", (pay_key, oid, "PENDING"))
            c.execute("UPDATE payments SET attempts=attempts+1 WHERE idem_key=?", (pay_key,))
            if not gateway_up:
                self._log(c, uid, oid, "PAYMENT_PENDING_GATEWAY_DOWN")
                return "PENDING"                          # order stays recoverable
            c.execute("UPDATE payments SET state='AUTHORISED' WHERE idem_key=?", (pay_key,))
            self._move(c, uid, oid, "PAID")
            return "AUTHORISED"
        return self._tx(tx)

    # S04 pick list, S12 scan, S05 dispatch / deliver
    def pick_list(self, uid):
        c = self._conn(); self._auth(c, uid, "pick_list")
        return [dict(r) for r in c.execute("SELECT id,sku,qty FROM orders WHERE status='PAID'")]

    def confirm_scan(self, uid, oid, scanned_sku):
        def tx(c):
            self._auth(c, uid, "confirm_scan")
            o = c.execute("SELECT sku FROM orders WHERE id=?", (oid,)).fetchone()
            if o["sku"] != scanned_sku:
                self._log(c, uid, oid, "WRONG_ITEM_SCANNED"); return False
            c.execute("UPDATE orders SET scanned=1 WHERE id=?", (oid,))
            self._move(c, uid, oid, "PICKED")
            return True
        return self._tx(tx)

    def dispatch(self, uid, oid):
        def tx(c):
            self._auth(c, uid, "dispatch")
            o = c.execute("SELECT sku,qty FROM orders WHERE id=?", (oid,)).fetchone()
            self._move(c, uid, oid, "DISPATCHED")
            c.execute("UPDATE products SET stock=stock-?, reserved=reserved-? WHERE sku=?",
                      (o["qty"], o["qty"], o["sku"]))
            p = c.execute("SELECT stock-reserved AS avail FROM products WHERE sku=?", (o["sku"],)).fetchone()
            if p["avail"] <= LOW_STOCK_THRESHOLD:      # S11 fixed-threshold rule, one alert per item
                c.execute("INSERT OR IGNORE INTO alerts VALUES(?,?)", (o["sku"], time.time()))
        return self._tx(tx)

    def deliver(self, uid, oid):
        def tx(c):
            self._auth(c, uid, "deliver"); self._move(c, uid, oid, "DELIVERED")
        return self._tx(tx)

    def alerts(self, uid):
        c = self._conn(); self._auth(c, uid, "alerts")
        return [r["sku"] for r in c.execute("SELECT sku FROM alerts")]

    # S06 tracking (permitted milestones only), S10 support lookup
    def track(self, uid, oid):
        c = self._conn()
        o = c.execute("SELECT owner FROM orders WHERE id=?", (oid,)).fetchone()
        if not o or o["owner"] != uid: raise Denied("not your order")
        out = []
        for e in c.execute("SELECT event FROM audit WHERE order_id=? ORDER BY id", (oid,)):
            if "->" in e["event"]:
                to = e["event"].split("->")[1]
                if to in CUSTOMER_MILESTONES: out.append(CUSTOMER_MILESTONES[to])
        return out

    def lookup(self, uid, oid):
        c = self._conn(); self._auth(c, uid, "lookup")
        o = c.execute("SELECT id,status,total FROM orders WHERE id=?", (oid,)).fetchone()
        r = c.execute("SELECT status FROM returns WHERE order_id=?", (oid,)).fetchone()
        f = c.execute("SELECT amount FROM refunds WHERE order_id=?", (oid,)).fetchone()
        return {"order": dict(o), "return": r["status"] if r else None, "refund": f["amount"] if f else None}

    # S07 return, S08 refund approval with amount limit and audit
    def request_return(self, uid, oid, days_since_delivery=0):
        def tx(c):
            self._auth(c, uid, "request_return")
            o = c.execute("SELECT owner FROM orders WHERE id=?", (oid,)).fetchone()
            if not o or o["owner"] != uid: raise Denied("not your order")
            if days_since_delivery > RETURN_WINDOW_DAYS: raise BadTransition("return window closed")
            self._move(c, uid, oid, "RETURN_REQUESTED")
            c.execute("INSERT INTO returns VALUES(?,?,?)", (oid, time.time(), "OPEN"))
        return self._tx(tx)

    def approve_refund(self, uid, oid, amount):
        def tx(c):
            role = self._auth(c, uid, "approve_refund")      # support agent is denied here
            if amount > REFUND_LIMIT[role]:
                self._log(c, uid, oid, f"REFUND_REJECTED_OVER_LIMIT:{amount}")
                return "OVER_LIMIT"
            self._move(c, uid, oid, "REFUNDED")
            c.execute("INSERT INTO refunds VALUES(?,?,?,?)", (oid, amount, uid, time.time()))
            c.execute("UPDATE returns SET status='REFUNDED' WHERE order_id=?", (oid,))
            self._log(c, uid, oid, f"REFUND_APPROVED:{amount}")
            return "APPROVED"
        return self._tx(tx)

    def audit_trail(self, oid):
        return [dict(r) for r in self._conn().execute("SELECT actor,event FROM audit WHERE order_id=? ORDER BY id", (oid,))]

    def stock(self, sku):
        return dict(self._conn().execute("SELECT stock,reserved FROM products WHERE sku=?", (sku,)).fetchone())
