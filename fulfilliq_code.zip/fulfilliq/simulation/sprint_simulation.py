"""SIMULATED sprint data + figures for the report. Nothing here is real team performance.
Run: python simulation/sprint_simulation.py   (needs matplotlib; writes docs/figures/*.png and docs/indicators.json)"""
import json, os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch

plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"],
                     "font.size": 10, "axes.edgecolor": "black", "savefig.dpi": 200, "savefig.bbox": "tight"})
OUT = os.path.join(os.path.dirname(__file__), "..", "docs", "figures"); os.makedirs(OUT, exist_ok=True)
GREYS = ["#000000", "#555555", "#999999", "#d0d0d0", "#ffffff"]
HATCH = ["", "//", "..", "xx", "\\\\"]

# ---------- capacity (planning assumptions)
def focused(people, days=10, hours=6, avail=1.0, reserve=0.20):
    nominal = people * days * hours * avail
    return nominal, nominal * (1 - reserve)
nom0, foc0 = focused(7)                                   # 420 -> 336
nomA, _ = focused(6); nomB, _ = focused(7, avail=0.6)     # 360, 252
nom1 = nomA + nomB; foc1 = nom1 * 0.75                    # 25% coordination reserve -> 459

# ---------- stories: id -> (points, epic)
STORIES = {"S01": (3, "Order & stock"), "S02": (5, "Order & stock"), "S03a": (2, "Payments & refunds"),
           "S03b": (3, "Payments & refunds"), "S04": (3, "Fulfilment & tracking"), "S05": (5, "Fulfilment & tracking"),
           "S06": (3, "Fulfilment & tracking"), "S07": (3, "Payments & refunds"), "S08": (5, "Payments & refunds"),
           "S09a": (3, "Delivery & support"), "S09b": (2, "Delivery & support"), "S10": (3, "Delivery & support"),
           "S11": (3, "Fulfilment & tracking"), "S12": (3, "Fulfilment & tracking")}
PLAN = {1: ["S01", "S02", "S03a", "S04", "S09a"], 2: ["S05", "S06", "S11", "S09b"],
        3: ["S03b", "S07", "S08", "S12"], 4: ["S10"]}
assert [sum(STORIES[s][0] for s in v) for v in PLAN.values()] == [16, 13, 14, 3]

# ---------- SIMULATED sprint 1: (day, status) transitions per story
TL = {"S01": [(1, "Dev"), (3, "Review"), (4, "Dev"), (5, "Test"), (6, "Done")],
      "S02": [(1, "Dev"), (5, "Review"), (6, "Test"), (7, "Dev"), (8, "Done")],
      "S04": [(4, "Dev"), (6, "Test"), (7, "Done")],
      "S03a": [(5, "Dev"), (7, "Blocked"), (9, "Dev")],
      "S09a": [(3, "Dev"), (9, "Review")]}
def status(story, day):
    s = "To Do"
    for d, st in TL[story]:
        if d <= day: s = st
    return s
days = range(1, 11)
cols = ["To Do", "Dev", "Review", "Test", "Blocked", "Done"]
counts = {d: {c: sum(1 for s in TL if status(s, d) == c) for c in cols} for d in days}
wip = {d: sum(counts[d][c] for c in ["Dev", "Review", "Test", "Blocked"]) for d in days}
done = [s for s in TL if status(s, 10) == "Done"]
cycle = {s: next(d for d, st in TL[s] if st == "Done") - TL[s][0][0] for s in done}
blocked = sum(1 for s in TL for d in days if status(s, d) == "Blocked")
reopened = ["S01", "S02"]
planned1 = sum(STORIES[s][0] for s in PLAN[1]); comp1 = sum(STORIES[s][0] for s in done)
ind1 = {"planned_points": planned1, "completed_points": comp1, "completion_pct": round(100 * comp1 / planned1, 1),
        "mean_cycle_days": round(sum(cycle.values()) / len(cycle), 1), "blocked_story_days": blocked,
        "max_wip": max(wip.values()), "max_test_queue": max(counts[d]["Test"] for d in days),
        "reopened_per_completed": round(len(reopened) / len(done), 2)}
# ---------- SIMULATED revised sprint (two teams, changed conditions)
ind2 = {"planned_points": 22, "completed_points": 18, "completion_pct": round(100 * 18 / 22, 1),
        "mean_cycle_days": round((3 + 2 + 5 + 4 + 2 + 4) / 6, 1), "blocked_story_days": 1,
        "max_wip": 9, "max_test_queue": 2, "reopened_per_completed": round(2 / 6, 2)}
json.dump({"capacity": {"original_nominal": nom0, "original_focused": foc0, "revised_nominal": nom1,
          "revised_focused": round(foc1), "ratio": round(foc1 / foc0, 2)}, "sprint1_simulated": ind1,
          "revised_simulated": ind2}, open(os.path.join(OUT, "..", "indicators.json"), "w"), indent=2)
print(json.dumps({"s1": ind1, "revised": ind2, "cap": [nom0, foc0, nom1, round(foc1)]}, indent=1))

def save(name):
    f = plt.gcf()
    if f._suptitle is not None: f._suptitle.set_text("")
    for a in f.axes: a.set_title("")
    plt.savefig(os.path.join(OUT, name + ".png")); plt.close()
def box(ax, x, y, w, h, t, fs=9, fill="white", bold=False, ls="-"):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.02", fc=fill, ec="black", lw=1.2, ls=ls))
    ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal")
def arrow(ax, a, b, t=None, style="->", ls="-"):
    ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle=style, lw=1.2, ls=ls))
    if t: ax.text((a[0] + b[0]) / 2, (a[1] + b[1]) / 2 + 0.12, t, ha="center", fontsize=8)

# F1 order lifecycle
fig, ax = plt.subplots(figsize=(9, 2.6)); ax.axis("off"); ax.set_xlim(-0.3, 13); ax.set_ylim(0, 3)
st = ["PLACED", "PAID", "PICKED", "DISPATCHED", "DELIVERED", "RETURN\nREQUESTED", "REFUNDED"]
for i, s in enumerate(st):
    box(ax, i * 1.85, 1.2, 1.5, 0.8, s, 8, bold=(s in ("PLACED", "REFUNDED")))
    if i: arrow(ax, (i * 1.85 - 0.33, 1.6), (i * 1.85, 1.6))
box(ax, 0, 0.1, 1.5, 0.6, "CANCELLED\n(expiry)", 7.5, ls="--"); arrow(ax, (0.75, 1.2), (0.75, 0.7), style="->", ls="--")
ax.text(3.7, 0.4, "Gateway down: payment stays PENDING; retry with same key is safe", fontsize=8, style="italic")
ax.text(9.2, 2.45, "Refund approval: finance role only, amount limit, audit record", fontsize=8, style="italic")
ax.set_title("Figure 1. Operational order lifecycle (distinct from the Jira development workflow)", fontsize=10); save("f1_lifecycle")

# F2 module scope map
fig, ax = plt.subplots(figsize=(9, 3.4)); ax.axis("off"); ax.set_xlim(0, 12); ax.set_ylim(0, 4.6)
mods = [("Catalogue, cart,\ncheckout", 0), ("Inventory sync\n(reservation)", 1), ("Payment\nintegration", 2), ("Order\ntracking", 3),
        ("Warehouse\npicking", 4), ("Returns and\nrefunds", 5), ("Support\nconsole", 6), ("Sales\nanalytics", 7), ("Demand\nforecast (ML)", 8)]
for i, (m, k) in enumerate(mods):
    deferred = i >= 7
    r, c = divmod(i, 5)
    box(ax, 0.2 + c * 2.35, 3.0 - r * 1.5, 2.1, 1.0, m + ("\n[DEFERRED]" if deferred else "\n[RELEASE 1]"), 8.5,
        fill="#d9d9d9" if deferred else "white", ls="--" if deferred else "-")
ax.text(0.2, 0.2, "Note: the brief lists nine modules; analytics is deferred. Forecasting is an extension, not part of the nine and not release 1.", fontsize=8, style="italic")
ax.set_title("Figure 2. Module scope: retained versus deferred", fontsize=10); save("f2_scope")

# F3 capacity
fig, ax = plt.subplots(figsize=(6.5, 3.4))
labels = ["Original\n(1 team, 7 people)", "Revised\n(Team A 6 + Team B 7)"]
usable = [foc0, foc1]; reserve = [nom0 - foc0, nom1 - foc1]
ax.bar(labels, usable, color="#7f7f7f", ec="black", label="Focused hours", width=0.5)
ax.bar(labels, reserve, bottom=usable, color="white", ec="black", hatch="//", label="Reserve (defects, review, coordination)", width=0.5)
for i, u in enumerate(usable): ax.text(i, u / 2, f"{u:.0f} h", ha="center", color="white", fontweight="bold")
ax.set_ylabel("Hours per two-week sprint"); ax.legend(frameon=False, fontsize=8, loc="upper left")
ax.set_title(f"Figure 3. Capacity: 1.37x, not 2x (planning assumption)", fontsize=10); ax.spines[["top", "right"]].set_visible(False); save("f3_capacity")

# F4 release plan gantt
fig, ax = plt.subplots(figsize=(9, 4.4))
order = ["S01", "S02", "S03a", "S04", "S09a", "S05", "S06", "S11", "S09b", "S03b", "S07", "S08", "S12", "S10"]
sprint_of = {s: k for k, v in PLAN.items() for s in v}
epics = list(dict.fromkeys(v[1] for v in STORIES.values())); fill = dict(zip(epics, ["#222222", "#777777", "#bbbbbb", "#ffffff"]))
for i, s in enumerate(order):
    k = sprint_of[s]; ax.barh(i, 2, left=(k - 1) * 2, color=fill[STORIES[s][1]], ec="black", hatch="//" if s in ("S03b", "S12") else "")
    ax.text((k - 1) * 2 + 1, i, f"{s} ({STORIES[s][0]})", ha="center", va="center", fontsize=8,
            color="white" if fill[STORIES[s][1]] in ("#222222", "#777777") else "black")
ax.axvline(3, color="black", ls="--", lw=1); ax.text(3.05, -0.9, "Gateway sandbox opens (wk 4)", fontsize=8)
ax.axvline(4, color="black", ls=":", lw=1); ax.text(4.05, -0.4, "Scanner arrives (wk 5)", fontsize=8)
ax.axvline(2, color="black", lw=2); ax.text(2.05, -0.9, "Change event", fontsize=8, fontweight="bold")
ax.set_yticks([]); ax.set_xticks(range(0, 9)); ax.set_xlabel("Week"); ax.set_ylim(len(order), -1.3); ax.set_xlim(0, 8)
ax.legend([plt.Rectangle((0, 0), 1, 1, fc=fill[e], ec="black") for e in epics], epics, frameon=False, fontsize=8, loc="upper center", bbox_to_anchor=(0.5, -0.15), ncol=4)
ax.set_title("Figure 4. Four-sprint release plan with dependency milestones (points in brackets)", fontsize=10); save("f4_release_plan")

# F5 workflow with WIP limits
fig, ax = plt.subplots(figsize=(9, 2.8)); ax.axis("off"); ax.set_xlim(0, 13); ax.set_ylim(0, 3.4)
wf = [("Ready", "DoR met"), ("In Progress", "WIP 4"), ("Review", "WIP 2"), ("Test", "WIP 2"), ("Done", "DoD met")]
for i, (n, w) in enumerate(wf):
    box(ax, i * 2.5, 1.5, 2.0, 1.0, f"{n}\n[{w}]", 9, bold=True)
    if i: arrow(ax, (i * 2.5 - 0.5, 2.0), (i * 2.5, 2.0))
box(ax, 5, 0.1, 2.0, 0.8, "Blocked\n(reason + owner,\nstill counted)", 8, fill="#d9d9d9")
arrow(ax, (6.0, 1.5), (6.0, 0.9), ls="--"); arrow(ax, (7.5, 1.5), (2.2, 1.5), ls="--")
ax.text(8.6, 0.8, "Failed review or test returns the story to\nIn Progress (counted as reopened)", fontsize=8, style="italic")
ax.set_title("Figure 5. Jira development workflow with WIP limits", fontsize=10); save("f5_workflow")

# F6 CFD, F7 burndown
fig, ax = plt.subplots(figsize=(6.8, 3.6))
ser = [(c, [counts[d][c] for d in days]) for c in ["Done", "Test", "Review", "Blocked", "Dev"]]
ax.stackplot(list(days), [s for _, s in ser], labels=[c for c, _ in ser], colors=["#222222", "#555555", "#888888", "#e6e6e6", "#bbbbbb"], edgecolor="black", lw=0.6)
ax.set_xlabel("Sprint day"); ax.set_ylabel("Stories in system"); ax.legend(frameon=False, fontsize=8, loc="upper left"); ax.set_xlim(1, 10)
ax.set_title("Figure 6. Simulated sprint 1 cumulative flow (stories started)", fontsize=10); ax.spines[["top", "right"]].set_visible(False); save("f6_cfd")

fig, ax = plt.subplots(figsize=(6.8, 3.4))
rem = [planned1 - sum(STORIES[s][0] for s in done if next(d for d, st in TL[s] if st == "Done") <= d) for d in days]
ax.plot([0] + list(days), [planned1] + rem, "k-o", label="Simulated remaining points", drawstyle="steps-post")
ax.plot([0, 10], [planned1, 0], "k--", label="Ideal")
ax.set_xlabel("Sprint day"); ax.set_ylabel("Points remaining"); ax.legend(frameon=False, fontsize=8)
ax.set_title("Figure 7. Simulated sprint 1 burndown: 11 of 16 points completed", fontsize=10); ax.spines[["top", "right"]].set_visible(False); save("f7_burndown")

# F8 comparison of indicators
fig, axs = plt.subplots(1, 4, figsize=(9.5, 3))
for ax, (k, t) in zip(axs, [("completion_pct", "Completion (%)"), ("mean_cycle_days", "Mean cycle (days)"),
                            ("blocked_story_days", "Blocked story-days"), ("reopened_per_completed", "Reopened / done")]):
    v = [ind1[k], ind2[k]]; ax.bar(["Original", "Revised"], v, color=["white", "#777777"], ec="black", hatch=None, width=0.55)
    for i, x in enumerate(v): ax.text(i, x, f"{x}", ha="center", va="bottom", fontsize=8)
    ax.set_title(t, fontsize=9); ax.spines[["top", "right"]].set_visible(False); ax.tick_params(labelsize=8); ax.set_ylim(0, max(v) * 1.25)
fig.suptitle("Figure 8. Simulated indicators: original sprint 1 vs revised two-team sprint", fontsize=10, y=1.03); plt.tight_layout(); save("f8_indicators")

# F9 two-team coordination
fig, ax = plt.subplots(figsize=(9, 4.2)); ax.axis("off"); ax.set_xlim(0, 12); ax.set_ylim(0, 6)
box(ax, 2.5, 4.9, 7, 0.9, "Shared Product Backlog  |  Product Owner + Integration Owner", 9, bold=True)
box(ax, 0.1, 2.5, 3.6, 1.8, "TEAM A (6)\nOrder, stock, tracking,\npicking, QA, DevOps", 9)
box(ax, 8.3, 2.5, 3.6, 1.8, "TEAM B (7; 60% in sprint 2)\nRegion policy, refund\napproval, UI, payments pair", 9)
box(ax, 4.0, 2.7, 3.9, 1.4, "Shared contracts: order, payment,\naddress; integration\nlane (WIP 2)", 8.5, fill="#d9d9d9", bold=True)
box(ax, 0.3, 0.3, 11.4, 1.0, "Twice-weekly dependency review  |  one integrated demo  |  region policy as configuration  |  release gate: authorization and audit", 9)
arrow(ax, (6, 4.9), (1.9, 4.3)); arrow(ax, (6, 4.9), (10.1, 4.3)); arrow(ax, (1.9, 2.5), (1.9, 1.3)); arrow(ax, (10.1, 2.5), (10.1, 1.3))
ax.set_title("Figure 9. Scaled coordination design for two teams (SAFe-inspired, lightweight)", fontsize=10); save("f9_scaled")
