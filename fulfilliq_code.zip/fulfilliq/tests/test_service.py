import os, tempfile, threading, unittest
from fulfilliq.service import *

def fresh(path=":memory:"):
    s = Store(path)
    for u, r in [("c1", "customer"), ("c2", "customer"), ("p1", "picker"), ("s1", "support"), ("f1", "finance"), ("a1", "admin")]:
        s.add_user(u, r)
    s.add_product("K", 10, 40.0)
    return s

def journey(s, key="k1"):
    oid = s.place_order("c1", "K", 1, key); s.pay("c1", oid, "p" + key)
    s.confirm_scan("p1", oid, "K"); s.dispatch("p1", oid); s.deliver("a1", oid)
    return oid

class T(unittest.TestCase):
    def test_login_permissions(self):
        s = fresh()
        with self.assertRaises(Denied): s.place_order("p1", "K", 1, "x")
        with self.assertRaises(Denied): s.pick_list("c1")

    def test_out_of_stock_rejected(self):
        with self.assertRaises(OutOfStock): fresh().place_order("c1", "K", 11, "x")

    def test_100_concurrent_orders_never_oversell(self):
        d = tempfile.mkdtemp(); s = fresh(os.path.join(d, "t.db")); res = []; lock = threading.Lock()
        def w(i):
            try: s.place_order("c1", "K", 1, f"k{i}"); r = 1
            except OutOfStock: r = 0
            with lock: res.append(r)
        th = [threading.Thread(target=w, args=(i,)) for i in range(100)]
        [t.start() for t in th]; [t.join() for t in th]
        self.assertEqual(sum(res), 10); self.assertEqual(s.stock("K")["reserved"], 10)

    def test_payment_idempotent_ten_retries(self):
        s = fresh(); oid = s.place_order("c1", "K", 1, "k")
        for _ in range(10): s.pay("c1", oid, "pay-1")
        self.assertEqual(s._conn().execute("SELECT COUNT(*) FROM payments").fetchone()[0], 1)
        self.assertEqual(s.lookup("s1", oid)["order"]["status"], "PAID")

    def test_gateway_down_keeps_order_recoverable(self):
        s = fresh(); oid = s.place_order("c1", "K", 1, "k")
        self.assertEqual(s.pay("c1", oid, "p", gateway_up=False), "PENDING")
        self.assertEqual(s.pay("c1", oid, "p"), "AUTHORISED")

    def test_pick_list_only_paid(self):
        s = fresh(); a = s.place_order("c1", "K", 1, "a"); s.place_order("c1", "K", 1, "b"); s.pay("c1", a, "pa")
        self.assertEqual([x["id"] for x in s.pick_list("p1")], [a])

    def test_invalid_transition_and_wrong_scan(self):
        s = fresh(); oid = s.place_order("c1", "K", 1, "a")
        with self.assertRaises(BadTransition): s.dispatch("p1", oid)
        s.pay("c1", oid, "pa"); self.assertFalse(s.confirm_scan("p1", oid, "WRONG"))

    def test_tracking_milestones_and_owner_only(self):
        s = fresh(); oid = journey(s)
        self.assertEqual(s.track("c1", oid), ["Paid", "Picked", "Dispatched", "Delivered"])
        with self.assertRaises(Denied): s.track("c2", oid)

    def test_refund_rules(self):
        s = fresh(); oid = journey(s)
        with self.assertRaises(Denied): s.request_return("c2", oid)
        s.request_return("c1", oid)
        with self.assertRaises(Denied): s.approve_refund("s1", oid, 40.0)
        self.assertEqual(s.approve_refund("f1", oid, 900.0), "OVER_LIMIT")
        self.assertEqual(s.approve_refund("f1", oid, 40.0), "APPROVED")
        self.assertEqual(s.lookup("s1", oid)["refund"], 40.0)
        ev = [a["event"] for a in s.audit_trail(oid)]
        self.assertTrue(any("REFUND_APPROVED" in e for e in ev) and any("OVER_LIMIT" in e for e in ev))

    def test_return_window(self):
        s = fresh(); oid = journey(s)
        with self.assertRaises(BadTransition): s.request_return("c1", oid, days_since_delivery=31)

    def test_low_stock_alert_once(self):
        s = fresh(); s.add_product("L", 5, 10.0)
        for i in range(3):
            oid = s.place_order("c1", "L", 1, f"l{i}"); s.pay("c1", oid, f"pl{i}")
            s.confirm_scan("p1", oid, "L"); s.dispatch("p1", oid)
        self.assertEqual(s.alerts("p1"), ["L"])

    def test_reservation_expiry_releases_stock(self):
        s = fresh(); s.place_order("c1", "K", 2, "x", now=1000.0)
        self.assertEqual(s.expire_reservations(now=1000.0 + RESERVATION_TTL + 1), 1)
        self.assertEqual(s.stock("K")["reserved"], 0)

if __name__ == "__main__":
    unittest.main()
